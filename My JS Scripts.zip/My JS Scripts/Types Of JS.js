function myFun()
{
alert("This works by External JS");
}