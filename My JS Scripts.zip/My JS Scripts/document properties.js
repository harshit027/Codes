function changeBGColor()
{  
   document.bgColor='#996600';
}
function initialBGColor()
{  
   document.bgColor='#ffffff';
}
function changeFGColor()
{  
   document.fgColor='#0000ff';
}
function initialFGColor()
{  
   document.fgColor='#000000';
}

function showTitle()
{
   alert("Title : "+document.title);
}

function showURL()
{
   alert("URL : "+document.URL);
}

function showLastModification()
{
   alert("Last Modified : "+document.lastModified );
}