function showTarget()
{
     var obj=document.getElementById("link1");
     obj.target="Events.html";
     alert(obj.target);
}

function showText()
{
     var obj=document.getElementById("link1");
     obj.text="Events Page";
     alert(obj.text);
}