function assignNewURL()
{
   assign("E:\CODES Drive\My JS Scripts\Events.html");
}

fucntion reloadPage()
{
   
   document.reload();
}

fucntion replaceURL()
{
   location.replace("E:\CODES Drive\My JS Scripts\Events.html");
}