function countHistory()
{
   alert("Number of URLs : "+history.length);
}

function goToURL2()
{
   history.go(2);
}
