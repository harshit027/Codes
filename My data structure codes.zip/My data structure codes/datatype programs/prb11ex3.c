#include<stdio.h>
#include<conio.h>
void main()
{
register float r=3.14;
register double y=3.4;
printf("r=%f y=%f",r,y);
}
