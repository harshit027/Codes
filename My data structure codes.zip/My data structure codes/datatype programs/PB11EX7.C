#include<stdio.h>
#include<conio.h>
int i=10,j=20,k=30;
void main()
{
int i=1,j=2,k=3;
clrscr();
printf("i=%d j=%d k=%d\n",i,j,k);
val();
}
val()
{
printf("i=%dj=%dk=%d \n",i,j,k);
}
