import java.io.*;
class MyRational1
{
	double num,den;
	void getValue() throws Exception
	{
		BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
		String str="";
		System.out.println("\nEnter Numerator : ");
		str=br.readLine();
		num=Double.valueOf(str).doubleValue();
		System.out.println("\nEnter Denominator : ");
		str=br.readLine();
		den=Double.valueOf(str).doubleValue();
	}
	void showValue()
	{
		System.out.println(num+"/"+den);
	}
	public static void main(String args[]) throws Exception
	{
			MyRational1 r=new MyRational1();
			r.getValue();
			r.showValue();
	}
}