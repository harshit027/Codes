//package pk;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
//import pk.DialogBox.java;

 class regstr extends JFrame implements ActionListener,WindowListener
{
//boolean addmin=true;
//JCheckBox jbx[];
JButton jbtn;
JButton jbtn1;
JButton jbtn2;
JButton jbtn3;
Color myc2=Color.orange;
JPanel p1,p2,p3;
JLabel jl;
ImageIcon ig1,ig2,ig3;

regstr()
{
	setTitle("Registration");
	setSize(800,800);
	//p1=new JPanel();
	/*jbx=new JCheckBox[10];
	//b=Box.createVerticalBox();
	//String jbx1[]={"C/C++","Visual Basic","Visual C++","Core Java","Advance Java","ASP.net","Java.net","HTML","Computer Hardware","Linux"};
		for(int i=0;i<=9;i++)
	{
		jbx[i]=new JCheckBox(jbx1[i],false);
		p1.add(jbx[i]);
		b.add(jbx[i]);
		b.add(Box.createVerticalStrut(25));
		jbx[i].setBackground(myc2);
	}
	p1.add(b);*/

		//--------------------//
	p2=new JPanel();
	p3=new JPanel();
	getContentPane().add(p3,"Center");
	Container c=getContentPane();
	//p1.setBackground(myc1);
	//p2.setBackground(myc);
	p3.setBackground(myc2);
	ImageIcon ig1 =new ImageIcon("Follow.gif");
	jl=new JLabel("Follow.gif",ig1,JLabel.CENTER);
	p3.add(jl);
	jbtn=new JButton("REGISTRATION");
	jbtn.setBackground(myc2);
	jbtn.addActionListener(this);
	jbtn1=new JButton("SIGN-IN");
	jbtn1.setBackground(myc2);
	getContentPane().add(p2,"South");
	p2.add(jbtn);
	p2.add(jbtn1);
	jbtn2=new JButton("Back",new ImageIcon ("back.gif "));
	jbtn3=new JButton("Next",new ImageIcon ("next1.gif "));
	jbtn1.addActionListener(this);
	jbtn2.addActionListener(this);
	jbtn3.addActionListener(this);
	p2.add(jbtn2);
	p2.add(jbtn3);

	jbtn2.setBackground(myc2);
	jbtn3.setBackground(myc2);

		//----------------------------func for administrator use--------------//
	//getContentPane().add(p1,"West");
	setVisible(true);
}

public void actionPerformed(ActionEvent ae)
{
	JButton jbt=(JButton)ae.getSource();
	if(jbt==jbtn)
	{
	JOptionPane.showMessageDialog(this,"This is recomended,you should have \njdk1.3 or above installed on your computer\ndo you wish to continue?","information",JOptionPane.OK_CANCEL_OPTION);
	}
	/*else
	if(jbt==jbtn1)
	{

		JFrame jf=new pk.Ewndow();
		jf.show();
		jf.setVisible(false);
		//pk.Ewndow ewin =new pk.Ewndow();
	}*/
}
public void windowActivated(WindowEvent e1)
{
}
public void windowClosed(WindowEvent e1)
{
}
public void windowClosing(WindowEvent e1)
{
}
public void windowDeactivated(WindowEvent e1)
{
}
public void windowDeiconified(WindowEvent e1)
{
}
public void windowIconified(WindowEvent e1)
{
}
public void windowOpened(WindowEvent e1)
{
}


}




