import java.awt.*;
import java.applet.*;
import java.awt.event.*;
 class  sampleframe extends Frame implements ActionListener
    {
    Button open;
    sampleframe(String title)
    {
    open= new Button("open");
    add(open);
    open.addActionListener(this);
    super(title);
    {
    mwa ada=new mwa(this);
    addWindowListener(ada);
    }
   }
   public void Actionperformed(ActionEvent ae)
   {
     diag d1= new diag(


    public void paint (Graphics g)
        {
        g.drawString("in frame");
        }
    
    }
   class mwa extends WindowAdapter
   {
   fampleframe sf;
   public  mwa (sampleframe sf)
   {
   this.sampleframe=sf;
   }
   public void windowClosing(WindowEvent we)
   {
   sf.setVisible(false);

   }
   }



public class frdia extends Applet implements ActionLister
{
    sampleframe sf;
    public void init()
        {
         sf=new sampleframe("my dialog");
         sf.setVisible(true);
        }
    public void start()
        {
        sf.setVisible(true);
        }
     public void stop()
        {
        sf.setVisible(false);
        }
       public void paint(Graphics g)
       {
       g.drawString("in applet");
       }
  }



