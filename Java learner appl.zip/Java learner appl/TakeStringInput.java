import java.io.*;

class TakeStringInput
{
	public static void main(String args[])
	{
		try
		{
			InputStreamReader x = new InputStreamReader(System.in);
			BufferedReader br = new BufferedReader(x);
			String str="";
			str=br.readLine();
			System.out.println("Inputted String is : "+str);
			System.out.println("Length of String is : "+str.length());

			System.out.println("Enter Any Integer Value : ");
			str=br.readLine();
			int y = Integer.parseInt(str);
			System.out.println("You have Entered : "+y +" and multiplied by 2 is : "+y*2);

			System.out.println("Enter Any Float Value : ");
			str=br.readLine();
			//Float obj;
			//obj = Float.valueOf(str);
			//float t = obj.floatValue();

			float f = Float.valueOf(str).floatValue();
			System.out.println("You have Entered : "+f +" and multiplied by 2 is : "+f*2);
		}
		catch(Exception e)
		{}
	}
}