import java.io.*;
class MyFilter implements FilenameFilter
{
	String ext;
	MyFilter(String ext)
	{
		this.ext = ext;
	}
	public boolean accept(File d, String name)
	{
		return name.endsWith(ext);
	}
}
class FileFiltering
{
	public static void main(String args[])
	{
		File f=new File("e:\\old\\java_programs");
		MyFilter myfl=new MyFilter(".class");
		File lst[] = f.listFiles(myfl);
		for(int i=0;i<=lst.length-1;i++)
		{
			if (lst[i].isFile())
			{
				System.out.println("File : "+lst[i].getName());
				//lst[i].delete();
				//System.out.println("File Deleted");
			}
			else
			{
				System.out.println("Directory : "+lst[i].getName());
			}
		}
	}
}