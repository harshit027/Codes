import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.*;
import javax.swing.border.*;


class Student_marks_details extends JFrame implements ActionListener
 {
          JButton jb1,jb2,jb3,jb4;
          JTextField   jt1,jt2,jt3,jt4,jt5,jt6,jt7;
          JTable table,table1;
          JScrollPane jsp,jsp1;
           Container cp;
          JComboBox jc1,jc2;
          JPanel jp1,jp3;
          int v,h,v1,h1;
          ResultSet rs,rs1;
          Statement st,st1;
          Connection con,con1;
          String  qry,qry1,qry11,qry3,qry2,qry4,qry5,qry6,qry7,qry8,qry9,qry10,qry12,qry13,qry14;
          int n=10;
          public static void main(String args[])
          {
                    new Student_marks_details();
          }
          Student_marks_details()
          {
             super("Record of Student Marks");
            // getContentPane().setLayout(new BorderLayout());
             setSize(850,850);
 
             WindowListener l = new WindowAdapter()
              {
               public void windowClosing(WindowEvent we)
                  {
                  System.exit(0);
                 }
              };
          addWindowListener(l);
          jp1 = new JPanel();
          cp = getContentPane();
          GridBagLayout gb = new GridBagLayout();
          GridBagConstraints gbc =new GridBagConstraints();

          jp1.setLayout(gb);
          gbc.weightx=1;
          gbc.weighty=1;
          gbc.gridwidth=1;
          gbc.gridheight=1;

            try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
             st   = con.createStatement();
            String qry21="select  * from student_data ";
             rs1 = st.executeQuery(qry21);
            int i1=0;
            while(rs1.next())
            {  int j1=0;
              while(j1<26)
               {
                 j1++;
               }
             i1++;n++;
            }
          }
           
          catch(Exception e)
         {
          System.out.println("ERRRRRRRR"+e);
         }
          

          final String[] colHeads ={"Roll_no","Name","DOB","Course","Branch","Semester","10th", "12th" ,"Graduation", " Sem I/Year I", " Sem II/Year II"," Sem III/YearIII","Sem IV","Sem V","Sem VI","Sem VII","Sem VIII","Aggregate","PostGradution","Sem I","Sem II","Sem III","Sem IV","Sem V","Sem VI","P_Aggregate"};
          String[][] data=new String[n][26];
          int i=0,j=0;

          v= ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
          h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;

          try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
            Statement st   = con.createStatement();
            String qry11="select student_data.roll_no,name,dob";
            qry11+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry11+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry11+=",psem3,psem4,psem5,psem6,paggregate ";
            qry11+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            JOptionPane.showMessageDialog(this,qry11);
            rs = st.executeQuery(qry11);
            //ResultSet rs = st.executeQuery("select student_data.roll_no,name,category,dob,fathername,course,branch,semester,phone_no,tenth,twelvth,graduation,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2,psem3,psem4,psem5,psem6,paggregate  from student_data,s_marks where student_data.roll_no=s_marks.roll_no");
            System.out.println("Abhi Data Nikal liya");
            while(rs.next())
            {  j=0;
              while(j<26)
               {
                 System.out.println("data array main bheja ja raha hai");
                 String str=rs.getString(j+1);
                 str=str+"                                                ".substring(0,"                                                ".length()-str.length());
                 data[i][j]=str;
                 System.out.println(data[i][j]);
                 j++;
               }
             i++;
            }
            System.out.println("Abhi Data dikha kya");
            }
           catch(Exception e)
            {
                    System.out.println("Error : "+e);
            }
  
          table = new JTable (data,colHeads);
          table.setSize(500,200);
          table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
          jsp= new JScrollPane(table,v,h);

//          jp1.add(jsp);
           cp.add(jsp,"Center");

           JPanel  jp2 = new JPanel();
           Border etched =BorderFactory.createEtchedBorder();
           Border titled = BorderFactory.createTitledBorder(etched, "Criteria Selection");
           jp2.setBorder(titled);

           GridBagLayout gb1 = new GridBagLayout();
           GridBagConstraints gbc1 =new GridBagConstraints();
 
           jp2.setLayout(gb1);
           gbc1.weightx=1;
           gbc1.weighty=1;
           gbc1.gridheight=1;
           gbc1.gridwidth=1;

           JLabel jl1=new JLabel("Percent in X             ");
           gbc1.gridx=0;
           gbc1.gridy=1;
           jp2.add(jl1,gbc1);

           gbc1.gridx  =  1;
           gbc1.gridy   = 1;
           jt1 =  new JTextField(15);
           jp2.add(jt1,gbc1);

           JLabel jl2=new JLabel("Percent in XII          ");
           gbc1.gridx=0;
           gbc1.gridy=2;
           jp2.add(jl2,gbc1);

           gbc1.gridx  =  1;
           gbc1.gridy   = 2;
           jt2 =  new JTextField(15);
           jp2.add(jt2,gbc1);

           JLabel jl3=new JLabel("Percent in Graduation    ");
           gbc1.gridx=0;
           gbc1.gridy=3;
           jp2.add(jl3,gbc1);

           gbc1.gridx  =  1;
           gbc1.gridy   = 3;
           jt3 =  new JTextField(15);
           jp2.add(jt3,gbc1);

           JLabel jl4=new JLabel("Percent in PostGraduation");
           gbc1.gridx=0;
           gbc1.gridy=4;
           jp2.add(jl4,gbc1);

           gbc1.gridx  =  1;
           gbc1.gridy   = 4;
          jt4 =  new JTextField(15);
          jp2.add(jt4,gbc1);

           JLabel jl5=new JLabel("Age                      ");
           gbc1.gridx=0;
           gbc1.gridy=5;
           jp2.add(jl5,gbc1);

           gbc1.gridx  =  1;
           gbc1.gridy   = 5;
           jt5= new JTextField(15);
           jp2.add(jt5,gbc1);

           JLabel jl6=new JLabel("Branch                   ");
           gbc1.gridx=0;
           gbc1.gridy=6;
           jp2.add(jl6,gbc1);
 
           gbc1.gridx  =  1;
           gbc1.gridy   = 6;
        jc1 =  new JComboBox();
           jc1.addItem("-");
           jc1.addItem("Information Tecnology");
           jc1.addItem("Electronics & Telecommunication");
           jc1.addItem("Electrical");
           jc1.addItem("Mechanical");
           jc1.addItem("Civil");
           jc1.addItem("Industrial Production");
           jc1.addItem("ComputerScience");
           jc1.addItem("M.C.A");

        jp2.add(jc1,gbc1);

        JLabel jl7=new JLabel("Semester                 ");
        gbc1.gridx=0;
        gbc1.gridy=7;
        jp2.add(jl7,gbc1);

        gbc1.gridx  =  1;
        gbc1.gridy   = 7;
       jc2 =  new JComboBox();
           jc2.addItem("-");
           jc2.addItem("I");
           jc2.addItem("II");
           jc2.addItem("III");
           jc2.addItem("IV");
           jc2.addItem("V");
           jc2.addItem("VI");
           jc2.addItem("VII");
           jc2.addItem("VIII");


       jp2.add(jc2,gbc1);


       jb1=new JButton("Exit");
       gbc1.gridx=0;
       gbc1.gridy=9;
       jb1.addActionListener(this);
       jp2.add(jb1,gbc1);

       gbc1.gridx  =  1;
       gbc1.gridy   = 9;
       jb2 =  new JButton("OK");

      jb2.addActionListener(this);
      jp2.add(jb2,gbc1);
       

      cp.add(jp2,"South");





       setVisible(true);
}  
            
  public void  actionPerformed(ActionEvent ae)
    {
         int i1=0;int flag=0;int flag1=0;
          final String[] colHeads ={"Roll_no","Name","DOB","Course","Branch","Semester","10th", "12th" ,"Graduation", " Sem I/Year I", " Sem II/Year II"," Sem III/YearIII","Sem IV","Sem V","Sem VI","Sem VII","Sem VIII","Aggregate","PostGradution","Sem I","Sem II","Sem III","Sem IV","Sem V","Sem VI","P_Aggregate"};
       Object source=ae.getSource();
       if (source == jb2)
       try
       {
        
            String[][] data=new String[n][26];
         if (!jt1.getText().equals("") &&jt2.getText().equals("")&&jt3.getText().equals("")&&jt4.getText().equals("")&&jt5.getText().equals("")&&jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry="select student_data.roll_no,name,dob";
            qry+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry+=",psem3,psem4,psem5,psem6,paggregate ";
            qry+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry+="and tenth >="+ jt1.getText();
            rs = st.executeQuery(qry);

         }
         if (jt1.getText().equals("") &&!jt2.getText().equals("")&&jt3.getText().equals("")&&jt4.getText().equals("")&&jt5.getText().equals("")&&jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry1="select student_data.roll_no,name,dob";
            qry1+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry1+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry1+=",psem3,psem4,psem5,psem6,paggregate ";
            qry1+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry1+="and twelvth >="+ jt2.getText();
            rs = st.executeQuery(qry1);

         }
         if (jt1.getText().equals("") &&jt2.getText().equals("")&&!jt3.getText().equals("")&&jt4.getText().equals("")&&jt5.getText().equals("")&&jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry2="select student_data.roll_no,name,dob";
            qry2+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry2+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry2+=",psem3,psem4,psem5,psem6,paggregate ";
            qry2+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry2+="and Aggregate >="+ jt3.getText();
            rs = st.executeQuery(qry2);

         }

         if (jt1.getText().equals("") &&jt2.getText().equals("")&&jt3.getText().equals("")&&!jt4.getText().equals("")&&jt5.getText().equals("")&&jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry3="select student_data.roll_no,name,dob";
            qry3+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry3+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry3+=",psem3,psem4,psem5,psem6,paggregate ";
            qry3+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry3+="and paggregate >="+ jt4.getText();
            rs = st.executeQuery(qry3);

         }
        
          
         if (jt1.getText().equals("") &&jt2.getText().equals("")&&jt3.getText().equals("")&&jt4.getText().equals("")&&jt5.getText().equals("")&&!jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry4="select student_data.roll_no,name,dob";
            qry4+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry4+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry4+=",psem3,psem4,psem5,psem6,paggregate";
            qry4+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry4+="and branch='"+jc1.getSelectedItem()+"'";
            rs = st.executeQuery(qry4);

         }
         
         if (jt1.getText().equals("") &&jt2.getText().equals("")&&jt3.getText().equals("")&&jt4.getText().equals("")&&jt5.getText().equals("")&&jc1.getSelectedItem().equals("-")&&!jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry5="select student_data.roll_no,name,dob";
            qry5+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry5+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry5+=",psem3,psem4,psem5,psem6,paggregate ";
            qry5+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry5+="and semester='"+ jc2.getSelectedItem()+"'";
            rs = st.executeQuery(qry5);

         }

         if (!jt1.getText().equals("") &&!jt2.getText().equals("")&&jt3.getText().equals("")&&jt4.getText().equals("")&&jt5.getText().equals("")&&jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry6="select student_data.roll_no,name,dob";
            qry6+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry6+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry6+=",psem3,psem4,psem5,psem6,paggregate ";
            qry6+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry6+="and tenth >="+jt1.getText();
            qry6+="and twelvth >="+jt2.getText();
            rs = st.executeQuery(qry6);

         }

          
          if (!jt1.getText().equals("") &&!jt2.getText().equals("")&&!jt3.getText().equals("")&&jt4.getText().equals("")&&jt5.getText().equals("")&&jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry7="select student_data.roll_no,name,dob";
            qry7+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry7+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry7+=",psem3,psem4,psem5,psem6,paggregate ";
            qry7+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry7+="and tenth >="+jt1.getText();
            qry7+="and twelvth >="+jt2.getText();
            qry7+="and aggregate >="+jt3.getText();
            rs = st.executeQuery(qry7);

         }

          if (!jt1.getText().equals("") &&!jt2.getText().equals("")&&!jt3.getText().equals("")&&!jt4.getText().equals("")&&jt5.getText().equals("")&&jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry8="select student_data.roll_no,name,dob";
            qry8+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry8+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry8+=",psem3,psem4,psem5,psem6,paggregate ";
            qry8+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry8+="and tenth >="+jt1.getText();
            qry8+="and twelvth >="+jt2.getText();
            qry8+="and aggregate >="+jt3.getText();
            qry8+="and paggregate >="+jt4.getText();
            rs = st.executeQuery(qry8);

         }

         if (!jt1.getText().equals("") &&!jt2.getText().equals("")&&!jt3.getText().equals("")&&!jt4.getText().equals("")&&jt5.getText().equals("")&&!jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry9="select student_data.roll_no,name,dob";
            qry9+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry9+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry9+=",psem3,psem4,psem5,psem6,paggregate ";
            qry9+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry9+="and tenth >="+jt1.getText();
            qry9+="and twelvth >="+jt2.getText();
            qry9+="and aggregate >="+jt3.getText();
            qry9+="and paggregate >="+jt4.getText();
            qry9+="and branch ='"+ jc1.getSelectedItem()+"' ";
            rs = st.executeQuery(qry9);

         }
          

          if (!jt1.getText().equals("") &&!jt2.getText().equals("")&&!jt3.getText().equals("")&&jt4.getText().equals("")&&jt5.getText().equals("")&&!jc1.getSelectedItem().equals("-")&&jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry10="select student_data.roll_no,name,dob";
            qry10+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry10+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry10+=",psem3,psem4,psem5,psem6,paggregate ";
            qry10+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry10+="and tenth >="+jt1.getText();
            qry10+="and twelvth >="+jt2.getText();
            qry10+="and aggregate >="+jt3.getText();
            qry10+="and branch ='"+jc1.getSelectedItem()+"' ";
            rs = st.executeQuery(qry10);

         }
   
          
           if (!jt1.getText().equals("") &&!jt2.getText().equals("")&&!jt3.getText().equals("")&&!jt4.getText().equals("")&&jt5.getText().equals("")&&!jc1.getSelectedItem().equals("-")&&!jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry12="select student_data.roll_no,name,dob";
            qry12+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry12+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry12+=",psem3,psem4,psem5,psem6,paggregate ";
            qry12+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry12+="and tenth >="+jt1.getText();
            qry12+="and twelvth >="+jt2.getText();
            qry12+="and aggregate >="+jt3.getText();
            qry12+="and paggregate >="+jt4.getText();
            qry12+="and branch ='"+jc1.getSelectedItem()+"' ";
            qry12+="and semester ='"+jc2.getSelectedItem()+"' ";
            rs = st.executeQuery(qry12);

         }
   
            if (!jt1.getText().equals("") &&!jt2.getText().equals("")&&!jt3.getText().equals("")&&jt4.getText().equals("")&&jt5.getText().equals("")&&!jc1.getSelectedItem().equals("-")&&!jc2.getSelectedItem().equals("-"))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry13="select student_data.roll_no,name,dob";
            qry13+=",course,branch,semester,tenth,twelvth,graduation,sem1,sem2";
            qry13+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry13+=",psem3,psem4,psem5,psem6,paggregate ";
            qry13+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry13+="and tenth >="+jt1.getText();
            qry13+="and twelvth >="+jt2.getText();
            qry13+="and aggregate >="+jt3.getText();
            qry13+="and branch ='"+jc1.getSelectedItem()+"' ";
            qry13+="and semester ='"+jc2.getSelectedItem()+"' ";
            rs = st.executeQuery(qry13);

         }
   
           
       //System.out.println(qry12);
            
            while(rs.next())
           {  flag=1;flag1=1;
                    int  j1=0;
                    while(j1<26)
                    {

                 String str1=rs.getString(j1+1);
          str1=str1+"                                                ".substring(0,"                                                ".length()-str1.length());
          data[i1][j1]=str1;

                              j1++;
                    }
                    i1++;
              setSize(800,800);
          }
            cp.remove(jsp);
           table = new JTable (data,colHeads);
           table.setSize(500,200);
           table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
           jsp= new JScrollPane(table,v,h);

          cp.add(jsp,"Center");
          if(flag1==0)
          {
            JOptionPane.showMessageDialog(this,"Sorry! no records");
            setSize(800,800);
          }
             

         if(flag==1)
        {
          setSize(850,850);
          flag=0;
        }
       }
      catch(Exception e)
       {} 
   
  } 
  
}


