class common
{
	int n;
	int flag=0;
	synchronized void storeVal(int n)
	{
		if (flag==1)
		{	
			try
			{
                                System.out.println("Waiting Thraed Put");
				wait();
			}
			catch(Exception e){}
		}
		this.n=n;
		flag=1;
		try
		{
			notify();
		}
		catch(Exception e){}
	}
	
	synchronized int pickVal()
	{
		if (flag==0)
		{
			try
			{
                                System.out.println("Waiting Thraed Get");
				wait();
			}
			catch(Exception e){}
		}
		flag=0;
		try
		{
			notify();
		}
		catch(Exception e){}
		return n;
	}
}
class febot extends Thread
{
	common p;
	febot(common p)
	{
		super("Febo Thread");
		start();
		this.p=p;
	}
	public void run()
	{
		int n=5,i,a,b,c;
		a=1;b=1;
		for(i=1;i<=11;i++)
		{
			c=a+b;
			a=b;
			b=c;
			System.out.print("Febo : "+c);
			p.storeVal(c);
			try
			{
				sleep(10);
			}
			catch(InterruptedException ie)
			{}
		}
	}
}

class Star_t extends Thread
{
	common p;
	Star_t(common p)
	{
		super("Star Thread");
		start();
		this.p=p;
	}
	public void run()
	{		
		int n,i,j;
		for(j=1;j<=11;j++)
		{
			n=p.pickVal();
			for(i=1;i<=n*3;i++)
			{
				System.out.print("*");
			}
			System.out.println("");
			try
			{
				sleep(10);
			}
			catch(InterruptedException ie)
			{}
		}
	}
}

class myTwot2
{
	public static void main(String args[])
	{
		String  s;
		common p=new common();
		febot t1=new febot(p);
		Star_t t2=new Star_t(p);
		try
		{
			t1.join();
			t2.join();
		}
		catch(Exception e){}
		System.out.print("\nEhhhh !!! Ab Sara Kaam Khatam");
	}
}
