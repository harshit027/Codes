import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class MySessionURL1 extends HttpServlet
{
	public void doGet(HttpServletRequest request, HttpServletResponse response) throws  ServletException, IOException
	{
		PrintWriter pw = response.getWriter();
		String uid=request.getParameter("uid");
		String pwd=request.getParameter("pwd");
		if(uid.equals("PACE") && pwd.equals("BUREAU"))
		{
			String resp="<h1>Congratulations You Are AUTHORISED User</h1>";
			resp+="<h2><a href='MySessionURL.html'>Click Here to Move to First Page</a></h2>";
			pw.println(resp);
		}
		else
		{
			String resp="<h1>Sorry !!! Wrong UserName </h1>";
			resp+="<h2><a href='MySessionURL.html'>Click Here to RE-ENTER</a></h2>";
			pw.println(resp);
		}
		pw.close();
	}
}