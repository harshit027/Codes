import javax.servlet.*;
import java.io.*;
import java.util.*;

public class MyServlet extends GenericServlet
{
	public void service(ServletRequest request, ServletResponse response) throws ServletException, UnavailableException, IOException
	{
		PrintWriter pw = response.getWriter();
		Enumeration e = request.getParameterNames();
		while(e.hasMoreElements())
		{
			String param =(String) e.nextElement();
			String value = request.getParameter(param);
			pw.print("Name : "+param ++          +"\t Value : "+value);
		}
		pw.close();
	}
}