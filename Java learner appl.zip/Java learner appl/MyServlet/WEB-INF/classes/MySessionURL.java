import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class MySessionURL extends HttpServlet
{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws  ServletException, IOException
	{
		PrintWriter pw = response.getWriter();
		String uid=request.getParameter("uid");
		String pwd=request.getParameter("pwd");
		if(uid.equals("PACE") && pwd.equals("BUREAU"))
		{
			String resp="<h1>Congratulations You Are AUTHORISED User</h1>";
			resp+="<h2><a href='http://localhost:8080/MyServlet/servlet/MySessionURL1?uid="+uid+"&pwd="+pwd+"'>Click Here to Move to Next Page</a></h2>";
			pw.println(resp);
		}
		else
		{
			String resp="<h1>Sorry !!! Wrong UserName </h1>";
			resp+="<h2><a href='http://localhost:8080/MyServlet/MySessionURL.html'>Click Here to RE-ENTER</a></h2>";
			pw.println(resp);
		}
		pw.close();
	}
}