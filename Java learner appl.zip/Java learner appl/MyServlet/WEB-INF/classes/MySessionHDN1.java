import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class MySessionHDN1 extends HttpServlet
{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws  ServletException, IOException
	{
		PrintWriter pw = response.getWriter();
		String uid=request.getParameter("uid");
		String pwd=request.getParameter("pwd");
		String resp="";
		resp+="<html><head>";
		resp+="<script language='javascript'>";
		resp+="function mySubmit()";
		resp+="{";
		resp+="	f1.action='http://localhost:8080/MyServlet/WEB-INF/classes/MySessionHDN.html';";
		resp+="	f1.submit();";
		resp+="}";
		resp+="function mySubmit1()";
		resp+="{";
		resp+="	f1.action='http://localhost:8080/MyServlet/WEB-INF/classes/MySessionHDN.html';";
		resp+="	f1.submit();";
		resp+="}";
		resp+="</script>";
		resp+="</head>";
		resp+="<body bgColor=rajneesh>";
		resp+="<form name='f1' method=post>";
		if(uid.equals("PACE") && pwd.equals("BUREAU"))
		{
			resp+="<h1>Congratulations You Are AUTHORISED User</h1>";
			resp+="<h2><a href='javascript:mySubmit()'>Click Here to Move to Next Page</a></h2>";
		}
		else
		{
			resp+="<h1>Sorry !!! Wrong UserName </h1>";
			resp+="<h2><a href='javascript:mySubmit1()'>Click Here to RE-ENTER</a></h2>";
		}
		resp+="</form>";
		resp+="</body>";
		resp+="</html>";
		pw.println(resp);
		pw.close();
	}
}