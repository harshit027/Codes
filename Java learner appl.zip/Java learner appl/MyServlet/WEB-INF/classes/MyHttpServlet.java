import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;
import java.util.*;

public class MyHttpServlet extends HttpServlet
{
	public void doPost(HttpServletRequest request, HttpServletResponse response) throws  ServletException, IOException
	{
		PrintWriter pw = response.getWriter();
		Enumeration e = request.getParameterNames();
		while(e.hasMoreElements())
		{
			String param =(String) e.nextElement();
			String value = request.getParameter(param);
			pw.print("Name : "+param +"\t Value : "+value);
		}
		pw.close();
	}
}