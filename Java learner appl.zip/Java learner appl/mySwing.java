import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/*
	<applet code="mySwing.class" width=500 height=400>
	</applet>
*/

public class mySwing extends JApplet
				implements ActionListener
{
	JLabel lbl;
	JButton btn;
	JTextField jtf;
	public void init()
	{
		ImageIcon ico,ico1,ico2;
		ico=new ImageIcon("hlpcd.gif");
		ico1=new ImageIcon("hlpglobe.gif");
		ico2=new ImageIcon("hlpbell.gif");
		lbl=new JLabel("Enter Text",ico,JLabel.RIGHT);
		btn=new JButton("Reverse the String in Text",ico1);
		btn.setRolloverIcon(ico2);
		btn.setPressedIcon(ico);
		jtf=new JTextField("PACE BUREAU",40);
		Container c = getContentPane();
		c.setLayout(new FlowLayout());
		c.add(lbl);
		c.add(jtf);
		c.add(btn);
		c.setBackground(Color.orange);
		btn.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		StringBuffer s=new StringBuffer(jtf.getText());
		s.reverse();
		String str=s.toString();
		jtf.setText(str);
	}
}

