import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;


   class student_detail1 extends JFrame
    {

      Container cp;
      JLabel jl1,jl2,jl3,jl4,jl5,jl6,jl7,jl8,jl9,jl10,njl1,njl2,njl3,njl4,njl5,njl6,njl7,njl8,njl9,njl10,njl11,njl12,njl13,njl43,njl44,njl45,njl46,njl47,njl48,njl49,njl410,njl411;
      JTextField jt1,jt2,jt3,jt4,jt5,njt1,njt2,njt3,njt4,njt5,njt6,njt7,njt8,njt9,njt10 ;
      JTextField njt11,njt12,njt13,njt43,njt44,njt45,njt46,njt47,njt48,njt49,njt410,njt411;
      TextArea jta1;
      JComboBox jc1,jc2,jc3,jc4,jc5,jc6;
      ButtonGroup group21,group22;
      JRadioButton be,bsc,bcom,bca,mca,me;
      JButton jb1,jb2;
      public static void main(String args[])
      {
           new student_detail1();
       }

      student_detail1()
      {
           super("students_details");
//           getContentPane().setLayout(new BorderLayout(0,0));

           WindowListener l=new WindowAdapter()
             {
               public void windowClosing(WindowEvent we)
                {
                    System.exit(0);
                 }
             };
            addWindowListener(l);
           cp=getContentPane();

           JPanel  jp1;
           jp1=new JPanel();

           Border etched =BorderFactory.createEtchedBorder();
           Border titled = BorderFactory.createTitledBorder(etched, "Personal Information");
           jp1.setBorder(titled);
           GridBagLayout gb=new GridBagLayout();
           GridBagConstraints gbc = new GridBagConstraints();
           jp1.setLayout(gb);

           gbc.gridwidth=1;
           gbc.gridheight=1;
           gbc.weightx=1;
           gbc.weighty=1;

           jl1=new JLabel("Roll_no");
           jl2=new JLabel("Name");
           jl3=new JLabel("Category");
           jl4=new JLabel("Date_Of_Birth");
           jl5=new JLabel("Father Name");
           jl6=new JLabel("Address");
           jl7=new JLabel("Email_id");
           jl8=new JLabel("Course");
           jl9=new JLabel("Branch");
           jl10=new JLabel("Semester");

           jt1 = new JTextField(15);
           jt2 = new JTextField(15);
           jt3 = new JTextField(15);
           jt4 = new JTextField(15);
           jt5 = new JTextField(15);

           jta1 = new TextArea(2,15);

           jc1 = new JComboBox();
           jc2 = new JComboBox();
           jc3 = new JComboBox();
           jc4 = new JComboBox();
           jc5 = new JComboBox();
           jc6 = new JComboBox();

           for(int i =1;i<=31;i++)
             {
               jc1.addItem(i+"");
            }

           jc2.addItem("January");
           jc2.addItem("February");
           jc2.addItem("March");
           jc2.addItem("April");
           jc2.addItem("May");
           jc2.addItem("June");
           jc2.addItem("July");
           jc2.addItem("August");
           jc2.addItem("September");
           jc2.addItem("October");
           jc2.addItem("November");
           jc2.addItem("December");

           for(int k=1975;k<=2030;k++)
            {
              jc3.addItem(k+"");
            }

           jc4.addItem("M.C.A.");
           jc4.addItem("B.E.");
           jc4.addItem("M.E.");

           jc5.addItem("Information Tecnology");
           jc5.addItem("Electronics & Telecommunication");
           jc5.addItem("Electrical");
           jc5.addItem("Mecanical");
           jc5.addItem("Civil");
           jc5.addItem("Industrial Production");
           jc5.addItem("ComputerScience");
           jc5.addItem("M.C.A");

           jc6.addItem("I");
           jc6.addItem("II");
           jc6.addItem("III");
           jc6.addItem("IV");
           jc6.addItem("V");
           jc6.addItem("VI");
           jc6.addItem("VII");
           jc6.addItem("VIII");


           gbc.gridx=1;
           gbc.gridy=3;
           jp1.add(jl1,gbc);

           gbc.gridx=5;
           gbc.gridy=3;
           jp1.add(jt1,gbc);

           gbc.gridx=15;
           gbc.gridy= 3;
           jp1.add(jl2,gbc);

           gbc.gridx=19;
           gbc.gridy=3;
           jp1.add(jt2,gbc);

           gbc.gridx=1;
           gbc.gridy=4;
           jp1.add(jl3,gbc);

           gbc.gridx=5;
           gbc.gridy=4;
           jp1.add(jt3,gbc);

           gbc.gridx=15;
           gbc.gridy=4;
           jp1.add(jl4,gbc);

           gbc.gridx=19;
           gbc.gridy=4;
           jp1.add(jc1,gbc);

           gbc.gridx=20;
           gbc.gridy=4;
           jp1.add(jc2,gbc);

           gbc.gridx=21;
           gbc.gridy=4;
           jp1.add(jc3,gbc);

           gbc.gridx=1;
           gbc.gridy=5;
           jp1.add(jl5,gbc);

           gbc.gridx=5;
           gbc.gridy=5;
           jp1.add(jt4,gbc);

           gbc.gridx=15;
           gbc.gridy=5;
           jp1.add(jl7,gbc);

           gbc.gridx=19;
           gbc.gridy=5;
           jp1.add(jt5,gbc);

           gbc.gridx=1;
           gbc.gridy=6;
           jp1.add(jl6,gbc);

           gbc.gridx =5;
           gbc.gridy =6;
           jp1.add(jta1,gbc);

           gbc.gridx = 1;
           gbc.gridy = 8;
           jp1.add(jl8,gbc);

           gbc.gridx = 5;
           gbc.gridy = 8;
           jp1.add(jc4,gbc);

           gbc.gridx = 14;
           gbc.gridy = 8;
           jp1.add(jl9,gbc);

           gbc.gridx = 18;
           gbc.gridy = 8;
           jp1.add(jc5,gbc);

           gbc.gridx = 22;
           gbc.gridy = 8;
           jp1.add(jl10,gbc);

           gbc.gridx = 26;
           gbc.gridy = 8;
           jp1.add(jc6,gbc);

           JPanel jp2 =new JPanel();
           Border etched1 =BorderFactory.createEtchedBorder();
           Border titled1 = BorderFactory.createTitledBorder(etched1, "Academic Records");
           jp2.setBorder(titled1);

           GridBagLayout gb1=new GridBagLayout();
           GridBagConstraints gbc1 = new GridBagConstraints();
           jp2.setLayout(gb1);

           gbc1.gridwidth=1;
           gbc1.gridheight=1;
           gbc1.weightx=1;
           gbc1.weighty=1;

           njl1 = new JLabel("10th");
           njl2 = new JLabel("12th");

           njt1 = new JTextField(15);
           njt2 = new JTextField(15);

           gbc1.gridx=1;
           gbc1.gridy= 10;
           jp2.add(njl1,gbc1);

           gbc1.gridx=2;
           gbc1.gridy= 10;
           jp2.add(njt1,gbc1);

           gbc1.gridx=1;
           gbc1.gridy= 13;
           jp2.add(njl2,gbc1);

           gbc1.gridx=2;
           gbc1.gridy= 13;
           jp2.add(njt2,gbc1);

           JPanel jp21 =new JPanel();
           Border etched21 =BorderFactory.createEtchedBorder();
           Border titled21= BorderFactory.createTitledBorder(etched21, "Graduation");
           jp21.setBorder(titled21);
           GridBagLayout gb21=new GridBagLayout();
           GridBagConstraints gbc21 = new GridBagConstraints();

           jp21.setLayout(gb21);
           gbc21.gridwidth=1;
           gbc21.gridheight=1;
           gbc21.weightx=1;
           gbc21.weighty=1;


           group21 = new ButtonGroup();
           be =new JRadioButton("B.E.",true);
           group21.add(be);
           bsc= new JRadioButton("B.Sc ",false);
           group21.add(bsc);
           bcom=new JRadioButton("B.Com",false);
           group21.add(bcom);
           bca=new JRadioButton("B.C.A",false);
           group21.add(bca);

           gbc21.gridx=1;
           gbc21.gridy=15 ;
           jp21.add(be,gbc21);

           gbc21.gridx=1;
           gbc21.gridy=16;
           jp21.add(bsc,gbc21);

           gbc21.gridx=1;
           gbc21.gridy=17;
           jp21.add(bcom,gbc21);

           gbc21.gridx=1;
           gbc21.gridy=17;
           jp21.add(bca,gbc21);

           gbc1.gridx=5;
           gbc1.gridy=14;
           jp2.add(jp21,gbc1);

           JPanel jp22 =new JPanel();
           Border etched22 =BorderFactory.createEtchedBorder();
           Border titled22= BorderFactory.createTitledBorder(etched22, "Post_Graduation");
           jp22.setBorder(titled22);
           GridBagLayout gb22=new GridBagLayout();
           GridBagConstraints gbc22 = new GridBagConstraints();

           jp22.setLayout(gb22);
           gbc22.gridwidth=1;
           gbc22.gridheight=1;
           gbc22.weightx=1;
           gbc22.weighty=1;


           group22 = new ButtonGroup();
           mca =new JRadioButton("M.C.A",true);
           group22.add(mca);
           me= new JRadioButton("M.E",false);
           group22.add(me);

           gbc22.gridx=5;
           gbc22.gridy=15 ;
           jp22.add(mca,gbc22);

           gbc22.gridx=5;
           gbc22.gridy=16;
           jp22.add(me,gbc22);

           gbc1.gridx=10;
           gbc1.gridy=14;
           jp2.add(jp22,gbc1);

           JPanel jp23 =new JPanel();
           Border etched23 =BorderFactory.createEtchedBorder();
           Border titled23= BorderFactory.createTitledBorder(etched23, "Graduation_details");
           jp23.setBorder(titled23);
           GridBagLayout gb23=new GridBagLayout();
           GridBagConstraints gbc23 = new GridBagConstraints();

           jp23.setLayout(gb23);
           gbc23.gridwidth=1;
           gbc23.gridheight=1;
           gbc23.weightx=1;
           gbc23.weighty=1;

           njl3 = new JLabel(" I sem");
           njl4 = new JLabel(" II sem");
           njl5 = new JLabel(" III sem");
           njl6 = new JLabel(" IV sem");
           njl7 = new JLabel(" V sem");
           njl8 = new JLabel(" VI sem");
           njl9 = new JLabel(" VII sem");
           njl10 = new JLabel(" VIII sem");
           njl11 = new JLabel("Grand_Total");
           njl12 = new JLabel("Out_Off");
           njl13 = new JLabel("Aggregate");

           njt3 = new JTextField(5);
           njt4 = new JTextField(5);
           njt5 = new JTextField(5);
           njt6 = new JTextField(5);
           njt7 = new JTextField(5);
           njt8 = new JTextField(5);
           njt9 = new JTextField(5);
           njt10 = new JTextField(5);
           njt11 = new JTextField(5);
           njt12 = new JTextField(5);
           njt13 = new JTextField(5);

           gbc23.gridx=0;
           gbc23.gridy=1;
           jp23.add(njl3,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=1;
           jp23.add(njt3,gbc23);

           gbc23.gridx=2;
           gbc23.gridy=1;
           jp23.add(njl4,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=1;
           jp23.add(njt4,gbc23);

           gbc23.gridx=0;
           gbc23.gridy=2;
           jp23.add(njl5,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=2;
           jp23.add(njt5,gbc23);

           gbc23.gridx=2;
           gbc23.gridy=2;
           jp23.add(njl6,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=2;
           jp23.add(njt6,gbc23);

           gbc23.gridx=0;
           gbc23.gridy=3;
           jp23.add(njl7,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=3;
           jp23.add(njt7,gbc23);

           gbc23.gridx=2;
           gbc23.gridy=3;
           jp23.add(njl8,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=3;
           jp23.add(njt8,gbc23);

           gbc23.gridx=0;
           gbc23.gridy=4;
           jp23.add(njl9,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=4;
           jp23.add(njt9,gbc23);

           gbc23.gridx=2;
           gbc23.gridy=4;
           jp23.add(njl10,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=4;
           jp23.add(njt10,gbc23);


           gbc23.gridx=0;
           gbc23.gridy=5;
           jp23.add(njl11,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=5;
           jp23.add(njt11,gbc23);

           gbc23.gridx=2;
           gbc23.gridy=5;
           jp23.add(njl12,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=5;
           jp23.add(njt12,gbc23);

           gbc23.gridx=0;
           gbc23.gridy=6;
           jp23.add(njl13,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=6;
           jp23.add(njt13,gbc23);

           gbc1.gridx=1;
           gbc1.gridy=40;
           jp2.add(jp23,gbc1);

           JPanel jp24 =new JPanel();
           Border etched24 =BorderFactory.createEtchedBorder();
           Border titled24= BorderFactory.createTitledBorder(etched24, "Post_Graduation_details");
           jp24.setBorder(titled24);
           GridBagLayout gb24=new GridBagLayout();
           GridBagConstraints gbc24 = new GridBagConstraints();

           jp24.setLayout(gb24);
           gbc24.gridwidth=1;
           gbc24.gridheight=1;
           gbc24.weightx=1;
           gbc24.weighty=1;

           njl43 = new JLabel(" I sem");
           njl44 = new JLabel(" II sem");
           njl45 = new JLabel(" III sem");
           njl46 = new JLabel(" IV sem");
           njl47 = new JLabel(" V sem");
           njl48 = new JLabel(" VI sem");
           njl49 = new JLabel("Grand_Total");
           njl410 = new JLabel(" Out_Off");
           njl411 = new JLabel("Aggregate");


           njt43 = new JTextField(5);
           njt44 = new JTextField(5);
           njt45 = new JTextField(5);
           njt46 = new JTextField(5);
           njt47 = new JTextField(5);
           njt48 = new JTextField(5);
           njt49 = new JTextField(5);
           njt410 = new JTextField(5);
           njt411 = new JTextField(5);

           gbc24.gridx=0;
           gbc24.gridy=1;
           jp24.add(njl43,gbc24);

           gbc24.gridx=1;
           gbc24.gridy=1;
           jp24.add(njt43,gbc24);

           gbc24.gridx=2;
           gbc24.gridy=1;
           jp24.add(njl44,gbc24);
           gbc24.gridx=3;
           gbc24.gridy=1;
           jp24.add(njt44,gbc24);

           gbc24.gridx=0;
           gbc24.gridy=2;
           jp24.add(njl45,gbc24);

           gbc24.gridx=1;
           gbc24.gridy=2;
           jp24.add(njt45,gbc24);

           gbc24.gridx=2;
           gbc24.gridy=2;
           jp24.add(njl46,gbc24);

           gbc24.gridx=3;
           gbc24.gridy=2;
           jp24.add(njt46,gbc24);

           gbc24.gridx=0;
           gbc24.gridy=3;
           jp24.add(njl47,gbc24);

           gbc24.gridx=1;
           gbc24.gridy=3;
           jp24.add(njt47,gbc24);

           gbc24.gridx=2;
           gbc24.gridy=3;
           jp24.add(njl48,gbc24);

           gbc24.gridx=3;
           gbc24.gridy=3;
           jp24.add(njt48,gbc24);

           gbc24.gridx=0;
           gbc24.gridy=4;
           jp24.add(njl49,gbc24);

           gbc24.gridx=1;
           gbc24.gridy=4;
           jp24.add(njt49,gbc24);

           gbc24.gridx=2;
           gbc24.gridy=4;
           jp24.add(njl410,gbc24);

           gbc24.gridx=3;
           gbc24.gridy=4;
           jp24.add(njt410,gbc24);

           gbc24.gridx=0;
           gbc24.gridy=5;
           jp24.add(njl411,gbc24);

           gbc24.gridx=1;
           gbc24.gridy=5;
           jp24.add(njt411,gbc24);


           gbc1.gridx=2;
           gbc1.gridy=40;
           jp2.add(jp24,gbc1);


           jb1 = new JButton("SUBMIT");
           jb2 = new JButton("CANCEL");

           gbc1.gridx=1;
           gbc1.gridy=60;
           jp2.add(jb1,gbc1);

           gbc1.gridx=2;
           gbc1.gridy=60;
           jp2.add(jb2,gbc1);

           cp.add(jp1,"North");

           cp.add(jp2,"South");

           setSize(800,800);
           setVisible(true);

   }

}



