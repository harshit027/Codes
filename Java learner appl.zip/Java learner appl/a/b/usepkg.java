import pkg.*;

class usepkg
{
        public static void main(String args[])
        {
                myPackage m=new myPackage();
                m.show("PACE BUREAU");
        }

}
