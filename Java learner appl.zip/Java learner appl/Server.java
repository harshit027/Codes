import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

class Server extends Frame
{
	Server()
	{
		super("MyIP");
		setSize(400,400);
		try
		{
			ServerSocket ss = new ServerSocket(2000);
			while(true)
			{
				Socket s=ss.accept();
				System.out.println("Client Connected : "+s);
				new MyServerThread(s);
			}

		}
		catch(Exception e)
		{
		}
	}
	public static void main(String args[])
	{
		new Server();
	}
}

class MyServerThread extends Thread
{
	Socket client;

	MyServerThread(Socket s)
	{
		client = s;
		start();
	}
	public void run()
	{
		try
		{
			PrintWriter pw = new PrintWriter(client.getOutputStream(),true);
			BufferedReader clientbr = new BufferedReader(new InputStreamReader(client.getInputStream()));
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			while(true)
			{
				System.out.println("Enter Message  :");
				String str=br.readLine();
				pw.println(str);
				str=clientbr.readLine();
				System.out.println(str);
			}
		}
		catch(Exception e)
		{}
	}
}