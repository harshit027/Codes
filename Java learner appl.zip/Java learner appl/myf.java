import java.applet.*;
import java.awt.*;
/*
	<applet code="myFont1.class" width=300 height=400>
	</applet>
*/

public class myFont1 extends Applet
{	
       	public void paint(Graphics g)
        {
         setBackground(Colour.yellow);

         setForeground(Colour.red);
         GraphicsEnvironment ge=GraphicsEnvironment.getLocalGraphicsEnvironment();
         String s[]=ge.getAvailableFontFamilyName();
         int k=0;
           while(true)
           {
                     if (k>10)
                     {
                       g.drawString(s[k],100,j);
                      }
                    else
                     {
                       g.drawString(s[k],10,j);
                      if(k==10)
                       j=40;
                     }
                       k++;
                      j=j+10;
     }
          }




