import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
public class company_details extends JFrame implements ActionListener
 {
        Container cp;
        JTextField jt1,jt2,jt3,jt4,jt5;
        JComboBox jc1,jc2;
        JButton jb1,jb2;
        Connection con;
        Statement st;
        ResultSet rs,rs1;
          public static void main(String args[])
           { 
           new company_details();
            }

  public company_details()
  {
   super("COMPANY_DETAILS");
   setSize(600,600);
   setVisible(true);
 
  //jframe.resizeable(false);
  WindowListener l = new WindowAdapter()
  {
   public void windowClosing(WindowEvent we)
   {
    System.exit(0);
   }
  };
 addWindowListener(l);

 GridBagLayout gb = new GridBagLayout();
 GridBagConstraints gbc = new GridBagConstraints();
  cp =getContentPane();
 JPanel jp = new JPanel();

 jp.setLayout(gb);
 jp.setBorder(BorderFactory.createCompoundBorder());
 gbc.gridwidth=1;
 gbc.gridheight=1;
 gbc.weightx=0.1;
 gbc.weighty=0.1; 

 JLabel jl1 = new JLabel("Company_id"); 
 JLabel jl2 = new JLabel("Company_name"); 
 JLabel jl3 = new JLabel("Company_address"); 
 JLabel jl4 = new JLabel("Company_phone_no"); 
 JLabel jl5 = new JLabel("Company_email_id");
 jt1 = new JTextField(15);
 jt2 = new JTextField(15);
 jt3 = new JTextField(15);
 jt4 = new JTextField(15);
 jt5 = new JTextField(15);
 JLabel jl6 = new JLabel("Year"); 
 JLabel jl7 = new JLabel("Month");
 jb1=new JButton("OK");
 jb2=new JButton("CANCEL");

  jc1 = new JComboBox();
 for(int i=0;i<=100;i++)
 {
  jc1.addItem(1940+i+"");
 }
  jc2 = new JComboBox();
 jc2.addItem("January");
 jc2.addItem("February");
 jc2.addItem("March");
 jc2.addItem("April");
 jc2.addItem("May");
 jc2.addItem("June");
 jc2.addItem("July");
 jc2.addItem("August");
 jc2.addItem("September");
 jc2.addItem("October");
 jc2.addItem("November");
 jc2.addItem("December");
 

 gbc.gridx =0;
 gbc.gridy =0;
 jp.add(jl1,gbc);


 gbc.gridx =2;
 gbc.gridy =0;
 jp.add(jt1,gbc);

   

 gbc.gridx =0;
 gbc.gridy =7;
 jp.add(jl2,gbc);

 gbc.gridx =2;
 gbc.gridy =7;
 jp.add(jt2,gbc);

 gbc.gridx =0;
 gbc.gridy =14;
 jp.add(jl3,gbc);

 gbc.gridx =2;
 gbc.gridy =14;
 jp.add(jt3,gbc);

 gbc.gridx =0;
 gbc.gridy =21;
 jp.add(jl4,gbc);

 gbc.gridx =2;
 gbc.gridy =21;
 jp.add(jt4,gbc);

 gbc.gridx =0;
 gbc.gridy =28;
 jp.add(jl5,gbc);

 gbc.gridx =2;
 gbc.gridy =28;
 jp.add(jt5,gbc);

 gbc.gridx =0;
 gbc.gridy =35;
 jp.add(jl6,gbc);

 gbc.gridx =1;
 gbc.gridy =35;
 jp.add(jc1,gbc);

 gbc.gridx =2;
 gbc.gridy =35;
 jp.add(jl7,gbc);

 gbc.gridx =3;
 gbc.gridy =35;
 jp.add(jc2,gbc);


 jb1.addActionListener(this);
 gbc.gridx =1;
 gbc.gridy =42;
 jp.add(jb1,gbc);

 gbc.gridx =2;
 gbc.gridy =42;
 jp.add(jb2,gbc);
 
 cp.add(jp);
setResizable(false);
 }

public void actionPerformed(ActionEvent ae)
{
     int flag1=0;int flag2=0;
       Object source=ae.getSource();
      try
      {
        if (source == jb1)
        {
              Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
              con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
              st   = con.createStatement();
 
              String qry12="select company_id";
              qry12+=" from company_details where company_id ='"+jt1.getText()+"'  ";
              rs=st.executeQuery(qry12)  ;
              while(rs.next())
              {           
               flag1=1;
              }     
              Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
              con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
              st   = con.createStatement();
              String qry13="select * ";
              qry13+=" from company_year where company_id ='"+jt1.getText()+"' and company_year='"+jc1.getSelectedItem()+"' and company_month='"+jc2.getSelectedItem()+"'  ";
              rs1=st.executeQuery(qry13);
              while(rs1.next())
              {           
               flag2=1;
              }    

            if(flag1==0)
            {
    
	      JOptionPane.showMessageDialog(this,"check1");
              Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
              JOptionPane.showMessageDialog(this,"check2");
              con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
	JOptionPane.showMessageDialog(this,"check3");
            st   = con.createStatement();
	JOptionPane.showMessageDialog(this,"check4");
	String insertqry1="insert into company_details values ("+Integer.parseInt(jt1.getText())+",'"+jt2.getText()+"','"+jt3.getText()+"','"+jt4.getText()+"','"+jt5.getText()+"')";
	JOptionPane.showMessageDialog(this,insertqry1);
            int t=st.executeUpdate(insertqry1);
	String insertqry2="insert into company_year values ("+Integer.parseInt(jt1.getText())+",'"+jc1.getSelectedItem()+"','"+jc2.getSelectedItem()+"')";
	JOptionPane.showMessageDialog(this,insertqry2);
            int t1=st.executeUpdate(insertqry2);
        new myProgMon(); 
         jt1.setText("");
         jt2.setText("");
         jt3.setText("");
         jt4.setText("");
         jt5.setText("");
        }

          if(flag1==1 && flag2==0)
        { 

	String insertqry3="insert into company_year values ("+Integer.parseInt(jt1.getText())+",'"+jc1.getSelectedItem()+"','"+jc2.getSelectedItem()+"')";
	JOptionPane.showMessageDialog(this,insertqry3);
            int t1=st.executeUpdate(insertqry3);
         new myProgMon();
         jt1.setText("");
         jt2.setText("");
         jt3.setText("");
         jt4.setText("");
         jt5.setText("");

        }

        if(flag1==1 && flag2==1)
        {
 
	    JOptionPane.showMessageDialog(this,"This Record already exists");

         jt1.setText("");
         jt2.setText("");
         jt3.setText("");
         jt4.setText("");
         jt5.setText("");
        }


        } 

        }
        catch (Exception e)
        {
		System.out.println("Arre yanhan to error hai");
	}
}
}
