import java.io.*;
class sort
{
	public static void main(String args[])
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		String str="PACE BUREAU",str1="",str2="";
		try
		{
			str=br.readLine();
		}
		catch(Exception e){}
		char t,t1;
		for (int i=str.length()-2;i>=0;i--)
		{
			for(int j=0;j<=i;j++)
			{
				if(str.charAt(j) > str.charAt(j+1))
				{
					t=str.charAt(j);
					t1=str.charAt(j+1);
					str1=str.substring(0,j);
					str2 = str.substring(j+2);
					str=str1+t1+t+str2;
				}
			}
		}
		System.out.println("Sorted String is : "+str);
	}
}