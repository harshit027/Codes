import java.sql.*;

class myDatabase
{
        public static void main(String args[])
        {
                Connection con;
                ResultSet rs;
                Statement st;
                try
                {
                        Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                        con=DriverManager.getConnection("jdbc:odbc:myLogons",null,null);
                        st=con.createStatement();
                        rs=st.executeQuery("select * from login_detail");
                        System.out.println("Name\tPassword\tTime\t\tSerialNo");
                        while(rs.next())
                        {
                                System.out.println(rs.getString("loginName")+"\t"+rs.getString("password")+"\t"+rs.getString("time_of_login")+"\t"+rs.getString("sno"));
                        }               
                        rs.close();
                        con.close();
                 }
                 catch(Exception e){}
        }
}
