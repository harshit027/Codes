import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code= "mkey" width= 200 height=200>
</applet>
*/
public class mkey extends Applet implements KeyListener
{
    String msg=" ";//new String[100];
       int x[]=new int[100];
    int y=20,i=0;
    public void init()
      {
      addKeyListener(this);
      requestFocus();
      }

    public void keyPressed(KeyEvent ke)
    {
    showStatus("key down");
    int key=ke.getKeyCode();
    switch(key)
    {
   case  KeyEvent.VK_ENTER:
    for(i=0;i<=40;i+=4)
    {

    msg+=ke.getKeyChar();
    repaint();
    
    keyTyped(ke);
    repaint();
    
    }
    }
    }
    public void keyReleased(KeyEvent ke)
    {
    showStatus("key up");
    }
    public void keyTyped(KeyEvent ke)
    {
    msg+=ke.getKeyChar();
    repaint();
    }
    public void paint(Graphics g)
    {
    g.drawString(msg,x[i],y);
    }
  }



