package pkg;

public class myPackage
{
        public void show(String str)
        {
                System.out.println("You have Passed : "+str);
        }
}
