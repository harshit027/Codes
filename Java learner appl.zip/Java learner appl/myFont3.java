import java.applet.*;
import java.awt.*;
/*
        <applet code="myFont3.class" width=300 height=400>
	</applet>
*/

public class myFont3 extends Applet
{
        int i=30;
        int j=30;
	public void paint(Graphics g)
        {
         for(int k=1;k<3;k++)
          {
                //setForeground(Color.red);
                //setBackground(Color.yellow);
               Font f=new Font("Arial",Font.BOLD|Font.ITALIC,i);
                g.setFont(f);
                g.drawString("PACE  BUREAU",i,j);
                i=i-20;j+=20;

           }
           System.out.println(" ");
	}
}
