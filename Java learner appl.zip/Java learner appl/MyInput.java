import java.io.*;

class myInput
{
        public static void main(String args[])
        {
                InputStreamReader isr=new InputStreamReader(System.in);
                BufferedReader br=new BufferedReader(isr);
                float x;
                String s="";
                try
                {
                        System.out.println("\nEnter Any Number :");
                        s=br.readLine();
                        x=Double.valueOf(s).floatValue();
                        System.out.println("Inputted Number * 2 = "+(x*2));
                }
                catch(Exception e)
                {}
                /*int x;
                String s="";
                try
                {
                        System.out.println("\nEnter Any Number :");
                        s=br.readLine();
                        x=Integer.parseInt(s);
                        System.out.println("Inputted Number * 2 = "+(x*2));
                }
                catch(Exception e)
                {}*/
        }
}
