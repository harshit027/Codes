//import pkg.*;

class usepkg
{
        public static void main(String args[])
        {
                pkg.myPackage m=new pkg.myPackage();
                m.show("PACE BUREAU");
        }

}
