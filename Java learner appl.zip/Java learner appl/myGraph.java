import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class myGraph extends JFrame
{
	myGraph(int a[],String title)
	{
		super(title);
		setSize(600,600);
                setVisible(true);
		myGraphPanel p=new myGraphPanel(a);
		getContentPane().add(p);


                setResizable(false);
		show();
	}

	public static void main(String args[])
	{
		int temp[]={1,2,3,4,5,6,7,8};
		new myGraph(temp,"MyGraph");
	}
}

  class myGraphPanel extends JPanel
{
	int b[];
	int x=20;
	myGraphPanel(int a[])
	{
		b=a;
	}
	public void paint(Graphics g)
	{      String text=" IT             E&TC             Elec.           Mech.             Civil             I.P             C.S             MCA ";
               String text1 ="                         BRANCHES                              ";
               String text2 ="N";
               String text3 ="U";
               String text4 ="M";
               String text5 ="B";
               String text6 ="E";
               String text7 ="R";
               String text8 =" ";
               String text9 ="O";
               String text10 ="F";
               String text11=" ";
               String text12 ="S";
               String text13 ="T";
               String text14 ="U";
               String text15 ="D";
               String text16 ="E";
               String text17 ="N";
               String text18 ="T";
               String text19 ="S";
                g.drawString(text,60,500);

               Font font=new Font("Times New Roman",Font.BOLD,12);
               g.setFont(font);




                g.drawLine(40,480,550,480);
                g.drawLine(40,0,40,480);
                g.drawString(text1,200,520);
                g.drawString(text2,20,40);
                g.drawString(text3,20,50);
                g.drawString(text4,20,60);
                g.drawString(text5,20,70);
                g.drawString(text6,20,80);
                g.drawString(text7,20,90);
                g.drawString(text8,20,100);
                g.drawString(text9,20,110);
                g.drawString(text10,20,120);
                g.drawString(text11,20,130);
                g.drawString(text12,20,140);
                g.drawString(text13,20,150);
                g.drawString(text14,20,160);
                g.drawString(text15,20,170);
                g.drawString(text16,20,180);
                g.drawString(text17,20,190);
                g.drawString(text18,20,200);
                g.drawString(text19,20,210);
		Color c[]={Color.red,Color.green,Color.blue,Color.yellow,Color.magenta,Color.orange,Color.pink,Color.gray};
		x=60;
		for (int i=0;i<8;i++)
		{
			g.setColor(c[i]);
			g.fillRect(x,450-b[i],30,b[i]+30);
                        g.drawString(b[i]/20+"",x+5,440-b[i]);
			x+=60;
		}
	}

}
