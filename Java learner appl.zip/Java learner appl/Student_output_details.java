import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.*;

    class Student_output_details extends JFrame implements ActionListener
       {
              JButton jb1,jb2,jb3,jb4;
              JTextField   jt1,jt2,jt3,jt4;
              JTable table,table1;
              JScrollPane jsp,jsp1;
              Container cp;
              JPanel jp1,jp3;
              int v,h,v1,h1;
              ResultSet rs,rs1;
              Statement st,st1;
              Connection con,con1;
              String  qry,qry1,qry11,qry2,qry3,qry4,qry5,qry6;
              int n=10;
          public static void main(String args[])
          {
                    new Student_output_details();
          }
          Student_output_details()
          {
             super("Personal Information Student");
            // getContentPane().setLayout(new BorderLayout());
 
             WindowListener l = new WindowAdapter()
              {
               public void windowClosing(WindowEvent we)
                  {
                  System.exit(0);
                 }
              };
          addWindowListener(l);
          jp1 = new JPanel();
          cp = getContentPane();
          GridBagLayout gb = new GridBagLayout();
          GridBagConstraints gbc =new GridBagConstraints();

          jp1.setLayout(gb);
          gbc.weightx=1;
          gbc.weighty=1;
          gbc.gridwidth=1;
          gbc.gridheight=1;
 
          try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
             st   = con.createStatement();
            String qry21="select  * from student_data ";
             rs1 = st.executeQuery(qry21);
            int i1=0;
            while(rs1.next())
            {  int j1=0;
              while(j1<11)
               {
                 j1++;
               }
             i1++;n++;
            }
          }
           
          catch(Exception e)
         {
          System.out.println("ERRRRRRRR"+e);
         }
 



          final String[] colHeads ={"Roll_no","Name", "Category" ,"D.O.B","Father'sName","Address","Email_id","Phone_no","Course","Branch","Semester"};
          String[][] data=new String[n][11];
          int i=0,j=0;

          v= ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
          h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;

          try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
            Statement st   = con.createStatement();
            String qry11="select roll_no,name,category,dob,fathername";
            qry11+=",address,email_id,phone_no,course,branch,semester";
            qry11+=" from student_data  ";
            ResultSet rs = st.executeQuery(qry11);
            while(rs.next())
            {  j=0;
              while(j<11)
               {
                 String str=rs.getString(j+1);
                 str=str+"                                           ".substring(0,"                                           ".length()-str.length());
                 data[i][j]=str;
                 j++;
               }
             i++;
            }
            }
           catch(Exception e)
            {
                    System.out.println("Error : "+e);
            }
  
            //TableColumn getColumn(26);  
          table = new JTable (data,colHeads);
	table.setSize(500,200);
         table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
          jsp= new JScrollPane(table,v,h);
//          jp1.add(table);
          cp.add(jsp,"Center");

           JPanel  jp2 = new JPanel();
          GridBagLayout gb1 = new GridBagLayout();
          GridBagConstraints gbc1 =new GridBagConstraints();

          jp2.setLayout(gb1);
          gbc1.weightx=1;
          gbc1.weighty=1;
          gbc1.gridheight=1;
          gbc1.gridwidth=1;

         JLabel jl1=new JLabel("Roll_no");
         gbc1.gridx=0;
         gbc1.gridy=1;
        jp2.add(jl1,gbc1);

        jt1 =  new JTextField(25);
        gbc1.gridx  =  1;
        gbc1.gridy   = 1;
        jp2.add(jt1,gbc1);


        JLabel jl2=new JLabel("Age");
        gbc1.gridx=0;
        gbc1.gridy=2;
        jp2.add(jl2,gbc1);

        jt2 =  new JTextField(25);
        gbc1.gridx  =  1;
        gbc1.gridy   = 2;
        jp2.add(jt2,gbc1);

         JLabel jl3=new JLabel("Branch");
         gbc1.gridx=0;
         gbc1.gridy=3;
         jp2.add(jl3,gbc1);

        jt3 =  new JTextField(25);
        gbc1.gridx  =  1;
        gbc1.gridy   = 3;
        jp2.add(jt3,gbc1);

        JLabel jl4=new JLabel("Semester");
        gbc1.gridx=0;
        gbc1.gridy=4;
        jp2.add(jl4,gbc1);

        jt4 =  new JTextField(25);
        gbc1.gridx  =  1;
        gbc1.gridy   = 4;
        jp2.add(jt4,gbc1);


       jb1=new JButton("Exit");
       gbc1.gridx=0;
       gbc1.gridy=5;
       jb1.addActionListener(this);
       jp2.add(jb1,gbc1);

       gbc1.gridx  =  1;
       gbc1.gridy   = 5;
       jb2 =  new JButton("OK");

      jb2.addActionListener(this);
      jp2.add(jb2,gbc1);
      cp.add(jp2,"South");
       setSize(800,800);
       setVisible(true);
 
}            
     public void  actionPerformed(ActionEvent ae)
    {
        int i1=0;int flag=0;
          final String[] colHeads ={"Roll_no","Name", "Category" ,"D.O.B","Father'sName","Address","Email_id","Phone_no","Course","Branch","Semester"};
       Object source=ae.getSource();
       if (source == jb2)
       try
       {
        
            String[][] data=new String[n][11];
         if (!jt1.getText().equals("") &&jt2.getText().equals("")&&jt3.getText().equals("")&&jt4.getText().equals(""))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry="select roll_no,name,category,dob,fathername";
            qry+=",address,email_id,phone_no,course,branch,semester";
            qry+=" from student_data ";
            qry+="where roll_no ='"+ jt1.getText()+"'";
            rs = st.executeQuery(qry);

         }
         if (jt1.getText().equals("") &&jt2.getText().equals("")&&!jt3.getText().equals("")&&jt4.getText().equals(""))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry1="select roll_no,name,category,dob,fathername";
            qry1+=",address,email_id,phone_no,course,branch,semester";
            qry1+=" from student_data ";
            qry1+="where branch ='"+ jt3.getText()+"'";
            rs = st.executeQuery(qry1);

          }

         if (jt1.getText().equals("") &&jt2.getText().equals("")&&jt3.getText().equals("")&&!jt4.getText().equals(""))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry2="select roll_no,name,category,dob,fathername";
            qry2+=",address,email_id,phone_no,course,branch,semester";
            qry2+=" from student_data ";
            qry2+="where semester ='"+ jt4.getText()+"'";
            rs = st.executeQuery(qry2);

          }

         if (!jt1.getText().equals("") &&jt2.getText().equals("")&&!jt3.getText().equals("")&&!jt4.getText().equals(""))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry3="select roll_no,name,category,dob,fathername";
            qry3+=",address,email_id,phone_no,course,branch,semester";
            qry3+=" from student_data ";
            qry3+="where roll_no='"+jt1.getText()+"'and branch='"+jt3.getText()+"' and Semester ='"+ jt4.getText()+"'";
            rs = st.executeQuery(qry3);

          }

          if (!jt1.getText().equals("") &&jt2.getText().equals("")&&jt3.getText().equals("")&&!jt4.getText().equals(""))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry5="select roll_no,name,category,dob,fathername";
            qry5+=",address,email_id,phone_no,course,branch,semester";
            qry5+=" from student_data ";
            qry5+="where roll_no = '"+jt1.getText()+"' and Semester ='"+ jt4.getText()+"'";
            rs = st.executeQuery(qry5);

          }

         if (jt1.getText().equals("") &&jt2.getText().equals("")&&!jt3.getText().equals("")&&!jt4.getText().equals(""))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry6="select roll_no,name,category,dob,fathername";
            qry6+=",address,email_id,phone_no,course,branch,semester";
            qry6+=" from student_data ";
            qry6+="where branch = '" +jt3.getText()+"' and Semester ='"+ jt4.getText()+"'";
            rs = st.executeQuery(qry6);

          }

            System.out.println(qry6);
            
            //rs = st.executeQuery(qry);
            while(rs.next())
           {
                    int  j1=0;
      //  JOptionPane.showMessageDialog(this,"abhi loop chalega");
                    while(j1<11)
                    {

                 String str1=rs.getString(j1+1);
          str1=str1+"                                                ".substring(0,"                                                ".length()-str1.length());
          data[i1][j1]=str1;

                           //   data[i1][j1]=rs.getString(j1+1);
                              j1++;  flag=1;
                    }          
                    i1++;
            }
     //   JOptionPane.showMessageDialog(this,"dikha kya");

        if (flag==0)
        {
        JOptionPane.showMessageDialog(this,"Sorry! no Records");
        }
        

        cp.remove(jsp);
        table = new JTable (data,colHeads);
        table.setSize(500,200);
          	jsp= new JScrollPane(table,v,h);
         table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

       // jp1.add(jsp);
       // cp.repaint();
        cp.add(jsp,"Center");

       }
      catch(Exception e)
       {}
   
   }
  
}

