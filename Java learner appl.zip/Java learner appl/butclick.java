import java.awt.*;
import java.awt.event.*;
/*
        <applet code="butclick.class" width=1200 height=1200>
	</applet>
*/
public class butclick extends java.applet.Applet
{
	int x,y;
        Button btn;
        String str=" ";
	public void init()
	{
                btn=new Button("Touch Me");
		add(btn);
                setLayout(null);
                btn.setBounds(600,100,60,20);
                addMouseMotionListener(new myMMA(this));
	}
	public void paint(Graphics g)
	{
		g.setFont(new Font("Arial",Font.BOLD|Font.ITALIC,20));
		g.drawString(str,x,y);
	}
}

class myMMA extends MouseMotionAdapter
{
        butclick ref;
        int bx,by;
        myMMA(butclick ref)
	{
		this.ref=ref;
	}
        public void mouseMoved(MouseEvent me)
	{
		ref.x=me.getX();
		ref.y=me.getY();
	                	bx=ref.btn.getX();
                		by=ref.btn.getY();
		ref.str=ref.x+" ";
                		if (ref.x < bx)
                           		bx+=7;
                     	else
			bx-=7;
                		if (ref.y < by)
			by+=7;
                     	else
			by-=7;
		ref.btn.setBounds(bx,by,60,20);                 	
		ref.repaint();
	}	
}
