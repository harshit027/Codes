import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.sql.*;

   class student_details extends JFrame implements ActionListener
    {
  
      Container cp;
      JLabel jl1,jl2,jl3,jl4,jl5,jl6,jl7,jl8,jl9,jl10,jl11,njl1,njl2,njl3,njl4,njl5,njl6,njl7,njl8,njl9,njl10,njl11,njl12,njl13,njl43,njl44,njl45,njl46,njl47,njl48,njl49,njl410,njl411,grad,pgrad;
      JTextField jt1,jt2,jt3,jt4,jt5,jt6,njt1,njt2,njt3,njt4,njt5,njt6,njt7,njt8,njt9,njt10 ;
      JTextField njt13,njt43,njt44,njt45,njt46,njt47,njt48,njt411;
      TextArea jta1;
      JComboBox jc1,jc2,jc3,jc4,jc5,jc6,jc7,jc8;
      JButton jb1,jb2,jb3,jb4;
      Connection con;
      Statement st;
      ResultSet rs;
      public static void main(String args[])
      {
           new student_details();
       }

      student_details()
      {
           super("students_details");

           WindowListener l=new WindowAdapter()
             {
               public void windowClosing(WindowEvent we)
                {
                    System.exit(0);
                 }  
             };
            addWindowListener(l);
           cp=getContentPane();

           JPanel  jp1;
           jp1=new JPanel();

           Border etched =BorderFactory.createEtchedBorder();
           Border titled = BorderFactory.createTitledBorder(etched, "Personal Information");
           jp1.setBorder(titled);
           GridBagLayout gb=new GridBagLayout();
           GridBagConstraints gbc = new GridBagConstraints();
           jp1.setLayout(gb);

           gbc.gridwidth=1;
           gbc.gridheight=1;
           gbc.weightx=1;
           gbc.weighty=1;

           jl1=new JLabel("*Roll_no");
           jl2=new JLabel("*Name");
           jl3=new JLabel("*Category");
           jl4=new JLabel("*Date_Of_Birth");
           jl5=new JLabel("*Father Name");
           jl6=new JLabel("*Address");
           jl7=new JLabel("Email_id");
           jl8=new JLabel("*Course");
           jl9=new JLabel("*Branch");
           jl10=new JLabel("*Semester");
           jl11=new JLabel("Phone_no");

           jt1 = new JTextField(15);
           jt2 = new JTextField(15);
           jt3 = new JTextField(15);
           jt4 = new JTextField(15);
           jt5 = new JTextField(15);
           jt6 = new JTextField(15);

           jta1 = new TextArea(3,15);

           jc1 = new JComboBox();
           jc2 = new JComboBox();
           jc3 = new JComboBox();
           jc4 = new JComboBox();
           jc5 = new JComboBox();
           jc6 = new JComboBox();

           for(int i =1;i<=31;i++)
             {
               jc1.addItem(i+"");
            }
          
           jc2.addItem("January");
           jc2.addItem("February");
           jc2.addItem("March");
           jc2.addItem("April");
           jc2.addItem("May");
           jc2.addItem("June");
           jc2.addItem("July");
           jc2.addItem("August");
           jc2.addItem("September");
           jc2.addItem("October");
           jc2.addItem("November");
           jc2.addItem("December");

           for(int k=1975;k<=2030;k++)
            {
              jc3.addItem(k+"");
            }

           jc4.addItem("M.C.A.");
           jc4.addItem("B.E.");
           jc4.addItem("M.E.");

           jc5.addItem("Information Tecnology");
           jc5.addItem("Electronics & Telecommunication");
           jc5.addItem("Electrical");
           jc5.addItem("Mechanical");
           jc5.addItem("Civil");
           jc5.addItem("Industrial Production");
           jc5.addItem("ComputerScience");
           jc5.addItem("M.C.A");

           jc6.addItem("I");
           jc6.addItem("II");
           jc6.addItem("III");
           jc6.addItem("IV");
           jc6.addItem("V");
           jc6.addItem("VI");
           jc6.addItem("VII");
           jc6.addItem("VIII");


           gbc.gridx=0;
           gbc.gridy=1;
           jp1.add(jl1,gbc);

           gbc.gridx=2;
           gbc.gridy=1;
           jp1.add(jt1,gbc);

           gbc.gridx=12;
           gbc.gridy=1;
           jp1.add(jl2,gbc);

           gbc.gridx=14;
           gbc.gridy=1;
           jp1.add(jt2,gbc);

           gbc.gridx=0;
           gbc.gridy=2;
           jp1.add(jl3,gbc);

           gbc.gridx=2;
           gbc.gridy=2;
           jp1.add(jt3,gbc);

           gbc.gridx=12;
           gbc.gridy=2;
           jp1.add(jl4,gbc);

           gbc.gridx=14;
           gbc.gridy=2;
           jp1.add(jc1,gbc);

           gbc.gridx=15;
           gbc.gridy=2;
           jp1.add(jc2,gbc);

           gbc.gridx=16;
           gbc.gridy=2;
           jp1.add(jc3,gbc);

           gbc.gridx=0;
           gbc.gridy=3;
           jp1.add(jl5,gbc);

           gbc.gridx=2;
           gbc.gridy=3;
           jp1.add(jt4,gbc);

           gbc.gridx=12;
           gbc.gridy=3;
           jp1.add(jl11,gbc);

           gbc.gridx=14;
           gbc.gridy=3;
           jp1.add(jt6,gbc);

           gbc.gridx=0;
           gbc.gridy=4;
           jp1.add(jl6,gbc);

           gbc.gridx=2;
           gbc.gridy=4;
           jp1.add(jta1,gbc);

           gbc.gridx=12;
           gbc.gridy=4;
           jp1.add(jl7,gbc);

           gbc.gridx=14;
           gbc.gridy=4;
           jp1.add(jt5,gbc);

           gbc.gridx=0;
           gbc.gridy=5;
           jp1.add(jl9,gbc);

           gbc.gridx=2;
           gbc.gridy=5;
           jp1.add(jc5,gbc);

           gbc.gridx=12;
           gbc.gridy=5;
           jp1.add(jl10,gbc);

           gbc.gridx=14;
           gbc.gridy=5;
           jp1.add(jc6,gbc);

           gbc.gridx=15;
           gbc.gridy=5;
           jp1.add(jl8,gbc);

           gbc.gridx=16;
           gbc.gridy=5;
           jp1.add(jc4,gbc);

           JPanel jp2 =new JPanel();
           Border etched1 =BorderFactory.createEtchedBorder();
           Border titled1 = BorderFactory.createTitledBorder(etched1, "Academic Records");
           jp2.setBorder(titled1);

           GridBagLayout gb1=new GridBagLayout();
           GridBagConstraints gbc1 = new GridBagConstraints();
           jp2.setLayout(gb1);

           gbc1.gridwidth=1;
           gbc1.gridheight=1;
           gbc1.weightx=1;
           gbc1.weighty=1;

           njl1 = new JLabel("*10th");
           njl2 = new JLabel("*12th");

           njt1 = new JTextField(15);
           njt2 = new JTextField(15);

           gbc1.gridx=1;
           gbc1.gridy= 16;
           jp2.add(njl1,gbc1);

           gbc1.gridx=2;
           gbc1.gridy= 16;
           jp2.add(njt1,gbc1);

           gbc1.gridx=1;
           gbc1.gridy= 19;
           jp2.add(njl2,gbc1);

           gbc1.gridx=2;
           gbc1.gridy= 19;
           jp2.add(njt2,gbc1);

           JPanel jp21 =new JPanel();
           Border etched21 =BorderFactory.createEtchedBorder();
           Border titled21= BorderFactory.createTitledBorder(etched21, "Graduation");
           jp21.setBorder(titled21);
           GridBagLayout gb21=new GridBagLayout();
           GridBagConstraints gbc21 = new GridBagConstraints();

           jp21.setLayout(gb21);
           gbc21.gridwidth=1;
           gbc21.gridheight=1;
           gbc21.weightx=1;
           gbc21.weighty=1;

           jc7 = new JComboBox();
           jc7.addItem("B.E.");
           jc7.addItem("B.Sc");
           jc7.addItem("B.Com");
           jc7.addItem("B.C.A");

           jc8 = new JComboBox();
           jc8.addItem("-");
           jc8.addItem("M.C.A");
           jc8.addItem("M.E");
           grad=new JLabel("Graduation");
           pgrad=new JLabel("PostGraduation");

           gbc1.gridx=1;
           gbc1.gridy=24;
           jp2.add(grad,gbc1); 

           gbc1.gridx=2;
           gbc1.gridy=24;
           jp2.add(jc7,gbc1); 

           gbc1.gridx=1;
           gbc1.gridy=26;
           jp2.add(pgrad,gbc1); 

           gbc1.gridx=2;
           gbc1.gridy=26;
           jp2.add(jc8,gbc1); 


           JPanel jp23 =new JPanel();
           Border etched23 =BorderFactory.createEtchedBorder();
           Border titled23= BorderFactory.createTitledBorder(etched23, "Graduation_details");
           jp23.setBorder(titled23);
           GridBagLayout gb23=new GridBagLayout();
           GridBagConstraints gbc23 = new GridBagConstraints();

           jp23.setLayout(gb23);
           gbc23.gridwidth=1;
           gbc23.gridheight=1;
           gbc23.weightx=1;
           gbc23.weighty=1;
           
           njl3 = new JLabel(" Isem/Iyr");
           njl4 = new JLabel(" IIsem/IIyr");
           njl5 = new JLabel(" IIIsem/IIIyr");
           njl6 = new JLabel(" IV sem");
           njl7 = new JLabel(" V sem");
           njl8 = new JLabel(" VI sem");
           njl9 = new JLabel(" VII sem");
           njl10 = new JLabel(" VIII sem");
           njl13 = new JLabel("Aggregate");

           njt3 = new JTextField(5);
           njt4 = new JTextField(5);
           njt5 = new JTextField(5);
           njt6 = new JTextField(5);
           njt7 = new JTextField(5);
           njt8 = new JTextField(5);
           njt9 = new JTextField(5);
           njt10 = new JTextField(5);
           njt13 = new JTextField(8);
           
           jb3=new JButton("Cal");
         
           gbc23.gridx=0;
           gbc23.gridy=1;
           jp23.add(njl3,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=1;
           jp23.add(njt3,gbc23);

           gbc23.gridx=2;
           gbc23.gridy=1;
           jp23.add(njl4,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=1;
           jp23.add(njt4,gbc23);

           gbc23.gridx=0;
           gbc23.gridy=2;
           jp23.add(njl5,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=2;
           jp23.add(njt5,gbc23);

           gbc23.gridx=2;
           gbc23.gridy=2;
           jp23.add(njl6,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=2;
           jp23.add(njt6,gbc23);

           gbc23.gridx=0;
           gbc23.gridy=3;
           jp23.add(njl7,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=3;
           jp23.add(njt7,gbc23);

           gbc23.gridx=2;
           gbc23.gridy=3;
           jp23.add(njl8,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=3;
           jp23.add(njt8,gbc23);

           gbc23.gridx=0;
           gbc23.gridy=4;
           jp23.add(njl9,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=4;
           jp23.add(njt9,gbc23);

           gbc23.gridx=2;
           gbc23.gridy=4;
           jp23.add(njl10,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=4;
           jp23.add(njt10,gbc23);

           gbc23.gridx=0;
           gbc23.gridy=6;
           jp23.add(njl13,gbc23);

           gbc23.gridx=1;
           gbc23.gridy=6;
           jp23.add(njt13,gbc23);

           gbc23.gridx=3;
           gbc23.gridy=6;
           jp23.add(jb3,gbc23);
         
           gbc1.gridx=1;
           gbc1.gridy=40;
           jp2.add(jp23,gbc1);

           JPanel jp24 =new JPanel();
           Border etched24 =BorderFactory.createEtchedBorder();
           Border titled24= BorderFactory.createTitledBorder(etched24, "Post_Graduation_details");
           jp24.setBorder(titled24);
           GridBagLayout gb24=new GridBagLayout();
           GridBagConstraints gbc24 = new GridBagConstraints();

           jp24.setLayout(gb24);
           gbc24.gridwidth=1;
           gbc24.gridheight=1;
           gbc24.weightx=1;
           gbc24.weighty=1;

           njl43 = new JLabel(" I sem");
           njl44 = new JLabel(" II sem");
           njl45 = new JLabel(" III sem");
           njl46 = new JLabel(" IV sem");
           njl47 = new JLabel(" V sem");
           njl48 = new JLabel(" VI sem");
           njl411 = new JLabel("Aggregate");

           jb4=new JButton("Cal");

           njt43 = new JTextField(5);
           njt44 = new JTextField(5);
           njt45 = new JTextField(5);
           njt46 = new JTextField(5);
           njt47 = new JTextField(5);
           njt48 = new JTextField(5);
           njt411 = new JTextField(8);

           gbc24.gridx=0;
           gbc24.gridy=1;
           jp24.add(njl43,gbc24);

           gbc24.gridx=1;
           gbc24.gridy=1;
           jp24.add(njt43,gbc24);

           gbc24.gridx=2;
           gbc24.gridy=1;
           jp24.add(njl44,gbc24);
           gbc24.gridx=3;
           gbc24.gridy=1;
           jp24.add(njt44,gbc24);

           gbc24.gridx=0;
           gbc24.gridy=2;
           jp24.add(njl45,gbc24);

           gbc24.gridx=1;
           gbc24.gridy=2;
           jp24.add(njt45,gbc24);

           gbc24.gridx=2;
           gbc24.gridy=2;
           jp24.add(njl46,gbc24);

           gbc24.gridx=3;
           gbc24.gridy=2;
           jp24.add(njt46,gbc24);

           gbc24.gridx=0;
           gbc24.gridy=3;
           jp24.add(njl47,gbc24);

           gbc24.gridx=1;
           gbc24.gridy=3;
           jp24.add(njt47,gbc24);

           gbc24.gridx=2;
           gbc24.gridy=3;
           jp24.add(njl48,gbc24);

           gbc24.gridx=3;
           gbc24.gridy=3;
           jp24.add(njt48,gbc24);


           gbc24.gridx=0;
           gbc24.gridy=5;
           jp24.add(njl411,gbc24);

           gbc24.gridx=1;
           gbc24.gridy=5;
           jp24.add(njt411,gbc24);

           gbc24.gridx=3;
           gbc24.gridy=5;
           jp24.add(jb4,gbc24);

           gbc1.gridx=2;
           gbc1.gridy=40;
           jp2.add(jp24,gbc1);


           jb1 = new JButton("SUBMIT");
           jb2 = new JButton("CANCEL");

           gbc1.gridx=1;
           gbc1.gridy=100;
           jp2.add(jb1,gbc1);

           jb1.addActionListener(this);
           gbc1.gridx=2;
           gbc1.gridy=100;
           jp2.add(jb2,gbc1);

           jb3.addActionListener(this);
           jb4.addActionListener(this);

           cp.add(jp1,"North");

           cp.add(jp2,"South");

           setSize(800,800);
           setVisible(true);

   }

public void actionPerformed(ActionEvent ae)
{  float cal; float avg; float cal1;float avg1;
    int flag=0;int flag1=0;
       Object source=ae.getSource();
      try
      {
       if (source == jb1)
        {

          if(jt5.getText().equals(""))
           {
            jt5.setText("-");
           }
          if(jt6.getText().equals(""))
           {
            jt6.setText("0");
           }

         if(njt3.getText().equals(""))
           {
            njt3.setText("0");
           }
         if(njt4.getText().equals(""))
           {
            njt4.setText("0");
           }
         if(njt5.getText().equals(""))
           {
            njt5.setText("0");
           }
         if(njt6.getText().equals(""))
           {
            njt6.setText("0");
           }       
         if(njt7.getText().equals(""))
           {
            njt7.setText("0");
           }

          if(njt8.getText().equals(""))
           {
            njt8.setText("0");
           }
          if(njt9.getText().equals(""))
           {
            njt9.setText("0");
           }
          if(njt10.getText().equals(""))
           {
            njt10.setText("0");
           }
          if(njt13.getText().equals(""))
           {
            njt13.setText("0");
           }
          if(njt43.getText().equals(""))
           {
            njt43.setText("0");
           }
          if(njt44.getText().equals(""))
           {
            njt44.setText("0");
           }
          if(njt45.getText().equals(""))
           {
            njt45.setText("0");
           }
          if(njt46.getText().equals(""))
           {
            njt46.setText("0");
           }
          if(njt47.getText().equals(""))
           {
            njt47.setText("0");
           }
          if(njt48.getText().equals(""))
           {
            njt48.setText("0");
           }
          if(njt411.getText().equals(""))
           {
            njt411.setText("0");
           }

             Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
             con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
             st   = con.createStatement();
 
             String qry1="select roll_no";
             qry1+=" from student_data where roll_no='"+jt1.getText()+"'  ";
             rs=st.executeQuery(qry1)  ;
             while(rs.next())
              {
             
               flag=1;
             }

      if(flag==0)
   {
      if(!jt1.getText().equals("")&&!jt2.getText().equals("")&&!jt3.getText().equals("")&&!jt4.getText().equals("")&&!jt4.getText().equals("")&&!jta1.getText().equals("")&&!njt2.getText().equals(""))
       {
	JOptionPane.showMessageDialog(this,"check1");
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	JOptionPane.showMessageDialog(this,"check2");
            con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
	JOptionPane.showMessageDialog(this,"check3");
            st   = con.createStatement();
	JOptionPane.showMessageDialog(this,"check4");

        String insertqry1="insert into student_data values('"+jt1.getText()+"','"+jt2.getText()+"','"+jt3.getText()+"',TO_DATE('"+jc1.getSelectedItem()+ "/" +jc2.getSelectedItem()+ "/" +jc3.getSelectedItem()+ "','dd/mm/yy'),'"+jt4.getText()+"','"+jta1.getText()+"','"+jt5.getText()+"','"+jt6.getText()+"','"+jc4.getSelectedItem()+"','"+jc5.getSelectedItem()+"','"+jc6.getSelectedItem()+"')";
         JOptionPane.showMessageDialog(this,insertqry1);
            int t=st.executeUpdate(insertqry1);
         String insertqry2="insert into s_marks values ('"+jt1.getText()+"','"+njt1.getText()+"','"+njt2.getText()+"','"+jc7.getSelectedItem()+"','"+njt3.getText()+"','"+njt4.getText()+"','"+njt5.getText()+"','"+njt6.getText()+"','"+njt7.getText()+"','"+njt8.getText()+"','"+njt9.getText()+"','"+njt10.getText()+"','"+njt13.getText()+"','"+jc8.getSelectedItem()+"','"+njt43.getText()+"','"+njt44.getText()+"','"+njt45.getText()+"','"+njt46.getText()+"','"+njt47.getText()+"','"+njt48.getText()+"','"+njt411.getText()+"')";
        int t1=st.executeUpdate(insertqry2);
          JOptionPane.showMessageDialog(this,insertqry2);
         new myProgMon();
         flag1=1;
          }
      if(jt1.getText().equals("")||jt2.getText().equals("")||jt3.getText().equals("")||jt4.getText().equals("")|| jta1.getText().equals("")||njt1.getText().equals("")||njt2.getText().equals(""))
      {        
	JOptionPane.showMessageDialog(this,"Fill the compulsory fields");
      }

    }
     
 if(flag==1)
 {
          JOptionPane.showMessageDialog(this,"This Roll_no alredy exists");
}
        if(flag1==1)
        {
         jt1.setText("");
         jt2.setText("");
         jt3.setText("");
         jt4.setText("");
         jt5.setText("");
         jt6.setText("");
         njt1.setText("");
         njt2.setText("");
         njt3.setText("");
         njt4.setText("");
         njt5.setText("");
         njt6.setText("");
         njt7.setText("");
         njt8.setText("");
         njt9.setText("");
         njt10.setText("");
         njt13.setText("");
         njt43.setText("");
         njt44.setText("");
         njt45.setText("");
         njt46.setText("");
         njt47.setText("");
         njt48.setText("");
         njt411.setText("");
         jta1.setText("");
        }
       
       }
          if (source == jb3)
          {

            if(!njt3.getText().equals("")&&njt4.getText().equals("")&&njt5.getText().equals("")&&njt6.getText().equals("")&&njt7.getText().equals("")&&njt8.getText().equals("")&&njt9.getText().equals("")&&njt10.getText().equals(""))
             {
               cal = Integer.parseInt(njt3.getText());    
               njt13.setText(cal+"");     
             }
            if(!njt3.getText().equals("")&&!njt4.getText().equals("")&&njt5.getText().equals("")&&njt6.getText().equals("")&&njt7.getText().equals("")&&njt8.getText().equals("")&&njt9.getText().equals("")&&njt10.getText().equals(""))
             {
               cal = Integer.parseInt(njt3.getText())+Integer.parseInt(njt4.getText());    
               avg = cal/2;
               njt13.setText(avg+"");     
             }

            if(!njt3.getText().equals("")&&!njt4.getText().equals("")&&!njt5.getText().equals("")&&njt6.getText().equals("")&&njt7.getText().equals("")&&njt8.getText().equals("")&&njt9.getText().equals("")&&njt10.getText().equals(""))
             {
               cal = Integer.parseInt(njt3.getText())+Integer.parseInt(njt4.getText())+Integer.parseInt(njt5.getText());    
               avg = cal/3;
               njt13.setText(avg+"");     
             }
            if(!njt3.getText().equals("")&&!njt4.getText().equals("")&&!njt5.getText().equals("")&&!njt6.getText().equals("")&&njt7.getText().equals("")&&njt8.getText().equals("")&&njt9.getText().equals("")&&njt10.getText().equals(""))
             {
               cal = Integer.parseInt(njt3.getText())+Integer.parseInt(njt4.getText())+Integer.parseInt(njt5.getText())+Integer.parseInt(njt6.getText());    
               avg = cal/4;
               njt13.setText(avg+"");     
             }
            if(!njt3.getText().equals("")&&!njt4.getText().equals("")&&!njt5.getText().equals("")&&!njt6.getText().equals("")&&!njt7.getText().equals("")&&njt8.getText().equals("")&&njt9.getText().equals("")&&njt10.getText().equals(""))
             {
               cal = Integer.parseInt(njt3.getText())+Integer.parseInt(njt4.getText())+Integer.parseInt(njt5.getText())+Integer.parseInt(njt6.getText())+Integer.parseInt(njt7.getText());    
               avg = cal/5;
               njt13.setText(avg+"");     
             }
            if(!njt3.getText().equals("")&&!njt4.getText().equals("")&&!njt5.getText().equals("")&&!njt6.getText().equals("")&&!njt7.getText().equals("")&&!njt8.getText().equals("")&&njt9.getText().equals("")&&njt10.getText().equals(""))
             {
               cal = Integer.parseInt(njt3.getText())+Integer.parseInt(njt4.getText())+Integer.parseInt(njt5.getText())+Integer.parseInt(njt6.getText())+Integer.parseInt(njt7.getText())+Integer.parseInt(njt8.getText());    
               avg = cal/6;
               njt13.setText(avg+"");     
             }
            if(!njt3.getText().equals("")&&!njt4.getText().equals("")&&!njt5.getText().equals("")&&!njt6.getText().equals("")&&!njt7.getText().equals("")&&!njt8.getText().equals("")&&!njt9.getText().equals("")&&njt10.getText().equals(""))
             {
               cal = Integer.parseInt(njt3.getText())+Integer.parseInt(njt4.getText())+Integer.parseInt(njt5.getText())+Integer.parseInt(njt6.getText())+Integer.parseInt(njt7.getText())+Integer.parseInt(njt8.getText())+Integer.parseInt(njt9.getText());    
               avg = cal/7;
               njt13.setText(avg+"");     
             }
            if(!njt3.getText().equals("")&&!njt4.getText().equals("")&&!njt5.getText().equals("")&&!njt6.getText().equals("")&&!njt7.getText().equals("")&&!njt8.getText().equals("")&&!njt9.getText().equals("")&&!njt10.getText().equals(""))
             {
               cal = Integer.parseInt(njt3.getText())+Integer.parseInt(njt4.getText())+Integer.parseInt(njt5.getText())+Integer.parseInt(njt6.getText())+Integer.parseInt(njt7.getText())+Integer.parseInt(njt8.getText())+Integer.parseInt(njt9.getText())+Integer.parseInt(njt10.getText());    
               avg = cal/8;
               njt13.setText(avg+"");     
             }


          }

          if (source == jb4)
          {
            if(!njt43.getText().equals("") && njt44.getText().equals("") &&njt45.getText().equals("") &&njt46.getText().equals("") &&njt47.getText().equals("") &&njt48.getText().equals("") )
             {
               cal1 = Integer.parseInt(njt43.getText());
               njt411.setText(cal1+"");
             }

            if(!njt43.getText().equals("") && !njt44.getText().equals("") &&njt45.getText().equals("") &&njt46.getText().equals("") &&njt47.getText().equals("") &&njt48.getText().equals("") )
             {
               cal1 = Integer.parseInt(njt43.getText())+Integer.parseInt(njt44.getText());
               avg1 = cal1/2;
               njt411.setText(avg1+"");
             }

            if(!njt43.getText().equals("") && !njt44.getText().equals("") && !njt45.getText().equals("") &&njt46.getText().equals("") &&njt47.getText().equals("") &&njt48.getText().equals("") )
             {
               cal1 = Integer.parseInt(njt43.getText())+Integer.parseInt(njt44.getText())+Integer.parseInt(njt45.getText());
               avg1 = cal1/3;
               njt411.setText(avg1+"");
             }
       
            if(!njt43.getText().equals("") && !njt44.getText().equals("") && !njt45.getText().equals("") && !njt46.getText().equals("") &&njt47.getText().equals("") &&njt48.getText().equals("") )
             {
               cal1 = Integer.parseInt(njt43.getText())+Integer.parseInt(njt44.getText())+Integer.parseInt(njt45.getText())+Integer.parseInt(njt46.getText());
               avg1 = cal1/4;
               njt411.setText(avg1+"");
             }

            if(!njt43.getText().equals("") && !njt44.getText().equals("") && !njt45.getText().equals("") && !njt46.getText().equals("") && !njt47.getText().equals("") &&njt48.getText().equals("") )
             {
               cal1 = Integer.parseInt(njt43.getText())+Integer.parseInt(njt44.getText())+Integer.parseInt(njt45.getText())+Integer.parseInt(njt46.getText())+Integer.parseInt(njt47.getText());
               avg1 = cal1/5;
               njt411.setText(avg1+"");
               
             }
            if(!njt43.getText().equals("") && !njt44.getText().equals("") && !njt45.getText().equals("") && !njt46.getText().equals("") && !njt47.getText().equals("") && !njt48.getText().equals("") )
             {
               cal1 = Integer.parseInt(njt43.getText())+Integer.parseInt(njt44.getText())+Integer.parseInt(njt45.getText())+Integer.parseInt(njt46.getText())+Integer.parseInt(njt47.getText())+Integer.parseInt(njt48.getText());
               avg1 = cal1/6;
               njt411.setText(avg1+"");
             }

  
          }
 

         }
        catch (Exception e)
        {
		System.out.println("Arre yanhan to error hai");
	}
}

}



