//package pk;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;


public class regstr extends JFrame implements ActionListener,WindowListener
{

public static JButton jbtn;
public static JButton jbtn1;
public static JButton jbtn2;
public static Color myc2=Color.orange;
public static JPanel p1,p2,p3;
public static JLabel jl;
public static ImageIcon ig1,ig2,ig3;
public static DataExchangeTest1 det;
//public static user usr;
public String regkey,keykey;
regstr(){}
regstr(String r)
{
	setTitle("Registration");
	setSize(800,550);

	p2=new JPanel();
	p3=new JPanel();
	getContentPane().add(p3,"Center");
	Container c=getContentPane();

	p2.setBackground(Color.orange);
	p3.setBackground(myc2);
	ImageIcon ig1 =new ImageIcon("Follow.jpg");
	jl=new JLabel(ig1,JLabel.CENTER);
	p3.add(jl);
	jbtn=new JButton("REGISTRATION");
	jbtn.setBackground(myc2);
	jbtn.addActionListener(this);
	jbtn1=new JButton("SIGN-IN");
	jbtn1.setBackground(myc2);
	getContentPane().add(p2,"South");
	p2.add(jbtn);
	p2.add(jbtn1);
	jbtn2=new JButton("Back",new ImageIcon ("back.gif "));
//	jbtn3=new JButton("Next",new ImageIcon ("next1.gif "));
	jbtn1.addActionListener(this);
	jbtn2.addActionListener(this);
//	jbtn3.addActionListener(this);
	p2.add(jbtn2);
//	p2.add(jbtn3);

	jbtn2.setBackground(myc2);
//	jbtn3.setBackground(myc2);

	show();
}

public void actionPerformed(ActionEvent ae)
{
	JButton jbt=(JButton)ae.getSource();
	if(jbt==jbtn)
	{
			try{

				FileReader hfr=new FileReader("myf.pak");
				BufferedReader hbr=new BufferedReader(hfr);
				String str=new String();
				char ch[]=new char[9];
				char ch1[]=new char[9];
				char ch2[]=new char[9];
				str=hbr.readLine();
				str=hbr.readLine();
				str=hbr.readLine();
				str.getChars(25,34,ch,0);
				System.out.println(ch);

				for(int i=0;i<=8;i++)
				{
					int m=(int)ch[i];
					m+=(i+1);
					ch1[i]=(char)m;
					m=0;
				}
				System.out.println("Encryption : "+new String(ch1));
				regkey=new String(ch1);
				hfr.close();
				JOptionPane.showMessageDialog(this,"Kindly send this registration number to www.pacejbp\\myeditor.jsp\n"+new String(ch1),"Register",JOptionPane.OK_CANCEL_OPTION);

				/*---------------------Again Encryption----------------------*/

				/*String str=request.getParameter("key");
						char ch1[]=str.toCharArray();
						char ch2[]=new char[9];*/
						int finalKey[]=new int[5];
						int k=0;
						for(int i=0;i<=8;i++)
						{
							int m=(int)ch1[i];
							m-=(i+1);
							ch2[i]=(char)m;
							m=0;
						}
						for(int i=0;i<=8;i+=2)
						{
							int m=(int)ch2[i];
							int n=0;
							if(i<8)
							n=(int)ch2[i+1];
							m=m+n;
							n=0;
							while(m>0)
							{
								n+=m%10;
								m/=10;
								if(m==0 && n>9)
								{
									m=n;n=0;
								}

							}
							finalKey[k++]=n;

						}
						keykey=finalKey[0]+"";
						for(int i=1;i<5;i++)
						{
							keykey+=finalKey[i]+"";
						}
						System.out.println("your key is :"+keykey);

		}
		catch(Exception e)
		{
				System.out.println("You have some problem in registration.Please contact Pace Bureau"+e);

		}

	}

	if(jbt==jbtn1)
		{
			det=new DataExchangeTest1();
			//usr= new user();

		}

}
public void windowActivated(WindowEvent e1)
{
}
public void windowClosed(WindowEvent e1)
{
}
public void windowClosing(WindowEvent e1)
{
}
public void windowDeactivated(WindowEvent e1)
{
}
public void windowDeiconified(WindowEvent e1)
{
}
public void windowIconified(WindowEvent e1)
{
}
public void windowOpened(WindowEvent e1)
{
}

public static void main(String args[])
{
	JFrame jf=new regstr("preet");
	jf.show();
}
}




