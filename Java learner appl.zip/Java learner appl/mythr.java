class mythr
{
public static void main(String args[])
{
    
    new myt();
    }
 }
    class myt extends Thread
    {
        myt()
        {
        start();
        }
        public void run()
        {
            while(true)
            {
                System.out.println("neha");
                try
                {
                sleep(100);
                }
                catch(Exception e)
                {
                }
             }
        }
 }

