import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;

class Company_database extends JFrame   implements ActionListener
{
          JButton jb1,jb2;
          JTextField   jt1,jt2;
          JTable table;
          JScrollPane jsp;
          Container cp;
          JPanel jp1;
          int v,h;
          ResultSet rs;
          Statement st;
          Connection con;

          public static void main(String args[])
          {
                    new Company_database();
          }
          Company_database()
          {
             super("Record Of Company");
             getContentPane().setLayout(new BorderLayout());
             setSize(640,800);
 
             WindowListener l = new WindowAdapter()
              {
               public void windowClosing(WindowEvent we)
                 {
                  System.exit(0);
                 }
              };
          addWindowListener(l);
          jp1 = new JPanel();
          cp = getContentPane();
          GridBagLayout gb = new GridBagLayout();
          GridBagConstraints gbc =new GridBagConstraints();

          jp1.setLayout(gb);
          gbc.weightx=1;
          gbc.weighty=1;
          gbc.gridwidth=1;
          gbc.gridheight=1;

          final String[] colHeads ={"Company_id","Company_Name", "Address" ,"Phone_no","Email id","Year","Month"};
          final String[][] data=new String[10][7];
          int i=0,j=0;

          v= ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
          h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;

          try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
            Statement st=con.createStatement();
            ResultSet rs=st.executeQuery("select Company_details.company_id,Company_name,Company_address,Company_phone_no,Company_Email_id,Company_year,Company_Month from Company_details,Company_year where  Company_details.Company_id=Company_year.Company_id");
            while(rs.next())
            {
             j=0;
              while(j<7)
               {
                 data[i][j]=rs.getString(j+1);
                 j++;
                }
             i++;
            }
          table = new JTable (data,colHeads);                                                                             
          jsp= new JScrollPane(table,v,h);
          jp1.add(jsp);
          cp.add(jp1,"North");

          JPanel  jp2 = new JPanel();
          GridBagLayout gb1 = new GridBagLayout();
          GridBagConstraints gbc1 =new GridBagConstraints();

          jp2.setLayout(gb1);
          gbc1.weightx=1;
          gbc1.weighty=1;
          gbc1.gridheight=1;
          gbc1.gridwidth=1;

         JLabel jl1=new JLabel("company_name");
         gbc1.gridx=0;
         gbc1.gridy=1;

        jp2.add(jl1,gbc1);
        gbc1.gridx  =  1;
        gbc1.gridy   = 1;
        jt1 =  new JTextField(25);
        jp2.add(jt1,gbc1);
        JLabel jl2=new JLabel("year");
        gbc1.gridx=0;
        gbc1.gridy=2;

        jp2.add(jl2,gbc1);
        gbc1.gridx  =  1;
        gbc1.gridy   = 2;
       jt2 =  new JTextField(25);
       jp2.add(jt2,gbc1);

       jb1=new JButton("Exit");
       gbc1.gridx=0;
       gbc1.gridy=3;
       jb1.addActionListener(this);
       jp2.add(jb1,gbc1);

       gbc1.gridx  =  1;
       gbc1.gridy   = 3;
       jb2 =  new JButton("OK");

      jb2.addActionListener(this);
      jp2.add(jb2,gbc1);
      cp.add(jp2,"South");

       setVisible(true);
     }
     catch(Exception e)
     {
        System.out.println("\nOracle ki error : "+e);
     }


    }
      
            
   public void  actionPerformed(ActionEvent ae)
    {
        int i1=0;
        final String[] colHeads ={"Company_id","Company_Name", "Address" ,"Phone_no","Email id","Year","Month"};

       Object source=ae.getSource();
       if (source == jb2)
       try
       {
            System.out.println("hello !!!  alright");
            String[][] data=new String[10][7];
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
      
             
        if (!jt1.getText().equals("") && !jt2.getText().equals(""))
            rs = st.executeQuery("select Company_details.company_id,Company_name,Company_address,Company_phone_no,Company_Email_id,Company_year,Company_Month from Company_details ,Company_year where  Company_details.Company_id=Company_year.Company_id and ( Company_name ='"+jt1.getText()+"'and Company_year ='"+jt2.getText()+"') ");

          else if (jt2.getText().equals("")  && !jt1.getText().equals("") )
           rs=  st.executeQuery("select Company_details.company_id,Company_name,Company_address,Company_phone_no,Company_Email_id,Company_year,Company_Month from Company_details ,Company_year where  Company_details.Company_id=Company_year.Company_id and  Company_name ='"+jt1.getText()+"' ");
          
         else if(jt1.getText().equals("")  && !jt2.getText().equals(""))
           rs=  st.executeQuery("select Company_details.company_id,Company_name,Company_address,Company_phone_no,Company_Email_id,Company_year,Company_Month from Company_details ,Company_year where  Company_details.Company_id=Company_year.Company_id and Company_year ='"+jt2.getText()+"'");
       else
         JOptionPane.showMessageDialog(null,"record does not exists");


  while(rs.next())
  {
       int  j1=0;
          while(j1<7)
          {
                    data[i1][j1]=rs.getString(j1+1);
                    j1++;
          }
          i1++;
  }
          jp1.remove(jsp);
          table = new JTable (data,colHeads);                                                                             
          jsp= new JScrollPane(table,v,h);
          jp1.add(jsp);
          cp.add(jp1,"North");
       }
      catch(Exception e)
      {}

  }
     
}

