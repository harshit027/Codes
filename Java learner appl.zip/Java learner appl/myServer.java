import java.net.*;
import java.io.*;

class myServer
{
	public static void main(String ada[]) 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String str="";
		try
        {   System.out.println("aaaaaa");
            ServerSocket server=new ServerSocket(8189);
			Socket clientSocket = server.accept();
			InputStream myIS=clientSocket.getInputStream();
			OutputStream myOS=clientSocket.getOutputStream();
			BufferedReader mySocketIS=new BufferedReader(new InputStreamReader(myIS));
			PrintWriter mySocketOS=new PrintWriter(new BufferedWriter(new OutputStreamWriter(myOS)),true);
			System.out.println("Client Contacted :"+clientSocket);
			mySocketOS.println("\nHello Client !!! Welcome in PACE");
			while(!str.equals("bye"))
			{
				str=mySocketIS.readLine();
				System.out.println("Client Sent : "+str);
				System.out.println("\nEnter Response : ");
				str=br.readLine();
				System.out.println("Sent : "+str+" :to Client");
				mySocketOS.println(str);
			}
			
		}
		catch(Exception e){}
	}
}
