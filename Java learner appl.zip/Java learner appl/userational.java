import rational.*;

class userational
{
	public static void main(String fsjk[])
	{
		myrational x=new myrational(50,60);
		myrational y=new myrational(50,60);
		myrational z=new myrational();
		y.get_data();
		z=x.add(y);
		x.show_data();
		y.show_data();
		z.show_data();
	}
}