import java.net.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class winServer extends JFrame implements ActionListener
{
	
        JButton btn;
        JTextArea jta;
        JTextField jtf;
        ImageIcon ico,ico1,ico2;
        public static void main(String args[]) throws Exception
        {
                new winServer();
        }
        winServer() throws Exception
        {
                ico=new ImageIcon("hlpcd.gif");
                ico1=new ImageIcon("hlpglobe.gif");
                ico2=new ImageIcon("hlpbell.gif");
                btn=new JButton("SERVER SEND",ico1);
                btn.setRolloverIcon(ico2);
                btn.setPressedIcon(ico);
                jta=new JTextArea(20 ,20);
                jtf=new JTextField(20);
                getContentPane().setLayout(new FlowLayout());
                getContentPane().add(jta);
                getContentPane().add(jtf);
                getContentPane().add(btn);
                getContentPane().setBackground(Color.lightGray);
                btn.addActionListener(this);
                show();
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                String str="";
                StringBuffer s=new StringBuffer(jta.getText());
                try
                {
                     ServerSocket server=new ServerSocket(1400);
                     Socket clientSocket = server.accept();
                     InputStream myIS=clientSocket.getInputStream();
                     OutputStream myOS=clientSocket.getOutputStream();
                     BufferedReader mySocketIS=new BufferedReader(new InputStreamReader(myIS));
                     PrintWriter mySocketOS=new PrintWriter(new BufferedWriter(new OutputStreamWriter(myOS)),true);
                     //System.out.println("Client Contacted :"+clientSocket);
                     mySocketOS.println("\nHello Client !!! Welcome in PACE");
                     //while(!str.equals("bye"))
                     //{
                            str=mySocketIS.readLine();
                            jta.setText("Client Sent : "+str);
                            jtf.setText("\nEnter Response : ");
                            jtf.select(0,jtf.getText().length());
                            str=jtf.getText();
                            //str=br.readLine();
                            jta.setText("Sent : "+str+" :to Client");
                            mySocketOS.println(str);
                      //}
                 }
                 catch(Exception e){}
                 repaint();

	}
        public void actionPerformed(ActionEvent ae)
        {       
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
                String str="";
                StringBuffer s=new StringBuffer(jta.getText());
                try
                {
                     ServerSocket server=new ServerSocket(1400);
                     Socket clientSocket = server.accept();
                     InputStream myIS=clientSocket.getInputStream();
                     OutputStream myOS=clientSocket.getOutputStream();
                     BufferedReader mySocketIS=new BufferedReader(new InputStreamReader(myIS));
                     PrintWriter mySocketOS=new PrintWriter(new BufferedWriter(new OutputStreamWriter(myOS)),true);
                     //System.out.println("Client Contacted :"+clientSocket);
                     mySocketOS.println("\nHello Client !!! Welcome in PACE");
                     while(!str.equals("bye"))
                     {
                            str=mySocketIS.readLine();
                            jta.setText("Client Sent : "+str);
                            jtf.setText("\nEnter Response : ");
                            jtf.select(0,jtf.getText().length());
                            str=jtf.getText();
                            str=br.readLine();
                            jta.setText("Sent : "+str+" :to Client");
                            mySocketOS.println(str);
                      }
                 }
                 catch(Exception e){}
         }
}
