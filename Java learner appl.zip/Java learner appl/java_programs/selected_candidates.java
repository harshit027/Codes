import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.io.*;
class selected_candidates extends JFrame implements ActionListener
{
JTextField jt1,jt2,jt3,jt4,jt5;
JComboBox jc1,jc2,jc3;
String name[];
Connection con;
Statement st;
ResultSet rs,rs1,rs2;
JButton jb1,jb2;
String name1,roll,ph,eid,br; 

 public static void main(String args[])
  {
    new selected_candidates();
  }
  selected_candidates()
{
  super("SELECTED_CANDIDATES");
  setSize(600,600);
  setVisible(true);
 
  WindowListener l = new WindowAdapter()
  {
   public void windowClosing(WindowEvent we)
   {
    System.exit(0);
   }
  };
 addWindowListener(l);

 GridBagLayout gb = new GridBagLayout();
 GridBagConstraints gbc = new GridBagConstraints();
 Container cp = getContentPane();
 JPanel jp = new JPanel();

 jp.setLayout(gb);
 jp.setBorder(BorderFactory.createCompoundBorder());
 gbc.gridwidth=1;
 gbc.gridheight=1;
 gbc.weightx=0.1;
 gbc.weighty=0.1; 

 JLabel jl1 = new JLabel("Roll_no"); 
 JLabel jl2 = new JLabel("Name"); 
 JLabel jl3 = new JLabel("Phone_no"); 
 JLabel jl4 = new JLabel("Email_id"); 
 JLabel jl5 = new JLabel("Branch"); 
 JLabel jl6 = new JLabel("Company_name"); 
 JLabel jl7 = new JLabel("Year");
 JLabel jl8 = new JLabel("Month");
  jt1 = new JTextField(15);
  jt2 = new JTextField(15);
  jt3 = new JTextField(15);
  jt4 = new JTextField(15);
  jt5 = new JTextField(15);
 
 jc1=new JComboBox();
 jc2=new JComboBox();
 jc3=new JComboBox(); 
 

 name = new String [50]; 

for(int i=1970;i<=2040;i++)
{
jc2.addItem(i+""); 
}
jc3.addItem("January"); 
jc3.addItem("February"); 
jc3.addItem("March"); 
jc3.addItem("April"); 
jc3.addItem("May"); 
jc3.addItem("June"); 
jc3.addItem("July"); 
jc3.addItem("August"); 
jc3.addItem("September"); 
jc3.addItem("October"); 
jc3.addItem("November"); 
jc3.addItem("December"); 

try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
             con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
             st   = con.createStatement();
            String qry11="select company_name";
            qry11+=" from company_details  ";
                  
             rs = st.executeQuery(qry11);
            
                 int i=0;        
            while(rs.next())
             
            {
             name[i]=rs.getString("company_name"); 
             i++;
            }
             int j=0;  
             while(j<i)
              {
              jc1.addItem(name[j]);
                j++;
              } 
           }
             catch(Exception e)
            {
                    System.out.println("Error : "+e);
            }

   jb1=new JButton("OK");
   jb2=new JButton("CANCEL");

 
 gbc.gridx=0;
 gbc.gridy=0;
 jp.add(jl1,gbc);

 gbc.gridx=2;
 gbc.gridy=0;
 jp.add(jt1,gbc);

 gbc.gridx=0;
 gbc.gridy=2;
 jp.add(jl2,gbc);

 gbc.gridx=2;
 gbc.gridy=2;
 jp.add(jt2,gbc);

 gbc.gridx=0;
 gbc.gridy=4;
 jp.add(jl3,gbc);

 gbc.gridx=2;
 gbc.gridy=4;
 jp.add(jt3,gbc);
 
 gbc.gridx=0;
 gbc.gridy=6;
 jp.add(jl4,gbc);

 gbc.gridx=2;
 gbc.gridy=6;
 jp.add(jt4,gbc);
 
 gbc.gridx=0;
 gbc.gridy=8;
 jp.add(jl5,gbc);

 gbc.gridx=2;
 gbc.gridy=8;
 jp.add(jt5,gbc);
 
 gbc.gridx=0;
 gbc.gridy=10;
 jp.add(jl6,gbc);

 gbc.gridx=2;
 gbc.gridy=10;
 jp.add(jc1,gbc);
 
 gbc.gridx=0;
 gbc.gridy=12;
 jp.add(jl7,gbc);

 gbc.gridx=2;
 gbc.gridy=12;
 jp.add(jc2,gbc);
 
 gbc.gridx=0;
 gbc.gridy=14;
 jp.add(jl8,gbc);

 gbc.gridx=2;
 gbc.gridy=14;
 jp.add(jc3,gbc);
 
 gbc.gridx=1;
 gbc.gridy=80;
jp.add(jb1,gbc);


 gbc.gridx=2;
 gbc.gridy=80;
jp.add(jb2,gbc);
 


jt1.addActionListener(this);
jb1.addActionListener(this);
setResizable(false);
cp.add(jp); 

  }


public void actionPerformed(ActionEvent ae)
{
      int flag1=0;
       Object source=ae.getSource();
        if (source == jt1)
         try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
             con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
             st   = con.createStatement();

            String qry12="select roll_no";
            qry12+=" from s_records where roll_no='"+jt1.getText()+"'  ";
            rs2=st.executeQuery(qry12)  ;
            while(rs2.next())
             {
             
              flag1=1;
            }
         if(flag1==0)
        {

            String qry11="select name,phone_no,email_id,branch";
            qry11+=" from student_data where roll_no='"+jt1.getText()+"'  ";
            rs1 = st.executeQuery(qry11);     
            int flag=0;
            
                int i1=0;        
            while(rs1.next())
             
            {
             name1=rs1.getString("name"); 
             ph=rs1.getString("phone_no");
             eid=rs1.getString("email_id");
             br=rs1.getString("branch");  
            jt2.setText(name1);
            jt3.setText(ph);
            jt4.setText(eid);
            jt5.setText(br);
            flag=1;
           
             }
             
            if(flag==0)
            {
               JOptionPane.showMessageDialog(this,"Sorry! not a valid roll_no");
            jt1.setText("");
            jt2.setText("");
            jt3.setText("");
            jt4.setText("");
            jt5.setText("");
               
            }
           }
           if(flag1==1)
            {
            jt1.setText("");          
            JOptionPane.showMessageDialog(this,"Sorry! this is already been entered");
           
             }

            }
             catch(Exception e)
            {
                    System.out.println("Error : "+e);
            }
         if(source == jb1)
         {

         try{
	    
             
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
            st   = con.createStatement();
            String insertqry1="insert into s_records values ('"+jt1.getText()+"','"+jt2.getText()+"','"+jt3.getText()+"','"+jt4.getText()+"','"+jt5.getText()+"','"+jc1.getSelectedItem()+"','"+jc2.getSelectedItem()+"','"+jc3.getSelectedItem()+"')";
            int t=st.executeUpdate(insertqry1);
            new myProgMon();
            jt1.setText("");
            jt2.setText("");
            jt3.setText("");
            jt4.setText("");
            jt5.setText("");
            
          }

        catch(Exception e)
        {System.out.println("ARRE ERROR HAI"+e);
         }
}

}
}