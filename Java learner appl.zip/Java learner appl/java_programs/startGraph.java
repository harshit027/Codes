import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class startGraph 
{ int  a[]={count1,count2,count3,count4,count5,count6,count7,count8};
		
	/*public static void main(String sdfs[])
	{
            new myGraph(a,"Hello Graph");
	}*/
}

 class startGraph extends JFrame
{
	startGraph(int a[],String title)
	{
		super(title);
		myGraphPanel p=new myGraphPanel(a);
		getContentPane().add(p);
		setSize(300,300);
		show();
	}
}

  class myGraphPanel extends JPanel
{
	int b[];
	int x=20;
	myGraphPanel(int a[])
	{
		b=a;
	}
	public void paint(Graphics g)
	{
		Color c[]={Color.red,Color.green,Color.blue,Color.yellow,Color.magenta};
		x=20;
		for (int i=0;i<5;i++)
		{
			g.setColor(c[i]);
			g.fillRect(x,230-b[i],30,b[i]+30);
			x+=60;
		}
	}
}
