import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

class myJDBC extends JFrame implements ActionListener
{
	JTextField bid,bname,bauthor;
	JButton next,addnew,saveData;
	JLabel lblbid,lblbname,lblbauthor;
	Connection con;
	Statement st;
	ResultSet rs;
	myJDBC()
	{
		Container cp=getContentPane();
		cp.setLayout(new GridLayout(5,2));
		bid=new JTextField();
		bname=new JTextField();
		bauthor=new JTextField();
		lblbid=new JLabel("Book ID");
		lblbname=new JLabel("Book Name");
		lblbauthor=new JLabel("Book Author");
		next=new JButton("MoveNext");
		addnew=new JButton("Add New Record");
		saveData=new JButton("Save Data");
		cp.add(lblbid);
		cp.add(bid);
		cp.add(lblbname);
		cp.add(bname);
		cp.add(lblbauthor);
		cp.add(bauthor);
		cp.add(next);
		cp.add(saveData);
		cp.add(addnew);
		
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			con=DriverManager.getConnection("jdbc:odbc:myJavaDSN","scott","tiger");
			st=con.createStatement();
			rs=st.executeQuery("select * from book");
			rs.next();
			//bid.setText(rs.getString("dname"));
			bid.setText(rs.getString("bookid"));
			bname.setText(rs.getString("bookname"));
			bauthor.setText(rs.getString("bookauthor"));
		}
		catch(Exception e)
		{
			System.out.println("Error in Connection  : " +e);
		}
		next.addActionListener(this);
		addnew.addActionListener(this);
		saveData.addActionListener(this);

		setSize(500,200);
		setVisible(true);
	}
	public static void main(String args[])
	{
		new myJDBC();
	}
	public void actionPerformed(ActionEvent ae)
	{
		JButton btn=(JButton)ae.getSource();
		if(btn==next)
		{
			try
			{
				if (rs.next())
				{
					bid.setText(rs.getString("bookid"));
					bname.setText(rs.getString("bookname"));
					bauthor.setText(rs.getString("bookauthor"));
				}
			}
			catch(Exception e)
			{
				System.out.println("Error in Connection  : " +e);
			}
		}
		if(btn==addnew)
		{
			bid.setText("");
			bname.setText("");
			bauthor.setText("");
		}
		if(btn==saveData)
		{
			try
			{
				int t=st.executeUpdate("insert into book values ("+Integer.parseInt(bid.getText())+",'"+bname.getText()+"','"+bauthor.getText()+"')");
				if(t==0)
				{
					//JOptionPane.showMessageDialog("Error in insertion");
				}
			}
			catch(Exception e){}
		}
	}
}0....