import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;
//import java.awt.datatransfer.*;

 public class DataExchangeTest1 extends JFrame
{
	public static user usr;

	public DataExchangeTest1()
	{
	       ConnectInfo transfer=new ConnectInfo("","");
     		 //dialog= new ConnectDialog(this);

		 if(dialog==null)
		 {

			//   int selection=JOptionPane.showConfirmDialog(this,"Are you sure you want to quit","Confirmation",JOptionPane.OK_CANCEL_OPTION);
	              // if(selection==JOptionPane.CANCEL_OPTION)
			       dialog= new ConnectDialog(this);
		 }


		 if(dialog.showDialog(transfer))
		 {
			/* if(transfer.password=="preet")
			 {
			     JOptionPane.showMessageDialog(this,"u have successfully entered the password","Title",JOptionPane.OK_CANCEL_OPTION);
				*/
				usr= new user();

			 /*else
			 {
				  JOptionPane.showMessageDialog(this,"your key is wrong","Error!!",JOptionPane.OK_OPTION);
				  dialog.showDialog(transfer);
			 }*/
		 }

	}

/*-----------------------Function Main-------------------------- */
	/*public static void main(String args[])
	 {

		JFrame f=new DataExchangeTest1();


	 }*/

 	  private ConnectDialog dialog=null;

}

class ConnectInfo
{
	public String username;
	public String password;
	public ConnectInfo(String u,String p)
	{
		username=u;password=p;
	}
}

  class ConnectDialog extends JDialog implements ActionListener
{



	public ConnectDialog(JFrame parent)
	{
		super(parent,"Connect",true);
		Container contentPane=getContentPane();
		JPanel p1=new JPanel();
		p1.setLayout(new GridLayout(2,2));
		p1.add(new JLabel("User name:"));
		p1.add(username =new JTextField(""));
		username.setText("Pace Bureau");
		p1.add(new JLabel("Key:"));
		p1.add(password=new JPasswordField(""));
		contentPane.add("Center",p1);

		Panel p2=new Panel();
		okButton=addButton(p2,"ok");
		cancelButton=addButton(p2,"cancel");
		contentPane.add("South",p2);
		setLocation(150,150);
		setSize(240,120);

	}
	JButton addButton(Container c,String name)
	{
		JButton button=new JButton(name);
		button.addActionListener(this);
		c.add(button);
		return button;
	}
	public void actionPerformed(ActionEvent evt)
	{
		Object source=evt.getSource();
		if(source==okButton)
		{
			ok=true;
			setVisible(false);
		}
		else if(source==cancelButton)
			{
				setVisible(false);
			  	int selection=JOptionPane.showConfirmDialog(this,"Are you sure you want to quit","Confirmation",JOptionPane.OK_CANCEL_OPTION);
	               	if(selection==JOptionPane.CANCEL_OPTION)
					new DataExchangeTest1();

			}

	}
	public boolean showDialog(ConnectInfo transfer)
	{
		username.setText(transfer.username);
		password.setText(transfer.password);
		ok=false;
		show();
		regstr reg = new regstr();
		if(ok)
		{
			transfer.username=username.getText();
			transfer.password=new String(password.getPassword());
			System.out.println("key-: "+reg.keykey);
			String localKey=getLocalKey();
			 if(transfer.password.equals(localKey))
			 {
						JOptionPane.showMessageDialog(this,"u have successfully entered the password","Title",JOptionPane.OK_CANCEL_OPTION);
						ok=true;
			 }
			 else
			 {
				 ok=false;
				 JOptionPane.showMessageDialog(this,"your key is wrong","Error!!",JOptionPane.OK_OPTION);
				 new DataExchangeTest1();
			 }

		}
		return ok;
	}

	String getLocalKey()
	{
		int finalKey[]=new int[5];
		String keykey="";
		int k=0;
		try
		{
			FileReader hfr=new FileReader("myf.pak");
			BufferedReader hbr=new BufferedReader(hfr);
			String str=new String();
			char ch[]=new char[9];
			char ch1[]=new char[9];
			char ch2[]=new char[9];
			str=hbr.readLine();
			str=hbr.readLine();
			str=hbr.readLine();
			str.getChars(25,34,ch2,0);
			System.out.println(ch2);


			for(int i=0;i<=8;i+=2)
			{
				int m=(int)ch2[i];
				int n=0;
				if(i<8)
					n=(int)ch2[i+1];
				m=m+n;
				n=0;
				while(m>0)
				{
					n+=m%10;
					m/=10;
					if(m==0 && n>9)
					{
						m=n;n=0;
					}
				}
				finalKey[k++]=n;
			}
			keykey=finalKey[0]+"";
			for(int i=1;i<5;i++)
			{
				keykey+=finalKey[i]+"";
			}
			System.out.println("your key is :"+keykey);
		}
		catch(Exception e)
		{}
		return keykey;
	}
	JTextField username;
	JPasswordField password;
	private boolean ok;
	JButton okButton;
	JButton cancelButton;
}
