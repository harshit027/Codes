import java.awt.*;
import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;

 public class progressbar
 {
  public ststic void main(String[] args)
  {
   JFrame frame = new ProgressMonitorFrame();
   frame.show();
  }

  class ProgressMonitorFrame extends JFrame
  {
   public ProgressMonitorFrame()
   {
    setTitle("ProgressBar");
    setSize(300,200);
    addWindowListener(new WindowAdapter()
    {
     public void windowClosing(WindowEvent e)
     {
       System.exit(0);
     }
    });

