import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code= "chess" width= 200 height=200>
</applet>
*/
public class chess extends Applet
{
       
    // d.getsize();
    int x=0,y=0;

/*     ToolKit tk=ToolKit.getDefaultToolKit();
        Dimension d=tk.getScreenSize();*/
      Dimension d=getSize(); 

    public void paint(Graphics g)
    {
    x=d.width;
    y=d.height;
   int a=x/64;
   int b= y/64;

       /* for(int i=0;i<=200-x;i+=x)
         {
            for(int j=0;j<=200-y;j+=y)
           {
                g.drawRect(i,j,x,y);
            }
         }*/
    g.drawRect(67,98,x,y);

    }

}

