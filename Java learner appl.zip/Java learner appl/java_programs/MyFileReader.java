import java.io.*;
class MyFileReader
{
	public static void main(String args[]) throws Exception
	{
		File f=new File("e:\\old\\java_programs\\MyFileReader.java");
		//FileInputStream fis = new FileInputStream(f);
		char c[]=new char[1];
		FileReader fis = new FileReader(f);
		while( fis.read(c)>0 )
		{
			System.out.print((char)c[0]);
		}
		fis.close();
	}
}