import java.net.*;
import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class winClient extends JFrame implements ActionListener
{
	
	JButton btn;
	JTextArea jta;
        JTextField jtf;
        ImageIcon ico,ico1,ico2;
        public static void main(String args[])
        {
                new winClient();
        }
        winClient()
        {
                ico=new ImageIcon("hlpcd.gif");
                ico1=new ImageIcon("hlpglobe.gif");
                ico2=new ImageIcon("hlpbell.gif");
                btn=new JButton("SEND",ico1);
                btn.setRolloverIcon(ico2);
                btn.setPressedIcon(ico);
                jta=new JTextArea(20 ,20);
                jtf=new JTextField(20);
                getContentPane().setLayout(new FlowLayout());
                getContentPane().add(jta);
                getContentPane().add(jtf);
                getContentPane().add(btn);
                getContentPane().setBackground(Color.lightGray);
                btn.addActionListener(this);
                show();
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String str="";
		try
		{
			Socket client=new Socket("202.54.4.11",1400);
			InputStream myIS=client.getInputStream();
			OutputStream myOS=client.getOutputStream();
			BufferedReader mySocketIS=new BufferedReader(new InputStreamReader(myIS));
			PrintWriter mySocketOS=new PrintWriter(new BufferedWriter(new OutputStreamWriter(myOS)),true);
			str=mySocketIS.readLine();
                        //System.out.println("Server Sent : "+str);
                        //while(str.equals("bye")==false)
                        //{
				str=mySocketIS.readLine();
                                jta.append("Server Sent : "+str);
                                //System.out.println("Server Sent : "+str);
                                //System.out.println("\nEnter Response : ");
                                jtf.setText("\nEnter Response : ");
                                jtf.select(0,jtf.getText().length());
                                str=jtf.getText();
                                //str=br.readLine();
                                //System.out.println("Sent : "+str+" :to Server");
                                jtf.setText("Sent : "+str+" :to Server");
				mySocketOS.println(str);
                        //}
			
		}
                 catch(Exception e){}
                 repaint();

	}
        public void actionPerformed(ActionEvent ae)
        {
                BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String str="";
		try
		{
			Socket client=new Socket("202.54.4.11",1400);
			InputStream myIS=client.getInputStream();
			OutputStream myOS=client.getOutputStream();
			BufferedReader mySocketIS=new BufferedReader(new InputStreamReader(myIS));
			PrintWriter mySocketOS=new PrintWriter(new BufferedWriter(new OutputStreamWriter(myOS)),true);
			str=mySocketIS.readLine();
                        //System.out.println("Server Sent : "+str);
                        while(str.equals("bye")==false)
                        {
				str=mySocketIS.readLine();
                                jta.append("Server Sent : "+str);
                                //System.out.println("Server Sent : "+str);
                                //System.out.println("\nEnter Response : ");
                                jtf.setText("\nEnter Response : ");
                                jtf.select(0,jtf.getText().length());
                                str=jtf.getText();
                                //str=br.readLine();
                                //System.out.println("Sent : "+str+" :to Server");
                                jtf.setText("Sent : "+str+" :to Server");
				mySocketOS.println(str);
                        }
			
		}
         catch(Exception e){}
        }         
       
}
