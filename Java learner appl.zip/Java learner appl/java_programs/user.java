//package enc;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.lang.Object.*;
import javax.swing.JToolBar.*;
import java.awt.datatransfer.*;
import javax.swing.undo.*;
import javax.swing.text.*;
import javax.swing.event.*;
import java.util.Hashtable;
import java.io.*;
import java.util.Date;

class user extends JFrame implements ActionListener,FocusListener,KeyListener
{
	JMenuBar jmb;
	JMenu jm[];
	String temp,temp1,temp2;
	boolean flag=true;
	JMenuItem jmi[],jmi1[],jmi2,jmi3,popjmi[];
	JPanel p,p1;
	JButton btn[];
	JScrollPane jsp;
	JTextArea jta;
	JTextPane textPane;
	JLabel jlb;
    Date date;
	ImageIcon icon;
	JToolBar toolBar;
	JPopupMenu popup;

	String open;

	final Toolkit kit;
                final Clipboard clipboard;

	static final int MAX_CHARACTERS = 300;

	Color myColor=Color.orange;

      keyword11R x=new keyword11R();

	user()
	{
		setTitle("Pace Bureau");

		jmb=new JMenuBar();
		jm=new JMenu[3];
		jm[0]=new JMenu("File");
		jm[1]=new JMenu("Edit");
		jm[2]=new JMenu("Help");


		jmi=new JMenuItem[4];
		jmi[0]=new JMenuItem("New",new ImageIcon("new.gif"));
		jmi[0].setEnabled(false);
		jmi[1]=new JMenuItem("Open");

		jmi[1].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_1, ActionEvent.ALT_MASK));

		jmi[2]=new JMenuItem("Save");
		jmi[2].setEnabled(false);

		jm[1].addSeparator();
		jmi[3]=new JMenuItem("Close");
		jm[0].add(jmi[0]);
		jm[0].add(jmi[1]);
		jm[0].add(jmi[2]);
		jm[0].add(jmi[3]);


		jmi1=new JMenuItem[6];
		jmi1[0]=new JMenuItem("Undo",new ImageIcon("undo.gif"));
		jmi1[0].setEnabled(false);
		jmi1[1]=new JMenuItem("Cut",new ImageIcon("cut.gif"));
		jmi1[1].setEnabled(false);
		jmi1[2]=new JMenuItem("Copy",new ImageIcon("copy.gif"));
		jmi1[2].setEnabled(false);
		jmi1[3]=new JMenuItem("Paste",new ImageIcon("paste.gif"));
		jmi1[3].setEnabled(false);
		jmi1[4]=new JMenuItem("Delete",new ImageIcon("delete.gif"));
		jmi1[4].setEnabled(false);
		//menu.addSeparator();
		jmi1[5]=new JMenuItem("Select All",'A');
		jmi1[5].setEnabled(false);

		for(int i=0;i<6;i++)
		{
			jm[1].add(jmi1[i]);
			jmi1[i].addActionListener(this);
		}


		jmi2=new JMenuItem();
		jmi2=new JMenuItem("About Editor");
		jm[2].add(jmi2);
		for(int i=0;i<=2;i++)
		{
			jmb.add(jm[i]);
			jmi[i].addActionListener(this);
		}

		jmi2.addActionListener(this);

		p=new JPanel();
		p1=new JPanel();
		p.setBackground(myColor);
		p1.setBackground(myColor);
		p.repaint();


		getContentPane().setLayout(new BorderLayout());
		jta=new JTextArea(27,56);
		jta.setEditable(false);
		jsp=new JScrollPane(jta);
		p.add(jsp);
		jta.addKeyListener(this);
		getContentPane().add(p,"East");
		getContentPane().add(p1,"South");
		setJMenuBar(jmb);
		setSize(800,560);
		setLocation(0,0);

		//Adding Image on to the JLabel
		icon = new ImageIcon("abt1.jpg");
    	jlb = new JLabel(icon,JLabel.LEFT);
		getContentPane().add(jlb);

		kit = Toolkit.getDefaultToolkit();
        clipboard = kit.getSystemClipboard();


///////////////////////////////////////////////////////////////////


		//Create the popup menu.

        popup = new JPopupMenu();
		popjmi=new JMenuItem[6];
        popjmi[0] = new JMenuItem("Undo");
        popjmi[0].addActionListener(this);
        popup.add(popjmi[0]);
        popjmi[0].setEnabled(false);

        popup.addSeparator();

        popjmi[1] = new JMenuItem("Cut");
        popjmi[1].addActionListener(this);
        popup.add(popjmi[1]);
        popjmi[1].setEnabled(false);

		popjmi[2] = new JMenuItem("Copy");
        popjmi[2].addActionListener(this);
        popup.add(popjmi[2]);
        popjmi[2].setEnabled(false);

		popjmi[3] = new JMenuItem("Paste");
        popjmi[3].addActionListener(this);
        popup.add(popjmi[3]);
        popjmi[3].setEnabled(false);

		popjmi[4] = new JMenuItem("Delete");
        popjmi[4].addActionListener(this);
        popup.add(popjmi[4]);
        popjmi[4].setEnabled(false);

		popup.addSeparator();

		popjmi[5] = new JMenuItem("Select All");
        popjmi[5].addActionListener(this);
        popup.add(popjmi[5]);
		popjmi[5].setEnabled(false);

		//Add listener to components that can bring up popup menus.
        MouseListener popupListener = new PopupListener();
        jta.addMouseListener(popupListener);
        jsp.addMouseListener(popupListener);
        jmb.addMouseListener(popupListener);

       /*------------------ToolBar------------------------------------------*/

		toolBar = new JToolBar()
		{
			public boolean isFocusTraversable()
			{
				return true;
			}
		};


		toolBar.addFocusListener(this);

 		toolBar.add( new JButton(new ImageIcon("cut.gif")));
		toolBar.add( new JButton(new ImageIcon("copy.gif")));
 		toolBar.add( new JButton(new ImageIcon("paste.gif")) );
 		toolBar.add( new JButton(new ImageIcon("bold.gif")) );
		toolBar.add( new JButton(new ImageIcon("italic.gif")) );
		toolBar.add( new JButton(new ImageIcon("underline.gif")) );
		toolBar.setEnabled(false);

		getContentPane().add( toolBar, BorderLayout.NORTH );

		show();

}              //--------------------------------------------------CLOSING CONSTRUCTOR

	public void focusGained(FocusEvent e)
	{
		//System.out.println("gained");
	}

	public void focusLost(FocusEvent e)
	{
		//System.out.println("lost");
	}

/*------------------------------- Function Main ------------------------------------------*/

	/*public static void main(String args[])
	 throws Exception{

		JFrame f=new user();
		f.show();

	 }*/
	public void keyPressed(KeyEvent ke)
	{
		int kcode=ke.getKeyCode();
		if(kcode==ke.VK_CONTROL)
		{
			JOptionPane.showMessageDialog(this,"it can not be 			cut,copy or paste","error",JOptionPane.OK_OPTION);
		}


	}
	public void keyReleased(KeyEvent ke)
	{}
	public void keyTyped(KeyEvent ke)
	{}
//////////////////////////////////////////////////////////////////

	 class PopupListener extends MouseAdapter
	 {
        	public void mousePressed(MouseEvent e)
		{
            		maybeShowPopup(e);
        	}

	        public void mouseReleased(MouseEvent e)
		{
        		maybeShowPopup(e);
        	}

        	private void maybeShowPopup(MouseEvent e)
		{
            		if (e.isPopupTrigger())
			{
                		popup.show(e.getComponent(),e.getX(), e.getY());
            		}
        	}
	 }

//////////////////////////////////////////////////////////////////


	public void actionPerformed(ActionEvent ae)
	{
		JMenuItem mit=(JMenuItem)ae.getSource();
		JFileChooser jfc = new JFileChooser();
		JFrame jf=new JFrame();

/*--------For New ------------------*/


		if(mit==jmi[0])
		{
			jta.setText("");
		}


/*--------For Open Dialog Box--------*/

		if(mit==jmi[1])
		{
			try{
						String str1="", str="";
						String ext="";
						int opendia=jfc.showOpenDialog(jf);
						if (opendia == JFileChooser.APPROVE_OPTION)
		     			{
							open=jfc.getSelectedFile().getName();

							int i = open.lastIndexOf('.');
						 	if (i > 0 && i < open.length() - 1)
							{
								 ext = open.substring(i+1).toLowerCase();
							}

							if(ext.equals("prv"))
							{
								x.keyGenerate();
								jta.setText(x.getDecryption(open));
								jmi[2].setEnabled(true);
							}
							else
							{
								JOptionPane.showMessageDialog(this,"Error!! : You can open only .prv files. ","Error",JOptionPane.OK_OPTION);

							}
				   		}
				}

			catch(Exception e)
	    		   {
						System.out.println("Error in reading file : "+e);
			   }
		}

/*--------For Save Dialog Box--------*/

		if(mit==jmi[2])
		{
		try{
		     int returnVal = jfc.showSaveDialog(jf);

                 if (returnVal == JFileChooser.APPROVE_OPTION)
		     	{
                    File file = jfc.getSelectedFile();
                    String save=file.getName();

			 	 	String strenc=jta.getText();
					String readenc="",readenc1="";

					int bool=strenc.length();
					if((bool%2)==1)
					{
						strenc=strenc+'.';
					}

                		x.keyGenerate();
                		x.getEncryption(strenc,save+".prv");

			 	 }


			}
			catch(IOException ioe)
			{
				System.out.println(ioe);
			}
		}

/*--------For Closing Window--------*/

        if(mit==jmi[4])
		{
			jta.setText("");
		}

/*--------For Undo Manager----------*/

/*		if(mit==jmi1[0])
		{
			temp1=temp;
			temp=jta.getText();
			//jta.setText(temp);
			flag=true;
		}
----------For Cut Function---------

		if((mit==jmi1[1]))
		{
			temp2=jta.getText();
			String selection = jta.getSelectedText();
			temp=selection;
			jta.replaceSelection("");
	        StringSelection data = new StringSelection(selection);
        	clipboard.setContents(data,data);
		}

--------For Copy Function----------

		if((mit==jmi1[2]))
		{
			String selection = jta.getSelectedText();
        	StringSelection data = new StringSelection(selection);
        	clipboard.setContents(data, data);
		}

--------For Paste Function---------

		if((mit==jmi1[3]))
		{
			Transferable clipData = clipboard.getContents(clipboard);
        	if (clipData != null)
			{
          		   try
		       	   {
            			if (clipData.isDataFlavorSupported(DataFlavor.stringFlavor))
				{
             				String s = (String)(clipData.getTransferData(DataFlavor.stringFlavor));
             	 			jta.replaceSelection(s);
            			}
				else
				{
              	 			kit.beep();
            			}
         		   }
	 		   catch (Exception e)
	 		   {
           	 		System.err.println("Problems getting data:" + e);
         		   }
        		}
		 }

----------For Delete Function---------

		if((mit==jmi1[4]))
		{

			jta.replaceSelection("");
		}

----------For Select All Function---------

		if((mit==jmi1[5]))
		{
			jta.selectAll();
		}
-----------For Date and Time------------
		if((mit==jmi1[10]))
		{
			date =new Date();
			long msec=date.getTime();
			jta.append(date+""+msec+"");
		}*/

	}

}
