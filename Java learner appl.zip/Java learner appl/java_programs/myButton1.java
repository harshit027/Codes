import java.awt.*;
import java.awt.event.*;
/*
	<applet code="myButton.class" width=300 height=300>
	</applet>
*/
public class myButton extends java.applet.Applet implements ActionListener
{
       Button btn;
	public void init()
	{
		btn=new Button("Open a New Window");
		add(btn);
		btn.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		new myWindow();
	}
}

class myWindow extends Frame
{
	myWindow()
	{
		super("My Java Window");
		setSize(100,100);
		setBackground(Color.cyan);
		addWindowListener(
					new WindowAdapter()
					{
						public void windowClosing(WindowEvent we)
						{
							setVisible(false);
						}
					}
				);
		setVisible(true);
	}
}
