class myfirst
{
	public static void main(String args[])
	{
		System.out.println("PACE");
		System.out.println("PACE");
		System.out.print("PACE");
		System.out.println("PACE");
	}
}