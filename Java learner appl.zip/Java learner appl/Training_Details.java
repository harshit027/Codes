
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class Training_Details extends JFrame
{  
 public static void main(String args[])
 { 
  new Training_Details();
 }

 Training_Details()
{

  super("Trainees Records");
  setSize(800,800);
  setVisible(true);


  WindowListener l = new WindowAdapter()
  {
   public void windowClosing(WindowEvent we)
   {
    System.exit(0);
   }
  };
addWindowListener(l);

Container cp = getContentPane();
GridBagLayout gb = new GridBagLayout();
GridBagConstraints gbc =new GridBagConstraints();

cp.setLayout(gb);
gbc.weightx=1;
gbc.weighty=1;
gbc.gridx=0;
gbc.gridy=0;

final String[] colHeads ={"Roll_No.", "Name" ,"Branch", "Company_Name" ,"Year", "Time_Duration"};
final Object[][] data={
  {"0201ca021029 ", "Suparna Sen" , "M.C.A.", "Infosys" , "2004" ,"2 month" }

 };

 JTable table = new JTable (data,colHeads);
 int v= ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
 int h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
 JScrollPane jsp= new JScrollPane(table,v,h);
 cp.add(jsp);

 JButton jb1=new JButton("company_name");
  jb1.setToolTipText("view the companies providing Training");
  cp.add(jb1);

 JButton jb2=new JButton("year");
 jb2.setToolTipText("view the name of terinees");
  cp.add(jb2);

 JButton jb3=new JButton("Exit");

  cp.add(jb3);


   }
 }



