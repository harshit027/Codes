import java.io.*;
class MyFileReader
{
	public static void main(String args[]) throws Exception
	{
		File f=new File("e:\\old\\java_programs\\MyFileReader.java");
		char c[]=new char[1];
		FileReader fis = new FileReader(f);
		FileWriter fos = new FileWriter("temp");
		while( fis.read(c)>0 )
		{
			fos.write(c[0]);
		}
		fis.close();
		fos.close();
	}
}