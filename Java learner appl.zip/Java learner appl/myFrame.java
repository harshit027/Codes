import java.awt.*;
import java.awt.event.*;

   class myFrame extends  Frame
    {
       myFrame()
      {
      super("pace");
      setSize(200,200);
      setLocation(50,50);
      setVisible(true);
      }
     public static void main(String a[])
        {
        myFrame t=new myFrame();
        }
   }

