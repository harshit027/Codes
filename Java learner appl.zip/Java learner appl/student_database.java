import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class Student_Database extends JFrame
{  
 public static void main(String args[])
 { 
  JFrame jframe=new JFrame("Record of students");
  jframe.setSize(640,800);
  jframe.setVisible(true);
 
  //jframe.resizeable(false);
  WindowListener l = new WindowAdapter()
  {
   public void windowClosing(WindowEvent we)
   {
    System.exit(0);
   }
  };
 jframe.addWindowListener(l);

Container cp = jframe.getContentPane();
GridBagLayout gb = new GridBagLayout();
GridBagConstraints gbc =new GridBagConstraints();

cp.setLayout(gb);
gbc.weightx=1;
gbc.weighty=1;
gbc.gridx=0;
gbc.gridy=0;

final String[] colHeads ={"Roll_No.", "Name" ,"Father's name", "Category" ,"D.O.B.", "Phone no." ,"Course", "Branch","Semester" };
final Object[][] data={
  {"0201ca021020 ", "Amrita Koshta" , "J.P.Koshta", "OBC" , "07/07/81" ,"2649109" , "M.C.A","M.C.A","V"}
  };

 JTable table = new JTable (data,colHeads);
 int v= ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
 int h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
 JScrollPane jsp= new JScrollPane(table,v,h);
 cp.add(jsp);

 JButton jb1=new JButton("By Roll_no");
  jb1.setToolTipText("view the selected students companywise");
  cp.add(jb1);

 JButton jb2=new JButton("By Name");
 jb2.setToolTipText("view the selected students yearwise");
  cp.add(jb2);

 JButton jb4=new JButton("By Branch");
 jb4.setToolTipText("view the selected students yearwise");
  cp.add(jb4);


 JButton jb3=new JButton("Exit");

  cp.add(jb3);


   }
 }



