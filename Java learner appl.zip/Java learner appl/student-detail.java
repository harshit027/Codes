import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;
class students_details extends JFrame
{
public static void main(String args[])
{
JFrame jframe=new JFrame("students_details");
jframe.getContentPane().setLayout(new BorderLayout(0,0));
jframe.setSize(800,800);
jframe.setVisible(true);

WindowListener l=new WindowAdapter()
{
public void windowClosing(WindowEvent we)
{
System.exit(0);
}
};
jframe.addWindowListener(l);
Container cp=jframe.getContentPane();

JPanel  jp1;
jp1=new JPanel();

Border etched =BorderFactory.createEtchedBorder();
Border titled = BorderFactory.createTitledBorder(etched, "Personal Information");
jp1.setBorder(titled);

GridBagLayout gb=new GridBagLayout();
GridBagConstraints gbc = new GridBagConstraints();
jp1.setLayout(gb);

gbc.gridwidth=1;
gbc.gridheight=1;
gbc.weightx=1;
gbc.weighty=1;

JLabel jl1=new JLabel("Roll_no");
JLabel jl2=new JLabel("Name");
JLabel jl3=new JLabel("Category");
JLabel jl4=new JLabel("Date_Of_Birth");
JLabel jl5=new JLabel("Father Name");
JLabel jl6=new JLabel("Course");
JLabel jl7=new JLabel("Branch");
JLabel jl8=new JLabel("Semester");

JTextField jt1=new JTextField(15);
JTextField jt2=new JTextField(15);
JTextField jt3=new JTextField(15);
JTextField jt5=new JTextField(15);

JComboBox jc1 = new JComboBox();
JComboBox jc2 = new JComboBox();
JComboBox jc3 = new JComboBox();
JComboBox jc4 = new JComboBox();
JComboBox jc5 = new JComboBox();
JComboBox jc6 = new JComboBox();

jc1.addItem("M.C.A.");
jc1.addItem("B.E.");
jc1.addItem("M.E.");

jc2.addItem("Information Tecnology");
jc2.addItem("Electronics & Telecommunication");
jc2.addItem("Electrical");
jc2.addItem("Mecanical");
jc2.addItem("Civil");
jc2.addItem("Industrial Production");
jc2.addItem("ComputerScience");
jc2.addItem("M.C.A");
jc3.addItem("I");
jc3.addItem("II");
jc3.addItem("III");
jc3.addItem("IV");
jc3.addItem("V");
jc3.addItem("VI");
jc3.addItem("VII");
jc3.addItem("VIII");
for(int i =1;i<=31;i++)

{
jc4.addItem(i+"");
}
jc5.addItem("January");
jc5.addItem("February");
jc5.addItem("March");
jc5.addItem("April");
jc5.addItem("May");
jc5.addItem("June");
jc5.addItem("July");
jc5.addItem("August");
jc5.addItem("September");
jc5.addItem("October");
jc5.addItem("November");
jc5.addItem("December");
for(int k=1975;k<=2030;k++)
{
jc6.addItem(k+"");
 }

gbc.gridx=5;
gbc.gridy=5;
jp1.add(jl1,gbc);

gbc.gridx=10;
gbc.gridy=5;
jp1.add(jt1,gbc);

gbc.gridx=30;
gbc.gridy= 5;
jp1.add(jl2,gbc);

gbc.gridx= 40;
gbc.gridy=5;
jp1.add(jt2,gbc);

gbc.gridx=5;
gbc.gridy= 8;
jp1.add(jl3,gbc);

gbc.gridx=10;
gbc.gridy= 8;
jp1.add(jt3,gbc);

gbc.gridx=30;
gbc.gridy=8;
jp1.add(jl4,gbc);

gbc.gridx=40;
gbc.gridy=8;
jp1.add(jc4,gbc);

gbc.gridx=41;
gbc.gridy=8;
jp1.add(jc5,gbc);

gbc.gridx=42;
gbc.gridy=8;
jp1.add(jc6,gbc);

gbc.gridx=5;
gbc.gridy= 11;
jp1.add(jl5,gbc);

gbc.gridx=10;
gbc.gridy=11;        
jp1.add(jt5,gbc);

gbc.gridx=30;
gbc.gridy=11;
jp1.add(jl6,gbc);

gbc.gridx= 40;
gbc.gridy=11;
jp1.add(jc1,gbc);

gbc.gridx=5;
gbc.gridy= 14;
jp1.add(jl7,gbc);

gbc.gridx = 10;
gbc.gridy =14;
jp1.add(jc2,gbc);

gbc.gridx = 30;
gbc.gridy = 14;
jp1.add(jl8,gbc);

gbc.gridx = 40;
gbc.gridy = 14;
jp1.add(jc3,gbc);

JPanel jp2 =new JPanel();
Border etched1 =BorderFactory.createEtchedBorder();
Border titled1 = BorderFactory.createTitledBorder(etched1, "Academic Records");
jp2.setBorder(titled1);

GridBagLayout gb1=new GridBagLayout();
GridBagConstraints gbc1 = new GridBagConstraints();
jp2.setLayout(gb1);

gbc1.gridwidth=1;
gbc1.gridheight=1;
gbc1.weightx=1;
gbc1.weighty=1;

JLabel njl1 = new JLabel("10th");
JLabel njl2 = new JLabel("12th");
JTextField njt1 = new JTextField(15);
JTextField njt2 = new JTextField(15);

gbc1.gridx=1;
gbc1.gridy= 16;
jp2.add(njl1,gbc1);

gbc1.gridx=2;
gbc1.gridy= 16;
jp2.add(njt1,gbc1);

gbc1.gridx=1;
gbc1.gridy= 19;
jp2.add(njl2,gbc1);

gbc1.gridx=2;
gbc1.gridy= 19;
jp2.add(njt2,gbc1);

JPanel jp21 =new JPanel();
Border etched21 =BorderFactory.createEtchedBorder();
Border titled21= BorderFactory.createTitledBorder(etched21, "Graduation");
jp21.setBorder(titled21);
GridBagLayout gb21=new GridBagLayout();
GridBagConstraints gbc21 = new GridBagConstraints();

jp21.setLayout(gb21);
gbc21.gridwidth=1;
gbc21.gridheight=1;
gbc21.weightx=1;
gbc21.weighty=1;


ButtonGroup group21 = new ButtonGroup();
JRadioButton be =new JRadioButton("B.E.",true);
group21.add(be);
JRadioButton bsc= new JRadioButton("B.Sc ",false);
group21.add(bsc);
JRadioButton bcom=new JRadioButton("B.Com",false);
group21.add(bcom);
JRadioButton bca=new JRadioButton("B.C.A",false);
group21.add(bca);

gbc21.gridx=0;
gbc21.gridy=0 ;
jp21.add(be,gbc21);

gbc21.gridx=0;
gbc21.gridy=2;
jp21.add(bsc,gbc21);

gbc21.gridx=0;
gbc21.gridy=4;
jp21.add(bcom,gbc21);

gbc21.gridx=0;
gbc21.gridy=6;
jp21.add(bca,gbc21);

gbc1.gridx=1;
gbc1.gridy=26;
jp2.add(jp21,gbc1);

JPanel jp22 =new JPanel();
Border etched22 =BorderFactory.createEtchedBorder();
Border titled22= BorderFactory.createTitledBorder(etched22, "Post_Graduation");
jp22.setBorder(titled22);
GridBagLayout gb22=new GridBagLayout();
GridBagConstraints gbc22 = new GridBagConstraints();

jp22.setLayout(gb22);
gbc22.gridwidth=1;
gbc22.gridheight=3;
gbc22.weightx=1;
gbc22.weighty=1;


ButtonGroup group22 = new ButtonGroup();
JRadioButton mca =new JRadioButton("M.C.A",true);
group22.add(mca);
JRadioButton me= new JRadioButton("M.E",false);
group22.add(me);

gbc22.gridx=0;
gbc22.gridy=3 ;
jp22.add(mca,gbc22);

gbc22.gridx=0;
gbc22.gridy=6;
jp22.add(me,gbc22);

gbc1.gridx=2;
gbc1.gridy=26;
jp2.add(jp22,gbc1);

JPanel jp23 =new JPanel();
Border etched23 =BorderFactory.createEtchedBorder();
Border titled23= BorderFactory.createTitledBorder(etched23, "Graduation_details");
jp23.setBorder(titled23);
GridBagLayout gb23=new GridBagLayout();
GridBagConstraints gbc23 = new GridBagConstraints();

jp23.setLayout(gb23);
gbc23.gridwidth=1;
gbc23.gridheight=1;
gbc23.weightx=1;
gbc23.weighty=1;

JLabel njl3 = new JLabel(" I sem");
JLabel njl4 = new JLabel(" II sem");
JLabel njl5 = new JLabel(" III sem");
JLabel njl6 = new JLabel(" IV sem");
JLabel njl7 = new JLabel(" V sem");
JLabel njl8 = new JLabel(" VI sem");
JLabel njl9 = new JLabel(" VII sem");
JLabel njl10 = new JLabel(" VIII sem");
JLabel njl11 = new JLabel("Grand_Total");
JLabel njl12 = new JLabel("Out_Off");
JLabel njl13 = new JLabel("Aggregate");

JTextField njt3 = new JTextField(5);
JTextField njt4 = new JTextField(5);
JTextField njt5 = new JTextField(5);
JTextField njt6 = new JTextField(5);
JTextField njt7 = new JTextField(5);
JTextField njt8 = new JTextField(5);
JTextField njt9 = new JTextField(5);
JTextField njt10 = new JTextField(5);
 JTextField njt11 = new JTextField(5);
JTextField njt12 = new JTextField(5);
 JTextField njt13 = new JTextField(5);
gbc23.gridx=0;
gbc23.gridy=1;
jp23.add(njl3,gbc23);

gbc23.gridx=1;
gbc23.gridy=1;
jp23.add(njt3,gbc23);

gbc23.gridx=2;
gbc23.gridy=1;
jp23.add(njl4,gbc23);

gbc23.gridx=3;
gbc23.gridy=1;
jp23.add(njt4,gbc23);

gbc23.gridx=0;
gbc23.gridy=2;
jp23.add(njl5,gbc23);

gbc23.gridx=1;
gbc23.gridy=2;
jp23.add(njt5,gbc23);

gbc23.gridx=2;
gbc23.gridy=2;
jp23.add(njl6,gbc23);

gbc23.gridx=3;
gbc23.gridy=2;
jp23.add(njt6,gbc23);

gbc23.gridx=0;
gbc23.gridy=3;
jp23.add(njl7,gbc23);

gbc23.gridx=1;
gbc23.gridy=3;
jp23.add(njt7,gbc23);

gbc23.gridx=2;
gbc23.gridy=3;
jp23.add(njl8,gbc23);

gbc23.gridx=3;
gbc23.gridy=3;
jp23.add(njt8,gbc23);

gbc23.gridx=0;
gbc23.gridy=4;
jp23.add(njl9,gbc23);

gbc23.gridx=1;
gbc23.gridy=4;
jp23.add(njt9,gbc23);

gbc23.gridx=2;
gbc23.gridy=4;
jp23.add(njl10,gbc23);

gbc23.gridx=3;
gbc23.gridy=4;
jp23.add(njt10,gbc23);


gbc23.gridx=0;
gbc23.gridy=5;
jp23.add(njl11,gbc23);

gbc23.gridx=1;
gbc23.gridy=5;
jp23.add(njt11,gbc23);

gbc23.gridx=2;
gbc23.gridy=5;
jp23.add(njl12,gbc23);

gbc23.gridx=3;
gbc23.gridy=5;
jp23.add(njt12,gbc23);

gbc23.gridx=0;
gbc23.gridy=6;
jp23.add(njl13,gbc23);

gbc23.gridx=1;
gbc23.gridy=6;
jp23.add(njt13,gbc23);




gbc1.gridx=1;
gbc1.gridy=40;
jp2.add(jp23,gbc1);

JPanel jp24 =new JPanel();
Border etched24 =BorderFactory.createEtchedBorder();
Border titled24= BorderFactory.createTitledBorder(etched24, "Post_Graduation_details");
jp24.setBorder(titled24);
GridBagLayout gb24=new GridBagLayout();
GridBagConstraints gbc24 = new GridBagConstraints();

jp24.setLayout(gb24);
gbc24.gridwidth=1;
gbc24.gridheight=1;
gbc24.weightx=1;
gbc24.weighty=1;

JLabel njl43 = new JLabel(" I sem");
JLabel njl44 = new JLabel(" II sem");
JLabel njl45 = new JLabel(" III sem");
JLabel njl46 = new JLabel(" IV sem");
JLabel njl47 = new JLabel(" V sem");
JLabel njl48 = new JLabel(" VI sem");
JLabel njl49 = new JLabel("Grand_Total");
JLabel njl410 = new JLabel(" Out_Off");
JLabel njl411 = new JLabel("Aggregate");


JTextField njt43 = new JTextField(5);
JTextField njt44 = new JTextField(5);
JTextField njt45 = new JTextField(5);
JTextField njt46 = new JTextField(5);
JTextField njt47 = new JTextField(5);
JTextField njt48 = new JTextField(5);
JTextField njt49 = new JTextField(5);
JTextField njt410 = new JTextField(5);
JTextField njt411 = new JTextField(5);

gbc24.gridx=0;
gbc24.gridy=1;
jp24.add(njl43,gbc24);

gbc24.gridx=1;
gbc24.gridy=1;
jp24.add(njt43,gbc24);

gbc24.gridx=2;
gbc24.gridy=1;
jp24.add(njl44,gbc24);

gbc24.gridx=3;
gbc24.gridy=1;
jp24.add(njt44,gbc24);

gbc24.gridx=0;
gbc24.gridy=2;
jp24.add(njl45,gbc24);

gbc24.gridx=1;
gbc24.gridy=2;
jp24.add(njt45,gbc24);

gbc24.gridx=2;
gbc24.gridy=2;
jp24.add(njl46,gbc24);

gbc24.gridx=3;
gbc24.gridy=2;
jp24.add(njt46,gbc24);

gbc24.gridx=0;
gbc24.gridy=3;
jp24.add(njl47,gbc24);

gbc24.gridx=1;
gbc24.gridy=3;
jp24.add(njt47,gbc24);

gbc24.gridx=2;
gbc24.gridy=3;
jp24.add(njl48,gbc24);

gbc24.gridx=3;
gbc24.gridy=3;
jp24.add(njt48,gbc24);

gbc24.gridx=0;
gbc24.gridy=4;
jp24.add(njl49,gbc24);

gbc24.gridx=1;
gbc24.gridy=4;
jp24.add(njt49,gbc24);

gbc24.gridx=2;
gbc24.gridy=4;
jp24.add(njl410,gbc24);

gbc24.gridx=3;
gbc24.gridy=4;
jp24.add(njt410,gbc24);

gbc24.gridx=0;
gbc24.gridy=5;
jp24.add(njl411,gbc24);

gbc24.gridx=1;
gbc24.gridy=5;
jp24.add(njt411,gbc24);


gbc1.gridx=2;
gbc1.gridy=40;
jp2.add(jp24,gbc1);


JButton jb1 = new JButton("SUBMIT");
JButton jb2 = new JButton("CANCEL");

gbc1.gridx=1;
gbc1.gridy=60;
jp2.add(jb1,gbc1);

gbc1.gridx=2;
gbc1.gridy=60;
jp2.add(jb2,gbc1);

cp.add(jp1,"North");

cp.add(jp2,"South");
jframe.pack();
}

}



