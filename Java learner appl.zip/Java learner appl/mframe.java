import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*</applet code ="mframe.class" width=500 height=400>
*/
class mframe extends Frame
{
    mframe()
    {
        setVisible(true);
        addWindowListner(new mwa(this));
    }
   public static void main(String args[]) 
   {
    new mframe();
   }
 }
 class mywa extends WindowAdapter
 {
     mframe ref;
     mwa(mframe ref)
     {
        this.ref=ref;
      }
  public void WindowClosing(WindowEvent we)
  {
    ref.setVisible(false);
   }
 }
