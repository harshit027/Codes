


































class an
{ public static void main(String args[])
                  {
                  system.out.println("ankit");
                  }
}
