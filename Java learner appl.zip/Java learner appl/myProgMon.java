
import javax.swing.*;

class myProgMon extends JFrame
{
	public static void main(String args[])
	{
		new myProgMon();
	}
        ProgressMonitor pm;
       /* public static void main(String argfdp[])
        {
                new myProgMon();
        }*/
       myProgMon()
        {
                pm=new ProgressMonitor(this,"Please Wait...","Check",0,100);
                new myPMThread(this);
        }
}

 class myPMThread extends Thread
{
        myProgMon ref;
        int currval=0;
        myPMThread(myProgMon ref)
        {
                super("DATA PROCESSING");
                this.ref=ref;
                start();
        }
        public void run()
        {
                boolean flag=false;
                while(true)
                {
                        if(flag==false)
                        {
                                currval=currval+5;
                                if(currval>=100)
                                      flag=true;
                        }
                        else
                        {
                                currval=currval-5;
                                if(currval<=0)
                                        flag=false;
                        }
                        ref.pm.setProgress(currval);
                        try
                        {
                                sleep(120);
                        }
                        catch(Exception e){}
                }
        }
}
