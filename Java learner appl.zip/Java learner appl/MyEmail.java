import java.sql.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

class MyEmail extends JFrame implements ActionListener
{
	JLabel lbl[];
	JTextField emailAddress;
	JPasswordField password;
	JButton done;
	MyEmail()
	{
		lbl = new JLabel[2];
		lbl[0]=new JLabel("Email Address");
		lbl[1] = new JLabel("Password");
		emailAddress = new JTextField(20);
		password = new JPasswordField(20);
		done = new JButton("Ok");
		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		JPanel northPanel = new JPanel ();
		northPanel.add(lbl[0]);
		northPanel.add(emailAddress);
		northPanel.add(lbl[1]);
		northPanel.add(password);
		cp.add(northPanel,"North");
		JPanel southPanel = new JPanel();
		southPanel.add(done);
		cp.add(southPanel,"South");
		done.addActionListener(this);
		setSize(200,100);
		show();
	}
	public static void main(String args[])
	{
		new MyEmail();
	}
	public void actionPerformed(ActionEvent ae)
	{
		String ea = emailAddress.getText();
		String pass = new String(password.getPassword());
		try
		{
			Class.forName ( "sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:myjavadsn","","");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("select * from email where emailaddress ='"+ea+"' and password='"+pass+"'");
			JOptionPane.showMessageDialog(this,ea+", "+ pass);
			if(rs.next())
			{
				JOptionPane.showMessageDialog(this,"Congratulations, Authorised User");
				new EmailData(ea,pass);
			}
			else
			{
				JOptionPane.showMessageDialog(this,"Unauthorized User !!! Retry");
				emailAddress.setText("");
				password.setText("");
			}
		}
		catch(Exception e)
		{
			System.out.println("Error : "+e);
		}
	}
}

class EmailData extends JFrame implements ActionListener
{
	String ea="",pass="";
	JLabel lbl[]=new JLabel[3];
	JTextField subject= new JTextField(30);
	JTextArea msg = new JTextArea("",10,40);
	JTextField name = new JTextField(30);
	JButton send = new JButton("Send");
	EmailData(String ea, String pass)
	{
		this.ea = ea;
		this.pass = pass;
		lbl[0]= new JLabel("Name ");
		lbl[1]= new JLabel("Subject");
		lbl[2]= new JLabel("Message");

		Container cp = getContentPane();
		cp.setLayout(new BorderLayout());
		JPanel panel1  = new JPanel();
		panel1.setLayout(new GridLayout(3,2));
		panel1.add(lbl[0]);
		panel1.add(name);
		panel1.add(lbl[1]);
		panel1.add(subject);
		panel1.add(lbl[2]);
		panel1.add(msg);
		cp.add(panel1,"North");
		JPanel panel2 = new JPanel();
		panel2.add(send);
		cp.add(send,"South");
		send.addActionListener(this);
		setSize(400,300);
		show();
	}
	public void actionPerformed(ActionEvent ae)
	{
		try
		{
			Class.forName ( "sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con = DriverManager.getConnection("jdbc:odbc:myjavadsn","","");
			Statement st = con.createStatement();
			int val = st.executeUpdate("update email set name='"+name.getText()+"',subject='"+subject.getText()+"',message='"+msg.getText()+"' where emailAddress='"+ea+"'");
			if(val >0)
			{
				JOptionPane.showMessageDialog(this,"Values Stored");
			}
			else
			{
				JOptionPane.showMessageDialog(this,"Value Error");
			}
		}
		catch(Exception e)
		{
			System.out.println("Error : "+e);
		}

	}
}