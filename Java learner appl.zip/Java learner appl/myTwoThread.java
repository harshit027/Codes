import java.io.*;
class mytt extends Thread
{
	mytt(String str)
	{
		super(str);
		//start();
	}
	public void run()
	{
		String str=this.getName();
		if(str.equals("one"))
		{
			for(int i=2;i<=10;i++)
			{
				System.out.println("Even Number : "+i);
				i++;
				try
				{
					sleep(500);
				}
				catch(Exception e)
				{}
			}
		}
		else
		{
			for(int i=1;i<=10;i++)
			{
				System.out.println("Odd Number : "+i);
				i++;
				try
				{
					sleep(500);
				}
				catch(Exception e)
				{}
			}
		}
	}
}

class myTwoThread
{
	public static void main(String args[])
	{
		mytt t1=new mytt("one");
		mytt t2=new mytt("two");
		int ch=0;
		BufferedReader br=new BufferedReader (new InputStreamReader(System.in));
		String str;
		while(ch!=3)
		{
			System.out.println("\n1. First Thread");
			System.out.println("2. Second Thread");
			System.out.println("3. Second Thread");
			System.out.println("\nEnter Choice : ");
			try
			{
				str=br.readLine();
				ch=Integer.parseInt(str);
			}
			catch(Exception e){}
			switch(ch)
			{
				case 1:
					t1.start();
					while(t1.isAlive())
					{
						try
						{
							Thread.sleep(500);
						}
						catch(Exception e){}
					}
					break;
				case 2:
					t2.start();
					while(t2.isAlive())
					{
						try
						{
							Thread.sleep(500);
						}
						catch(Exception e){}
					}
					break;
				case 3 :
					System.out.println("Bye-Bye");
					break;
				default :
					System.out.println("\nInvalid Choice");
			}
		}
	}
}