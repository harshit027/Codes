class area
{
	int x,y,z;
	void get_data()
	{
		x=5;y=6;
	}
	void show_data()
	{
		System.out.println("Area of Rectangle : "+x*y);
	}
}

class circle extends area
{
	void get_data()
	{
		y=6;
	}
	void show_data()
	{
		System.out.println("Area of Circle : "+3.14*y*y);
	}
}
class triangle extends area
{
	void show_data()
	{
		System.out.println("Area of Triangle : "+0.5*x*y);
	}
}
class dmd
{
	public static void main(String args[])
	{
		area x=new area();
		circle y=new circle();
		triangle z=new triangle();
		myf(x);
		myf(y);
		myf(z);
	}
	static void myf(area ref)
	{
		ref.get_data();
		ref.show_data();
	}	
}