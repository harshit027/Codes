import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.*;

class Student_output_database extends JFrame implements ActionListener
 {
          JButton jb1,jb2,jb3,jb4;
          JTextField   jt1,jt2,jt3,jt4;
          JTable table,table1;
          JScrollPane jsp,jsp1;
           Container cp;
          JPanel jp1,jp3;
          int v,h,v1,h1;
          ResultSet rs,rs1;
          Statement st,st1;
          Connection con,con1;
          String  qry,qry1,qry11;
          int n=10;
          public static void main(String args[])
          {
                    new Student_output_database();
          }
          Student_output_database()
          {
             super("Record Of Student");
             getContentPane().setLayout(new BorderLayout());
             setSize(800,800);
 
             WindowListener l = new WindowAdapter()
              {
               public void windowClosing(WindowEvent we)
                  {
                  System.exit(0);
                 }
              };
          addWindowListener(l);
          jp1 = new JPanel();
          cp = getContentPane();
          GridBagLayout gb = new GridBagLayout();
          GridBagConstraints gbc =new GridBagConstraints();

          jp1.setLayout(gb);
          gbc.weightx=1;
          gbc.weighty=1;
          gbc.gridwidth=1;
          gbc.gridheight=1;

            try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
             st   = con.createStatement();
            String qry21="select  * from student_data ";
             rs1 = st.executeQuery(qry21);
            int i1=0;
            while(rs1.next())
            {  int j1=0;
              while(j1<26)
               {
                 j1++;
               }
             i1++;n++;
            }
          }
           
          catch(Exception e)
         {
          System.out.println("ERRRRRRRR"+e);
         }



          final String[] colHeads ={"Roll_no","Name", "Category" ,"D.O.B","Father'sName","Course","Branch","Semester","Phone_no","10th", "12th" ,"Graduation", " Sem I/Year I", " Sem II/Year II"," Sem III/YearIII","Sem IV","Sem V","Sem VI","Sem VII","Sem VIII","Aggregate","PostGradution","Sem I","Sem II","Sem III","Sem IV","Sem V","Sem VI","P_Aggregate"};
          String[][] data=new String[n][29];
          int i=0,j=0;

          v= ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
          h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;

          try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
            Statement st   = con.createStatement();
            String qry11="select student_data.roll_no,name,category,dob,fathername";
            qry11+=",course,branch,semester,phone_no,tenth,twelvth,graduation,sem1,sem2";
            qry11+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry11+=",psem3,psem4,psem5,psem6,paggregate ";
            qry11+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
	JOptionPane.showMessageDialog(this,qry11);
            ResultSet rs = st.executeQuery(qry11);
            //ResultSet rs = st.executeQuery("select student_data.roll_no,name,category,dob,fathername,course,branch,semester,phone_no,tenth,twelvth,graduation,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2,psem3,psem4,psem5,psem6,paggregate  from student_data,s_marks where student_data.roll_no=s_marks.roll_no");
            System.out.println("Abhi Data Nikal liya");
            while(rs.next())
            {  j=0;
              while(j<29)
               {
                 System.out.println("data array main bheja ja raha hai");
                 String str=rs.getString(j+1);
	str=str+"                                                ".substring(0,"                                                ".length()-str.length());
	data[i][j]=str;
                 System.out.println(data[i][j]);
                 j++;
               }
             i++;
            }
            System.out.println("Abhi Data dikha kya");
            }
           catch(Exception e)
            {
                    System.out.println("Error : "+e);
            }
  
            //TableColumn getColumn(26);  
          table = new JTable (data,colHeads);
	table.setSize(500,200);
          jsp= new JScrollPane(table,v,h);
          //jp1.add(table);
          cp.add(jsp,"Center");

           JPanel  jp2 = new JPanel();
          GridBagLayout gb1 = new GridBagLayout();
          GridBagConstraints gbc1 =new GridBagConstraints();

          jp2.setLayout(gb1);
          gbc1.weightx=1;
          gbc1.weighty=1;
          gbc1.gridheight=1;
          gbc1.gridwidth=1;

         JLabel jl1=new JLabel("Percent");
         gbc1.gridx=0;
         gbc1.gridy=1;

        jp2.add(jl1,gbc1);
        gbc1.gridx  =  1;
        gbc1.gridy   = 1;
        jt1 =  new JTextField(25);
        jp2.add(jt1,gbc1);
        JLabel jl2=new JLabel("Age");
        gbc1.gridx=0;
        gbc1.gridy=2;

        jp2.add(jl2,gbc1);
        gbc1.gridx  =  1;
        gbc1.gridy   = 2;
       jt2 =  new JTextField(25);
       jp2.add(jt2,gbc1);

         JLabel jl3=new JLabel("Branch");
         gbc1.gridx=0;
         gbc1.gridy=3;

        jp2.add(jl3,gbc1);
        gbc1.gridx  =  1;
        gbc1.gridy   = 3;
        jt3 =  new JTextField(25);
        jp2.add(jt3,gbc1);
        JLabel jl4=new JLabel("Semester");
        gbc1.gridx=0;
        gbc1.gridy=4;

        jp2.add(jl4,gbc1);
        gbc1.gridx  =  1;
        gbc1.gridy   = 4;
       jt4 =  new JTextField(25);
       jp2.add(jt4,gbc1);


       jb1=new JButton("Exit");
       gbc1.gridx=0;
       gbc1.gridy=5;
	jb1.addActionListener(this);
       jp2.add(jb1,gbc1);

       gbc1.gridx  =  1;
       gbc1.gridy   = 5;
       jb2 =  new JButton("OK");

	jb2.addActionListener(this);
      jp2.add(jb2,gbc1);
      cp.add(jp2,"South");

       setVisible(true);


}


      
            
  public void  actionPerformed(ActionEvent ae)
    {
        int i1=0;
          final String[] colHeads ={"Roll_no","Name", "Category" ,"D.O.B","Father'sName","Course","Branch","Semester","Phone_no","10th", "12th" ,"Graduation", " Sem I/Year I", " Sem II/Year II"," Sem III/YearIII","Sem IV","Sem V","Sem VI","Sem VII","Sem VIII","Aggregate","PostGradution","Sem I","Sem II","Sem III","Sem IV","Sem V","Sem VI","P_Aggregate"};
       Object source=ae.getSource();
       if (source == jb2)
       try
       {
        
            String[][] data=new String[10][29];
         if (!jt1.getText().equals("") &&jt2.getText().equals("")&&jt3.getText().equals("")&&jt4.getText().equals(""))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry="select student_data.roll_no,name,category,dob,fathername";
            qry+=",course,branch,semester,phone_no,tenth,twelvth,graduation,sem1,sem2";
            qry+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry+=",psem3,psem4,psem5,psem6,paggregate ";
            qry+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry+="and Aggregate >="+ jt1.getText();
            rs = st.executeQuery(qry);

         }
         if (!jt3.getText().equals("") &&jt1.getText().equals("")&&jt2.getText().equals("")&&jt4.getText().equals(""))
         {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry1="select student_data.roll_no,name,category,dob,fathername";
            qry1+=",course,branch,semester,phone_no,tenth,twelvth,graduation,sem1,sem2";
            qry1+=",sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2";
            qry1+=",psem3,psem4,psem5,psem6,paggregate ";
            qry1+=" from student_data,s_marks where student_data.roll_no = s_marks.roll_no ";
            qry1+="and branch ='"+ jt3.getText()+"'";
            rs = st.executeQuery(qry1);

          }


            System.out.println(qry);
            
            //rs = st.executeQuery(qry);
            while(rs.next())
           {
                    int  j1=0;
	JOptionPane.showMessageDialog(this,"abhi loop chalega");
                    while(j1<29)
                    {

//                 String str1=rs.getString(j1+1);
//          str1=str1+"                                                ".substring(0,"                                                ".length()-str1.length());
//          data[i1][j1]=str1;

                              data[i1][j1]=rs.getString(j1+1);
                              j1++;
                    }
                    i1++;
            }
	cp.remove(jsp);
	cp.repaint();
          	table = new JTable (data,colHeads);
	table.setSize(500,200);
          	jsp= new JScrollPane(table,v,h);
	cp.add(jsp,"Center");
 /*           jp1.remove(jsp);
            table = new JTable (data,colHeads);                                                                             
            //table.setSize(500,200);
            jsp= new JScrollPane(table,v,h);
            jp1.add(jsp);
            cp.add(jp1,"Center");            */
       }
      catch(Exception e)
       {}
   
  }
  
}

