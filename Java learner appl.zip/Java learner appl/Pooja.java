import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/* <applet code="pooja" width=300 height=400>
</applet>*/

public class Pooja extends Applet implements MouseListener
{
 Myf f[]=new Myf[10];
 int i=0;
 String msg="Click Here";
 public void init()
 {
  addMouseListener(this);
 }
 public void paint(Graphics g)
 {
  g.drawString(msg,20,30);
 }
 public void mouseClicked(MouseEvent me)
 {
  f[i]=new Myf();
  f[i].setVisible(true);
  i++;
 }
 public void mouseExited(MouseEvent me)
 {
 }
 public void mouseEntered(MouseEvent me)
 {
 }
 public void mousePressed(MouseEvent me)
 {
 }
 public void mouseReleased(MouseEvent me)
 {
  try
   {
    System.exit(0);
   }
  catch(Exception e)
  {
  }
 }
} 
class Myf extends Frame implements WindowListener
{
 Myf()
 {
  addWindowListener(this);
  setBounds(200,200,200,200);
  setBackground(Color.yellow);
 }
 public void windowOpened(WindowEvent we)
 {
 }
 public void windowClosing(WindowEvent we)
 {
  setVisible(false);
 }
 public void windowDeiconified(WindowEvent we)
 {
 }
 public void windowIconified(WindowEvent we)
 {
 }
 public void windowDeactivated(WindowEvent we)
 {
 }
 public void windowActivated(WindowEvent we)
 {
 }
 public void windowClosed(WindowEvent we)
 {
 }
}
