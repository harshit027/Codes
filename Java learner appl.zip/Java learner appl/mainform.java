import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import javax.swing.tree.*;
import java.util.*;
import javax.swing.event.*;
 


class mainform extends JFrame
{
	JTree tree;
	JTextArea jt1;
	DefaultMutableTreeNode a1,a2,a3,b1,b2,c1,c2,f1,f2,f3,f4,f5;
	public static void main(String args[])
	{
		new mainform();
	}
	mainform()
	{
		super("Mainform");
		setSize(400,400);
		setVisible(true);
		Container cp = getContentPane();

		WindowListener l = new WindowAdapter()
  		{
			public void windowClosing(WindowEvent we)
			{
    				System.exit(0);
   			}
  		};
		addWindowListener(l);

		// create tree node
		DefaultMutableTreeNode top = new DefaultMutableTreeNode("Training & Placement");
		// creata a subtree1
		DefaultMutableTreeNode a = new DefaultMutableTreeNode("Campus Recruitment");
		top.add(a);
		 a1 = new DefaultMutableTreeNode("Selected Student Databases ");
		a.add(a1);
		 a2 = new DefaultMutableTreeNode("Information about Companies");
		a.add(a2);
		a3 = new DefaultMutableTreeNode("Criteria Satisfaction");
		a.add(a3);
	
		// creata a subtree2
		DefaultMutableTreeNode b = new DefaultMutableTreeNode("Training");
		top.add(b);
		b1 = new DefaultMutableTreeNode("Company Information ");
		b.add(b1);
		b2 = new DefaultMutableTreeNode("Forms Format");
		b.add(b2);

		DefaultMutableTreeNode d = new DefaultMutableTreeNode("Students Records");
		top.add(d);
		DefaultMutableTreeNode d1 = new DefaultMutableTreeNode("Students Records");
		d.add(d1);

		DefaultMutableTreeNode c = new DefaultMutableTreeNode("Application Forms ");
		top.add(c);
		// creata a subtree2
		c1 = new DefaultMutableTreeNode("Vocational Training");
		c.add(c1);
		c2 = new DefaultMutableTreeNode("Apprenticeship Training");
		c.add(c2);
                                //create subtree 5

		DefaultMutableTreeNode f = new DefaultMutableTreeNode("Records Entry");
		top.add(f);
		DefaultMutableTreeNode f1 = new DefaultMutableTreeNode(" Student Record  Entry");
		f.add(f1);
                                f2 = new DefaultMutableTreeNode("Selected Student Record  Entry");
		f.add(f2);
		f3 = new DefaultMutableTreeNode("Company Record Entry");
		f.add(f3);
                                f4 = new DefaultMutableTreeNode("Criteria Entry");
		f.add(f4);	
                                f5 = new DefaultMutableTreeNode("Training Record Entry");
		f.add(f5);



		//create Tree
		tree = new JTree(top);

		tree.setShowsRootHandles(true);
		int v= ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
		int h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;
		JScrollPane jsp = new JScrollPane(tree,v,h);

		JPanel jp1= new JPanel();
		jp1.add(jsp);
		//jp1.add(jt1);

		cp.add(jp1,"West");

		JPanel jp2= new JPanel();
		jt1 = new JTextArea(30,30);
		jp2.add(jt1);
		cp.add(jp2,"East" );
		pack();
		//handle mouse click
		tree.addMouseListener(new MouseAdapter()
		{
				public void mouseClicked(MouseEvent me)
				{
					doMouseClicked(me);
				}
		});
	}
	
	void doMouseClicked(MouseEvent me)
	{
		int ctr=me.getClickCount();
		if(ctr==1)
		{
			try
          			{
				TreePath tp=tree.getSelectionPath();
                    			if(tp!=null)
	                    		{
                	              			DefaultMutableTreeNode tmp=(DefaultMutableTreeNode)tp.getLastPathComponent();
					if (tmp==a1)
					{
						jt1.setText("rajneesh");
					}	
					if (tmp==a2)
					{
						jt1.setText("pace");
					}
					if (tmp==a3)
					{
						jt1.setText("jabalpur");
					}
	                    		                if (tmp==b1)
					{
						jt1.setText("amrita&suparna");
					}
                                                                               if (tmp==b2)
					{
						jt1.setText("amrita & smita");
					}
                                                                               if (tmp==c1)
					{
						jt1.setText("suparna & nidhi");
                                                                                 }

                                                                                if (tmp==c2)
					{
						jt1.setText("suparna & nidhi");
					}
                                                                                if (tmp==f1)
					{
						jt1.setText("nidhi");
					}
                                                                                if (tmp==f2)
					{
						jt1.setText("suparna");
					} 
                                                                                if (tmp==f3)
					{
						jt1.setText("rajneesh");
					}
                                                                                 if (tmp==f4)
					{
						jt1.setText("rajneesh");
					}
                                                                                if (tmp==f5)
					{
						jt1.setText("rajneesh");
					}
                                                                                						jt1.setText("rajneesh");
					  





                                                                 }
                	    		else
                    			{
                              				jt1.setText("");
	                    		}
           			}
           			catch(Exception e)
	           		{
                	    		System.out.println("Error Tree Se : "+e);
           			}
		}
		else
		{
			try
          			{
				TreePath tp=tree.getSelectionPath();
                    			if(tp!=null)
	                    		{
                	              			DefaultMutableTreeNode tmp1=(DefaultMutableTreeNode)tp.getLastPathComponent();
					if (tmp1==a1)
					{
						new selected_candidate_output();
					}	
					if (tmp1==a2)
					{
						new company_details();
					}
					if (tmp1==a3)
					{
						jt1.setText("jabalpur");
					}
	                    		}
                	    		else
                    			{
                              				jt1.setText("");
	                    		}
           			}
           			catch(Exception e)
	           		{
                	    		System.out.println("Error Tree Se : "+e);
           			}
		}
    	} 
}