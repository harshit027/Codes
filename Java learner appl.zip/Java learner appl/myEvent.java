import java.awt.*;
import java.awt.event.*;
/*
	<applet code="myEvent.class" width=300 height=300>
	</applet>
*/
public class myEvent extends java.applet.Applet implements MouseListener
{
	int x,y;
	String str="PACE";
	public void init()
	{
		addMouseListener(this);
	}
	public void paint(Graphics g)
	{
		g.setFont(new Font("Arial",Font.BOLD,20));
		g.drawString(str,x,y);
	}
	public void mouseClicked(MouseEvent me)
	{
		x=me.getX();
		y=me.getY();
      // str=x+", "+y;
        str=str.charAt(str.length()-1)+str.substring(0,str.length()-1);
        repaint();
	}
	public void mousePressed(MouseEvent me)
	{}
	public void mouseReleased(MouseEvent me)
	{}
	public void mouseEntered(MouseEvent me)
	{}
	public void mouseExited(MouseEvent me)
	{}
}
