import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;

class myPopup extends JFrame 
{
	JPopupMenu myPop;
	JMenuBar jmb;
	JMenu m1,m2;
	JMenuItem mi11,mi12,mi13,mi21,mi22,mi23,pm11,pm12,pm13;
	JButton btn=new JButton("Check Button");
	public static void main(String sdfs[])
	{
		new myPopup();
	}
	myPopup()
	{
		jmb=new JMenuBar();
		setJMenuBar(jmb);
                		ImageIcon img1=new ImageIcon("hlpcd.gif");

		m1=new JMenu("Books");
		mi11=new JMenuItem("C Plus Plus",'C');
		mi12=new JMenuItem("Visual Basic",'V');
		mi13=new JMenuItem("Oracle",'O');

		m1.add(mi11);
		m1.add(mi12);
		m1.add(mi13);

		m2=new JMenu("Countries");
                		mi21=new JMenuItem("India",img1);
		mi22=new JMenuItem("America");
		mi23=new JMenuItem("Autralia");
		
		m2.add(mi21);
		m2.add(mi22);
		m2.add(mi23);
		
		jmb.add(m1);
		jmb.add(m2);
		
		myPop=new JPopupMenu();
		pm11=new JMenuItem("C Plus Plus",'C');
		pm12=new JMenuItem("Visual Basic",'V');
		pm13=new JMenuItem("Oracle",'O');

		myPop.add(pm11);
		myPop.add(pm12);
		myPop.add(pm13);
		Dimension d=getSize();
		JPanel t=new JPanel();
		//Border mt=BorderFactory.createMatteBorder(0,0,200,200,img1);
		Border et=BorderFactory.createEtchedBorder(Color.green,SystemColor.activeCaption);
		//Border et=BorderFactory.createEtchedBorder(Color.green,Color.yellow);
		t.setBorder(BorderFactory.createTitledBorder(et));
		//t.setBorder(BorderFactory.createMatteBorder(0,0,d.height,d.width,img1));
		getContentPane().add(t,"North");
		setSize(400,400);
		setVisible(true);
		addMouseListener(new MouseAdapter()
				{
					public void mouseReleased(MouseEvent me)
					{
						if (me.isPopupTrigger())
						{
							myPop.show(me.getComponent(),me.getX(),me.getY());
							//getContentPane().add(btn);
						}
					}	
				}
			             );
	}
}
                        
