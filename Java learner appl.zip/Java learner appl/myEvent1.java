import java.awt.*;
import java.awt.event.*;
/*
	<applet code="myEvent1.class" width=300 height=300>
	</applet>
*/
public class myEvent1 extends java.applet.Applet
{
	int x,y;
	String str="PACE";
	public void init()
	{
		addMouseMotionListener(new myMMA(this));
	}
	public void paint(Graphics g)
	{
		g.setFont(new Font("Arial",Font.BOLD|Font.ITALIC,20));
		g.drawString(str,x,y);
	}
}

class myMMA extends MouseMotionAdapter
{
	myEvent1 ref;
	myMMA(myEvent1 ref)
	{
		this.ref=ref;
	}
	public void mouseDragged(MouseEvent me)
	{
		ref.x=me.getX();
		ref.y=me.getY();
		ref.str=ref.x+", "+ref.y;
		ref.repaint();
	}	
}