import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.event.*;

class myjf extends JFrame implements ListSelectionListener
{
	JList lst;
	JLabel lbl;
	myjf()
	{
		super("PACE");
		setSize(400,400);
		setLocation(30,30);
		lbl=new JLabel("PACE");
		String []w={"RED","GREEN","BLUE","YELLOW","CYAN","MAGENTA","BLACK","WHITE"};
		lst=new JList(w);
		lst.setVisibleRowCount(6);
		JScrollPane jp=new JScrollPane(lst);
		getContentPane().setLayout(new BorderLayout());
		getContentPane().add(jp,BorderLayout.NORTH);		
		getContentPane().add(lbl,BorderLayout.SOUTH);
		lst.addListSelectionListener(this);
		setVisible(true);
	}
	public static void main(String args[])
	{
		new myjf();
	}
	public void valueChanged(ListSelectionEvent lse)
	{
		String str=(String)lst.getSelectedValue();
		lbl.setText(str);
		getContentPane().repaint();
	}
}