import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
/*<applet code = "mysdialog .class" width=450 height =600>
</applet>
*/
class mysdialog extends JApplet
{
    JButton btn;
    public void init()
    {
    btn=new JButton("Message Dialog");
    JOptionPane jp= new JOptionPane();
    jp.addActionListner(this);
   // JOptionPane.ERROR_MESSAGE;
    }
public void actionPerformed(ActionEvent ae)
{
    
      //JOptionPane.showMessageDialog();
      JOptionPane.ERROR_MESSAGE;
      //jp.setVisible(true);
 }
}

