import java.awt.*;
import javax.swing.*;


 class notes extends JFrame
{

JCheckBox jbx[];
JButton jbtn;
Color myc=Color.cyan;
Color myc1=Color.orange;
JPanel p1,p2;

notes()
{int l,ind;
char ch='y';
	setTitle("Notes To Download");
	setSize(700,600);
	p1=new JPanel();
	jbx=new JCheckBox[5];
	Box b=Box.createVerticalBox();

	while(ch=='y'||ch=='Y')
	{
	jbx[0]=new JCheckBox("C/C++",false);
	p1.add(jbx[0]);
	b.add(jbx[0]);
	b.add(Box.createGlue());
	ch='n';
	}
	jbx[1]=new JCheckBox("Visual C++",false);
	p1.add(jbx[1]);
	b.add(jbx[1]);
	b.add(Box.createVerticalStrut(25));
	jbx[2]=new JCheckBox("Visual Basic",false);
	p1.add(jbx[2]);
	b.add(jbx[2]);
	b.add(Box.createVerticalStrut(25));
	jbx[3]=new JCheckBox("J2SE",false);
	p1.add(jbx[3]);
	b.add(jbx[3]);
	b.add(Box.createVerticalStrut(25));
	/*jbx[4]=new JCheckBox("subjecthtfldhjkghdjkhjk1",false);
	p1.add(jbx[4]);
	b.add(jbx[4]);
	b.add(Box.createVerticalStrut(25));
*/
	p1.add(b);

		//--------------------//


	p2=new JPanel();
	Container c=getContentPane();
	p1.setBackground(myc1);
	p2.setBackground(myc);
	jbtn=new JButton("DOWNLOAD");
	getContentPane().add(p2,"East");
	p2.add(jbtn);
	getContentPane().add(p1,"West");
	show();
}
public static void main(String args[])
{
	JFrame jf=new notes();
	jf.show();
}
}




