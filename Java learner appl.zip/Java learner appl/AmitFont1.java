import java.applet.*;                    
import java.awt.*;
/*
        <applet code="AmitFont1.class" width=300 height=400>
	</applet>
*/

public class AmitFont1 extends Applet
{	String s="AMIT";
Font f=new Font("Arial",Font.BOLD,20);

	public void paint(Graphics g)
	{
	//g.setFont(f);
	g.drawString("AMIT",49,44);
	g.drawString(s,100,44);
	}
}
