 import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class DialogFrame extends JFrame implements ActionListener
{
          public DialogFrame()
          {
                    setTitle("dialogtest");
                    setSize(300,300);
                    addWindowListener(new WindowAdapter()
                    {
                              public void windowClosing(WindowEvent e)
                              {
                              System.exit(0);
                              }
                     }
                 );
                     JMenuBar m =new JMenuBar();
                     setJMenuBar(m);
                     JMenu  fm=new JMenu("file");
                     m.add(fm);
                     aboutItem= new JMenuItem("about");
                     aboutItem.addActionListener(this);
                     fm.add(aboutItem);
                     exitItem=new JMenuItem("exit");
                     exitItem.addActionListener(this);
                     fm.add(exitItem);
           }


   public void actionPerformed(ActionEvent e)
   {
             Object source = e.getSource();
             if(source==aboutItem)
             {
                    JOptionPane.showMessageDialog(this,"Creating Dialog");
                    if(dialog==null)
                              dialog=new d1(this);
                    dialog.show();
                    JOptionPane.showMessageDialog(this,"Dialog Creted");
              }
              else if(source == exitItem)
               {
                    System.exit(0);
             }
   }
   private d1  dialog;
   private JMenuItem aboutItem;
   private JMenuItem  exitItem;
   }

 class d1 extends JDialog
 {
  public d1(JFrame parent)
   {
           super(parent,"hello",true);
          Box b= Box.createVerticalBox();
          b.add(Box.createGlue());
          b.add(new JLabel("neha"));
          b.add(new JLabel("koushi"));
          b.add(Box.createGlue());
          getContentPane().add(b, "Center");
          JPanel p2= new JPanel();
          JButton b1 = new JButton("ok");
          p2.add(b1);
          JTextField jtf= new JTextField(10);
          p2.add(jtf);
          getContentPane().add(p2, "North");
          b1.addActionListener(new ActionListener()
          {
                    public void actionPerformed(ActionEvent ae)
                    {
                              setVisible(false);
                    }
          }
      );
          setSize(200,100);
       }
  }
public class d2 implements ActionListener
{
 public static void main(String args[])
 {
          d2 x=new d2();
          x.myf();
 }
 void myf()
 {
          JButton btn=new JButton(" Show Application");
          JFrame fr=new JFrame("Hello World");
          btn.addActionListener(this);
          fr.getContentPane().setLayout(new BorderLayout());
          fr.getContentPane().add(btn,"Center");
          fr.show();
 }
 public void actionPerformed(ActionEvent ae)
 {
          JFrame f = new DialogFrame();
          f.show();
 }
}

