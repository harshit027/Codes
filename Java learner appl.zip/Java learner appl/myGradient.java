import java.applet.*;
import java.awt.*;
import java.awt.event.*;
/*
	<applet code="myGradient.class" width=300 height=300>
	</applet>
*/
public class myGradient extends Applet implements MouseListener
{
	String str="PACE BUREAU";
	boolean flag=false;
	public void init()
	{
		addMouseListener(this);
	}
	public void paint(Graphics g)
	{
		Dimension d=getSize();
		int x=0,y=0;
		for(int i=0;i<=255;i++)
		{
				x+=d.width/256;
				y+=d.height/256;
				if (flag==false)
				{
					g.setColor(new Color(i,i,0));
				}
				else
				{
					g.setColor(new Color(0,i,0));
				}
				g.fillRect(x,0,d.width,d.height);
		}
	}

	public void mouseClicked(MouseEvent me)
	{
		/*if (flag==false)
			flag=true;
		else
			flag=false;*/
		flag=!flag;
		repaint();
	}
	public void mousePressed(MouseEvent me)
	{
	}
	public void mouseReleased(MouseEvent me)
	{
	}
	public void mouseEntered(MouseEvent me)
	{
	}
	public void mouseExited(MouseEvent me)
	{
	}
}