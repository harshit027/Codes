class base
{
        private int x;
        protected int y;
        public int z;
        int w;
         base()
        {
            x=y=z=w=0;
         }
         base(int a,int b,int c,int d)
         {
            x=a;y=b;z=c;w=d;
         }
 }
class derived extends base
{
        int m;
        derived()
        {
            super();
           m=0;
        }
        derived(int p1,int p2,int p3,int p4,int p5)
        {
            super(p1,p2,p3,p4);
             m=p5;
         }
}
class inherit
{
    public static void main(String args[])
    {    // inherit
          base b=new base();
          base b1=new base(1,3,5,7);
          derived d=new derived();
          derived d1=new derived(22,33,44,55,66);
          System.out.println("value of base class");
          System.out.println("base=  "  +b.y+" " + b.z+" " + b.w);
          System.out.println("base=  "+b1.y + " " + b1.z+" " + b1.w);
          System.out.println("value of derived class");
          System.out.println("derived=  "+d1.y);
          System.out.println("derived=  "+ " "+d1.y+" "+d1.z+ " "+" " +d1.w);
    }
  }
