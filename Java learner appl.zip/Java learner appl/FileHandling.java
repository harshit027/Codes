import java.io.*;
class FileHandling
{
	public static void main(String args[])
	{
		File f=new File("e:\\old\\java_programs\\FileHandling.java");
		String str="";
		str+="Name : "+f.getName()+"\n";
		str+="Length : "+f.length()+"\n";
		str+="Exists : "+f.exists()+"\n";
		str+="is File : "+f.isFile()+"\n";
		str+="is Directory : "+f.isDirectory()+"\n";
		str+="Last Modified : "+f.lastModified()+"\n";
		str+="can Write : "+f.canWrite()+"\n";
		str+="can Read : "+f.canRead()+"\n";
		str+="get Path : "+f.getPath()+"\n";
		str+="Absolute Path : "+f.getAbsolutePath()+"\n";
		str+="get Parent : "+f.getParent()+"\n";
		f.setReadOnly();
		System.out.println(str);
	}
}