import java.awt.*;
import java.applet.*;

public class MyFirstApp extends Applet
{
	public void paint(Graphics g)
	{
		g.drawString("PACE BUREAU",50,50);
		showStatus("HELLO FROM PACE");
	}
}

/*
	<applet code="MyFirstApp.class" width=400 height=400>
	</applet>
*/