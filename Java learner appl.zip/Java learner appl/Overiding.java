import java.io.*;
abstract class CommonOverRiding
{
	double a,b,c;
	void get()
	{
		try
		{
			BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
			System.out.println("\nEnter Values : ");
			a = Double.valueOf(br.readLine()).doubleValue();
			b = Double.valueOf(br.readLine()).doubleValue();
		}
		catch(Exception e)
		{}
	}
	void show()
	{
		System.out.println("\nArea is : "+c);
	}
	abstract void Area();
	/*{
		System.out.println("Check");
	}*/
}
class Rectangle extends CommonOverRiding
{
	void Area()
	{
		c = a * b;
	}
}
class Circle extends CommonOverRiding
{
	void get()
	{
		try
		{
			BufferedReader br= new BufferedReader(new InputStreamReader(System.in));
			System.out.println("\nEnter Value : ");
			a = Double.valueOf(br.readLine()).doubleValue();
		}
		catch(Exception e)
		{}
	}
	void Area()
	{
		c = 3.14 * a * a;
	}
}
class Overiding
{
	public static void main(String args[])
	{
		myf(new Rectangle());
		myf(new Circle());
	}
	static void myf(CommonOverRiding ref)
	{
		ref.get();
		ref.Area();
		ref.show();
	}
}
