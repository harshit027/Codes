import java.awt.event.*;
import java.awt.*;
import java.applet.*;
public class applet21 extends java.applet.Applet implements MouseListener
{
 Color c=Color.yellow;
int i;
public void init()
{
 addMouseListener(this);
}
 public void paint(Graphics g)
{
setBackground(c);
}
public void mouseClicked(MouseEvent me)
{
switch(i)
{
 case 0:
c=Color.orange;
break;
case 1:
c=Color.yellow;
break;
case 2:
c=Color.blue;
break;
case 3:
c=Color.red;
break;
}
i++;
if(i>3)
repaint();
}
public void mousePressed(MouseEvent me)
{
}
public void mouseReleased(MouseEvent me)
{
}
public void mouseEntered(MouseEvent me)
{
}
public void mouseExited(MouseEvent me)
{
}

}
/*
<applet id='app1' code="applet21.class" width=400 height=300>

</applet> */
