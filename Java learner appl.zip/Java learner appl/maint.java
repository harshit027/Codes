class myt extends Thread
{
	myt(String tn)
	{
		super(tn);
		start();
		System.out.println("Child Thread :"+tn+" started");
	}
	public void run()
	{
		System.out.println("From Child Thread");
	}
}

class maint
{
	public static void main(String argsp[]) //throws Exception
	{
		try
		{
			System.out.println("Main Thread Started : "+Thread.currentThread());
			myt t=new myt("First");
			myt t1=new myt("Second");
			Thread.sleep(1000);
			System.out.println("I am main now ready to die");
		}
		catch(InterruptedException ie)
		{}
	}
}