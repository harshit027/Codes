import java.awt.*;
import java.awt.event.*;

public class MyRadioButton extends java.applet.Applet
	implements ItemListener
{
	Checkbox cb[],rb[];
	CheckboxGroup cbg;
	public void init()
	{
		cb=new Checkbox[3];
		String str[]={"Red","Green","Blue"};
		for(int i=0;i<=2;i++)
		{
			cb[i] = new Checkbox(str[i]);
			cb[i].addItemListener(this);
			add(cb[i]);
		}
		rb=new Checkbox[3];
		cbg=new CheckboxGroup();
		for(int i=0;i<=2;i++)
		{
			rb[i] = new Checkbox(str[i],cbg,false);
			rb[i].addItemListener(this);
			add(rb[i]);
		}
		rb[0].setState(true);
	}
	public void itemStateChanged(ItemEvent ie)
	{
		Checkbox ref = (Checkbox)ie.getSource();
		if(ref == cb[0])
		{
			if(ref.getState()==true)
			{
				setBackground(Color.red);
			}
		}
		if(ref == cb[1])
		{
			if(ref.getState()==true)
			{
				setBackground(Color.green);
			}
		}
		if(ref == cb[2])
		{
			if(ref.getState()==true)
			{
				setBackground(Color.blue);
			}
		}
		if(ref == rb[0])
		{
			if(ref.getState()==true)
			{
				setBackground(Color.red);
			}
		}
		if(ref == rb[1])
		{
			if(ref.getState()==true)
			{
				setBackground(Color.green);
			}
		}
		if(ref == rb[2])
		{.
			if(ref.getState()==true)
			{
				setBackground(Color.blue);
			}
		}
		repaint();
	}
}
