import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/*
<applet code=
class login  extends JApplet implements ActionListener
{
JPasswordField pa;
//JPasswardField pa;
JTextField t;
JButton b1,b2;
JLabel l1,l2;
public void init()
{
Container c=getContentPane();
l1=new JLabel("USER NAME:");
l2=new JLabel("PASSWARD:");
t=new JTextField("");
b1=new JButton("OK");
b2=new JButton("CANCLE");
pa=new JPasswordField("",2);
c.add(t);
c.add(l1);
c.add(l2);
c.add(b1);
c.add(b2);
c.add(pa);
b1.addActionListener(this);
b2.addActionListener(this);
}
public void actionPerformed(ActionEvent ae)
{
}
}
