import java.io.*;
import java.net.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Client extends JFrame
{
	JTextField enter;
	JTextArea display;
	ObjectOutputStream output;
	ObjectInputStream input;
	String message ="";

	public Client()
	{
		super("client");
		Container c = getContentPane();

		enter = new JTextField();
		enter.setEnabled(false);
		enter.addActionListener(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					sendData(e.getActionCommand());
				}
			}
			);
		c.add(enter,BorderLayout.NORTH);

		display=new JTextArea();
		c.add(new JScrollPane(display),BorderLayout.CENTER);
		setSize(300,150);
		show();
	}
	public void runClient()
	{
		Socket cl;

		try
		{

				display.setText("Attempting connection\n");
				cl = new Socket(InetAddress.getByName("127.0.0.1"),2000);
				display.append( " Connection to:"+ cl.getInetAddress().getHostName());

				output = new ObjectOutputStream(cl.getOutputStream());
				output.flush();
				input = new ObjectInputStream(cl.getInputStream());
				display.append("\nGot I/O stream\n");

				enter.setEnabled(true);

				do
				{
					try
					{
						message = (String) input.readObject();
						display.append("\n"+message);
						display.setCaretPosition(display.getText().length());
					}
					catch(ClassNotFoundException cnfex)
					{
						display.append("\nUnkown object type received");
					}
				}
				while(!message.equals("SERVER>>>TERMINATE"));

				display.append("CLOSING CONNECTION.\n");
				output.close();
				input.close();
				cl.close();


		}
		catch(EOFException eof)
		{
			System.out.println("server terminated connection");
		}
		catch(IOException io)
		{
			io.printStackTrace();
		}
	}
	private void sendData(String s)
	{
		try
		{
			output.writeObject("CLIENT>>>"+s);
			output.flush();
			display.append("\nCLIENT>>>"+ s);
		}
		catch(IOException cnfex)
		{
			display.append("\nError writin object");
		}
	}
	public static void main (String args[])
	{
		Client app = new Client();
		app.addWindowListener(
			new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					System.exit(0);
				}
			}
			);
		app.runClient();
	}
}
