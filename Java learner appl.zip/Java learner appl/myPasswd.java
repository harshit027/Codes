import java.awt.*;
import java.awt.event.*;

class myPasswd extends Frame
{
	Label pass,logname;
	TextField txtPass,txtLogname;
	public static void main(String argsp[])
	{
		myPasswd t=new myPasswd("Login Details");
	}
	myPasswd(String title)
	{
		super(title);
		setLayout(null);
		setBounds(30,30,200,130);
		pass=new Label("Password : ");
		logname=new Label("Login Name : ");

		txtPass=new TextField(8);
		txtLogname=new TextField(15);
		logname.setBounds(10,40,70,20);
		txtLogname.setBounds(90,40,170,20);
		add(logname);
		add(txtLogname);                        
		txtPass.setEchoChar('*');
		pass.setBounds(10,80,70,20);
		txtPass.setBounds(90,80,170,20);
		add(pass);
		add(txtPass);
		setResizable(false);
		setVisible(true);
	}
}