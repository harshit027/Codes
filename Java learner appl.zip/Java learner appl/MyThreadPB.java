class ThreadPB extends Thread
{
	int n;
	ThreadPB(int n)
	{
		this.n=n;
		start();
	}
	public void run()
	{
		System.out.println("");
		while(n>0)
		{
			System.out.print("�");
			n--;
			try
			{
				sleep(500);
			}
			catch(Exception e)
			{
				System.out.println("Error : "+e);
			}
		}
	}
}

class MyThreadPB
{
	public static void main(String args[])
	{
		new ThreadPB(10);
	}
}