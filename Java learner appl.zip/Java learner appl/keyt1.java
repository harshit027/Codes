import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code= "keyt1" width= 200 height=200>
</applet>
*/
public class keyt1 extends Applet implements KeyListener
{
        String msg[]=new String[50];
        int i=0,y=20;
        public void init()
        {
            addKeyListener(this);
           for(int j=0;j<=49;j++)
            {
                msg[j]="";
            }
            requestFocus();
        }
        public void keyPressed(KeyEvent ke)
        {
            int key=ke.getKeyCode();
            switch(key)
            {
                case  KeyEvent.VK_ENTER:
                        i++;
                        break;
           }
    }
    public void keyReleased(KeyEvent ke)
    {
    }
    public void keyTyped(KeyEvent ke)
    {
        if(ke.getKeyChar()!=KeyEvent.VK_ENTER)
        msg[i]=msg[i]+ke.getKeyChar();
        repaint();  
    }
    public void paint(Graphics g)
    {
        for(int j=0;j<=49;j++)
        {
            int t=y;
            g.drawString(msg[j],30,t);
            t+=20;
        }
    }
}
