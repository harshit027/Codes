package rational;

public class myrational
{
	int num,den;
	myrational()
	{
		num=0;den=1;
	}
	myrational(int num,int den)
	{
		this.num=num;
		this.den=den;
	}
	void get_data()
	{
		num=50;
		den=100;
	}
	void show_data()
	{
		system.out.println("\nOutput : "+num+"/"+den);
	}
	rational add(rational p)
	{
		rational t=new rational();
		t.num=num*p.den+den*p.num;
		t.den=den*p.den;
		return t;
	}
}