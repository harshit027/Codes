class common
{
	int n;
	synchronized void storeVal(int n)
	{
		this.n=n;
	}
	synchronized int pickVal()
	{
		return n;
	}
}
class febot extends Thread
{
	common p;
	febot(common p)
	{
		super("Febo Thread");
		start();
		this.p=p;
	}
	public void run()
	{
		int n=5,i,a,b,c;
		a=1;b=1;
		for(i=1;i<=n;i++)
		{
			c=a+b;
			a=b;
			b=c;
			System.out.print("Febo : "+c);
			p.storeVal(c);
			try
			{
				sleep(400);
			}
			catch(InterruptedException ie)
			{}
		}
	}
}

class Star_t extends Thread
{
	common p;
	Star_t(common p)
	{
		super("Star Thread");
		start();
		this.p=p;
	}
	public void run()
	{		
		int n,i,j;
		for(j=1;j<=5;j++)
		{
			n=p.pickVal();
            for(i=1;i<=n;i++)
			{
				System.out.print("*");
			}
			System.out.println("");
			try
			{
				sleep(400);
			}
			catch(InterruptedException ie)
			{}
		}
	}
}

class myTwot1
{
	public static void main(String args[])
	{
		common p=new common();
		febot t1=new febot(p);
		Star_t t2=new Star_t(p);
		try
		{
			t1.join();
			t2.join();
		}
		catch(Exception e){}
		System.out.print("\nEhhhh !!! Ab Sara Kaam Khatam");
	}
}
