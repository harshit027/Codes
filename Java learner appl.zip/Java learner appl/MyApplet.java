import java.applet.*;
import java.awt.*;
public class myApplet extends Applet
{
public void paint(Graphics g)
{
//set Foreground(Color.yellow);
g.drawString("neha",50,60);
}
}/*< applet code="myApplet.class" width=300 height=400>
</applet>*/
