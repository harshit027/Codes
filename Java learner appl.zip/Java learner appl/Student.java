import java.sql.*;
import java.awt.*;
import java.awt.event.*;

class Student extends Frame implements ActionListener
{
	TextField tf[]=new TextField[6];
	Label lbl[]=new Label[6];
	Button btn[]=new Button[4];
	Student()
	{
		super("MyStudent Database");
		setSize(400,400);
		String str[]={"RollNo","Name","C","CPP","JAVA","TOTAL"};
		String str1[]={"Add","Edit","Delete","Save"};
		setLayout(new GridLayout(8,2));
		for(int i=0;i<=5;i++)
		{
			lbl[i]=new Label(str[i]);
			add(lbl[i]);
			tf[i]=new TextField(20);
			add(tf[i]);
		}
		for(int i=0;i<=3;i++)
		{
			btn[i]=new Button(str1[i]);
			add(btn[i]);
			btn[i].addActionListener(this);
		}
		btn[3].setEnabled(false);
		show();
		addWindowListener(new WindowAdapter()
											{
												public void windowClosing(WindowEvent we)
												{
													setVisible(false);
													System.exit(0);
												}
											}
										 );
	}
	public void actionPerformed(ActionEvent ae)
	{
		Button tempBtn = (Button) ae.getSource();
		if(tempBtn == btn[0])
		{
			for(int i=0;i<=5;i++)
			{
				tf[i].setText("");
			}
			btn[0].setEnabled(false);
			btn[1].setEnabled(false);
			btn[2].setEnabled(false);
			btn[3].setEnabled(true);
		}
		if(tempBtn == btn[3])
		{
			try
			{
				Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
				Connection con = DriverManager.getConnection("jdbc:odbc:mydsn1","","");
				Statement st = con.createStatement();
				st.executeUpdate("insert into student values ("+tf[0].getText()+",'"+tf[1].getText()+"',"+tf[2].getText()+","+tf[3].getText()+","+tf[4].getText()+")");
				con.close();
				btn[0].setEnabled(true);
				btn[1].setEnabled(true);
				btn[2].setEnabled(true);
				btn[3].setEnabled(false);
				for(int i=0;i<=5;i++)
				{
					tf[i].setText("");
				}
			}
			catch(Exception e)
			{
				System.out.println("Error : "+e);
			}
			finally
			{
			}
		}
	}
	public static void main(String args[])
	{
		new Student();
	}
}