package mypkg;
interface myi
{
	void getString(String str);
	void showString();
}
public class ShowString implements myi
{
	String str="";
	public void getString(String str)
	{
		this.str = str;
	}
	public void showString()
	{
		System.out.println("String is : "+str);
	}
}