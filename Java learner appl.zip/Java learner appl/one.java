class one
{
        public static void main(String args[])
        {
                System.out.println("PACE BUREAU");
        }
}
