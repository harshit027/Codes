import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/* <applet code ="check " width=250 height=250>
</applet>
*/
public class check extends Applet implements ItemListener
{
String m ="";
Checkbox w98,nt,sol,mac;
public void init()
{
w98=new Checkbox("windows 98",null,true);
nt=new Checkbox("windows NT");
sol=new Checkbox("solaris");
mac=new Checkbox("MACOS");

add(w98);
add(nt);
add(sol);
add(mac);
w98.addItemListener(this);
nt.addItemListener(this);
sol.addItemListener(this);
mac.addItemListener(this);

}
public void itemStateChanged(ItemEvent ie)
{
repaint();
}
public void paint(Graphics g)
{
m="current state:";
g.drawString(m,6,80);
m="windows 98:"+w98.getState();
g.drawString(m,6,100);
m="windows NT:"+nt.getState();
g.drawString(m,6,120);
m="solaris:"+sol.getState();
g.drawString(m,6,140);
m="Macos:"+mac.getState();
g.drawString(m,6,160);


}
}


