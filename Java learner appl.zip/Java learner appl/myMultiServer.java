import java.net.*;
import java.io.*;

class myMultiServer
{
	public static void main(String ada[]) 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String str="";
		try
		{
			ServerSocket server=new ServerSocket(1400);
			while(true)
			{
				Socket clientSocket = server.accept();
				new handleClient(clientSocket);
			}
		}
		catch(Exception e){}
	}
}

class handleClient extends Thread
{
	Socket cliSock;
	BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	String str="";
	handleClient(Socket t) 
	{
		super("ClientThread");
		start();
		this.cliSock=t;
	}
	public void run()
	{
		try
		{
			InputStream myIS=cliSock.getInputStream();
			OutputStream myOS=cliSock.getOutputStream();
			BufferedReader mySocketIS=new BufferedReader(new InputStreamReader(myIS));
			PrintWriter mySocketOS=new PrintWriter(new BufferedWriter(new OutputStreamWriter(myOS)),true);
			System.out.println("Client Contacted :"+cliSock);
			mySocketOS.println("\nHello Client !!! Welcome in PACE");
			while(str.equals("bye") ==false)
			{
				str=mySocketIS.readLine();
				System.out.println("Client Sent : "+str);
				System.out.println("\nEnter Response : ");
				str=br.readLine();
				System.out.println("Sent : "+str+" :to Client");
				mySocketOS.println(str);
			}
		}
		catch(Exception e){}
	}
}