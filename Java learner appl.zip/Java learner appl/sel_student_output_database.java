import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.*;
import javax.swing.border.*;
class sel_student_output_database extends JFrame  implements ActionListener
 {
          JButton jb1,jb2,jb3;
          JTextField   jt1,jt2,jt3;
          JTable table;
          JComboBox jc1;
          int count1=0, count2=0, count3=0, count4=0, count5=0, count6=0, count7=0, count8=0;   
          JScrollPane jsp,jsp1;
           Container cp;
          JPanel jp1,jp2;
          int v,h,v1,h1;
          ResultSet rs,rs1,rs2,rs3,rs4,rs5,rs6,rs7,rs8;
          Statement st,st1;
          Connection con,con1;
          String  qry,qry1,qry2,qry3,qry4,qry5,qry6,qry7,qry8;
          public static void main(String args[])
          {
                    new sel_student_output_database();
          }
          sel_student_output_database()
          {
             super("Record Of Selected Students");
             getContentPane().setLayout(new BorderLayout());
             setSize(600,600);
 
             WindowListener l = new WindowAdapter()
              {
               public void windowClosing(WindowEvent we)
                  {
                  System.exit(0);
                 }
              };
          addWindowListener(l);
          jp1 = new JPanel();
          cp = getContentPane();
          GridBagLayout gb = new GridBagLayout();
          GridBagConstraints gbc =new GridBagConstraints();

          jp1.setLayout(gb);
          gbc.weightx=1;
          gbc.weighty=1;
          gbc.gridwidth=1;
          gbc.gridheight=1;

          final String[] colHeads ={"Roll_no","Name","Phone_no","Email_id", "Branch","Company_Name","Year","Month"};
          String[][] data=new String[50][8];
          int i=0,j=0;

          v= ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
          h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;

          try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
            Statement st   = con.createStatement();
           ResultSet rs = st.executeQuery("select roll_no,name,phone_no,email_id,branch,company_name,year,month  from s_records ");
            System.out.println("Abhi Data Nikal liya");
            while(rs.next())
            {  j=0;
              while(j<8)
               {
                 System.out.println("data array main bheja ja raha hai");
                 String str=rs.getString(j+1);
	str=str+"                                                    ".substring(0,"                                                    ".length()-str.length());
	data[i][j]=str;
                 System.out.println(data[i][j]);
                 j++;
               }
             i++;
            }
            System.out.println("Abhi Data dikha kya");
            }
           catch(Exception e)
            {
                    System.out.println("Error : "+e);
            }
  
           table = new JTable (data,colHeads);
           table.setSize(100,100);
           jsp= new JScrollPane(table,v,h);
           table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
           
           jp2 = new JPanel();
           GridBagLayout gb1 = new GridBagLayout();
           GridBagConstraints gbc1 =new GridBagConstraints();
           Border etched1 =BorderFactory.createEtchedBorder();
           Border titled1 = BorderFactory.createTitledBorder(etched1, "Criteria");
           jp2.setBorder(titled1);
 
           jp2.setLayout(gb1);
           gbc1.weightx=1;
           gbc1.weighty=1;
           gbc1.gridheight=1;
           gbc1.gridwidth=1;

           JLabel jl1=new JLabel("Branch");

           gbc1.gridx=0;
           gbc1.gridy=1;
           jp2.add(jl1,gbc1);

 
           jc1 =  new JComboBox();
           jc1.addItem("-");
           jc1.addItem("Information Tecnology");
           jc1.addItem("Electronics & Telecommunication");
           jc1.addItem("Electrical");
           jc1.addItem("Mecanical");
           jc1.addItem("Civil");
           jc1.addItem("Industrial Production");
           jc1.addItem("ComputerScience");
           jc1.addItem("M.C.A");

           gbc1.gridx  =  1;
           gbc1.gridy   = 1;
           jp2.add(jc1,gbc1);

           JLabel jl3=new JLabel("Count");
           gbc1.gridx=2;
           gbc1.gridy=1;
           jp2.add(jl3,gbc1);

           gbc1.gridx  =  3;
           gbc1.gridy   = 1;
           jt3 =  new JTextField(5);
           jp2.add(jt3,gbc1);
             
         
           JLabel jl2=new JLabel("Company");
           gbc1.gridx=0;
           gbc1.gridy=2;
           jp2.add(jl2,gbc1);

           gbc1.gridx  =  1;
           gbc1.gridy   = 2;
           jt2 =  new JTextField(15);
           jp2.add(jt2,gbc1);

           jb1=new JButton("Exit");
           gbc1.gridx=0;
           gbc1.gridy=25;
           jp2.add(jb1,gbc1);

           gbc1.gridx  =  1;
           gbc1.gridy   = 25;
           jb2 =  new JButton("OK");
           
           jp2.add(jb2,gbc1);
           gbc1.gridx  =  2;
           gbc1.gridy   = 25;
           jb3 =  new JButton("Rank-Chart");
           
           jp2.add(jb3,gbc1);
           jb1.addActionListener(this);
           jb2.addActionListener(this);
           jb3.addActionListener(this); 
         
           GridBagLayout cgb = new GridBagLayout();
           GridBagConstraints cgbc =new GridBagConstraints();
           cp.setLayout(cgb);
           
           cgbc.gridx  =  0;
           cgbc.gridy   = 0;
           cp.add(jsp,cgbc);

           cgbc.gridx  =  0;
           cgbc.gridy   = 20;
           cp.add(jp2,cgbc);
       
           setVisible(true);


}


      
            
public void  actionPerformed(ActionEvent ae)
    {
        int i1=0;int flag=0;int flag1=0;int count=0;int grow=0;
        final String[] colHeads ={"Roll_no","Name","Phone_no","Email_id","Branch","Company_Name","Year","Month"};
       Object source=ae.getSource();
       if (source == jb2)
       try
       {             
        
            String[][] data=new String[50][8];
         if (!jc1.getSelectedItem().equals("-") &&jt2.getText().equals(""))
         {              JOptionPane.showMessageDialog(this,"abhi ander aaye hain");
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry="select roll_no,name,phone_no,email_id,branch,company_name,year,month  from s_records where branch = '"+jc1.getSelectedItem()+"' ";
            rs = st.executeQuery(qry);
            flag1=1;
            
         }

         if (jc1.getSelectedItem().equals("-") &&!jt2.getText().equals(""))
         {              JOptionPane.showMessageDialog(this,"abhi ander aaye hain");
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry1="select roll_no,name,phone_no,email_id,branch,company_name,year,month  from s_records where company_name='"+jt2.getText()+ "' ";
            rs = st.executeQuery(qry1);
         }
         if (!jc1.getSelectedItem().equals("-") &&!jt2.getText().equals(""))
         {              JOptionPane.showMessageDialog(this,"abhi ander aaye hain");
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry2="select roll_no,name,phone_no,email_id,branch,company_name,year,month  from s_records where branch='"+jc1.getSelectedItem()+"' and company_name='"+jt2.getText()+ "' ";
            rs = st.executeQuery(qry2);
         }

            //System.out.println(qry);
            
            //rs = st.executeQuery(qry);
            while(rs.next())
           {      
                    flag=1;grow=1;
                   
               
                int  j1=0;
	   //   JOptionPane.showMessageDialog(this,"abhi loop chalega");
                    while(j1<8)
                    {
                   
               
                 String str1=rs.getString(j1+1);
          str1=str1+"                                                ".substring(0,"                                                ".length()-str1.length());
          data[i1][j1]=str1;
                           
                              j1++;
                    }
                  count++;  i1++;
               setSize(600,600);
            }
            if(flag==0)
             {
               	JOptionPane.showMessageDialog(this,"Sorry! no records");
           } 
          
           
           cp.remove(jsp);    
           table = new JTable (data,colHeads);
           table.setSize(100,100);
           table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
           jsp= new JScrollPane(table,v,h);
                      if(grow==1)
                     {
                      setSize(650,650);
                      grow=0;
                       }      
           if(flag1==1)
           {
            jt3.setText(count+"");
           }
           else
          {
           jt3.setText("");            
          }
          cp.add(jsp,"Center");

}
      catch(Exception e)
       {} 
        
      if(source ==jb3)
      {
          
           try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry1="select *  from s_records where branch='Information Tecnology' ";
            rs1 = st.executeQuery(qry1);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
                   
            qry2="select *  from s_records where branch='Electronics & Telecommunication' ";
            rs2 = st.executeQuery(qry2);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
            qry3="select *  from s_records where branch='Electrical' ";
            rs3 = st.executeQuery(qry3);     
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
       
            qry4="select *  from s_records where branch='Mechanical' ";
            rs4= st.executeQuery(qry4);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
                   qry5="select *  from s_records where branch='Civil' ";
            rs5 = st.executeQuery(qry5);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
                   qry6="select *  from s_records where branch='Industrial Production' ";
            rs6 = st.executeQuery(qry6);
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
                   qry7="select *  from s_records where branch='ComputerScience' ";
            rs7 = st.executeQuery(qry7);                    
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            con=DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger");
            st=con.createStatement();
                   qry8="select *  from s_records where branch='M.C.A' ";
            rs8 = st.executeQuery(qry8);
  
            while(rs1.next())
           {      
                int  j1=0;
	            while(j1<8)
                    {                   
                         j1++;
                    }
                  count1++;  
            }
            while(rs2.next())
           {      
                int  j2=0;
	            while(j2<8)
                    {
                   
                         j2++;
                    }
                  count2++;  
            }  while(rs3.next())
           {      
                int  j3=0;
	            while(j3<8)
                    {
                   
                         j3++;
                    }
                  count3++;  
            }  while(rs4.next())
           {      
                int  j4=0;
	            while(j4<8)
                    {
                   
                         j4++;
                    }
                  count4++;  
            }  while(rs5.next())
              {  int  j5=0;
	            while(j5<8)
                    {
                   
                         j5++;
                    }
                  count5++;  
            }  while(rs6.next())
           {      
                int  j6=0;

                    while(j6<8)
                    {
                   
                         j6++;
                    }
                  count6++;  
            }  while(rs7.next())
           {      
                int  j7=0;
	
                    while(j7<8)
                    {
                   
                         j7++;
                    }
                  count7++;  
            }  while(rs8.next())
           {      
                int  j8=0;

                    while(j8<8)
                    {
                   
                         j8++;
                    }
                  count8++;  
            }     
	int student_count[]={count1*20,count2*20,count3*20,count4*20,count5*20,count6*20,count7*20,count8*20};
	myGraph x=new myGraph(student_count,"Student Count Chart");
	
}
 catch(Exception e)
{
	System.out.println("ERRRRRORRR"+e);}
	
       }





  }

}    