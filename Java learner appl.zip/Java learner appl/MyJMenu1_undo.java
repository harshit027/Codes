//package enc;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.lang.Object.*;
import javax.swing.JToolBar.*;
import java.awt.datatransfer.*;
import javax.swing.undo.*;
import javax.swing.text.*;
import javax.swing.event.*;
import java.util.Hashtable;
import java.io.*;

class editor extends JFrame implements ActionListener,FocusListener,KeyListener
{
	JMenuBar jmb;
	JMenu jm[];
	String temp,temp1,temp2;
	boolean flag=true;
	JMenuItem jmi[],jmi1[],jmi2,jmi3,popjmi[];
	JPanel p,p1;
	JButton btn[];
	JScrollPane jsp;
	JTextArea jta;
	JTextPane textPane;
	JLabel jlb;
	ButtonGroup bg;
	ImageIcon icon;
	JToolBar toolBar;
	JPopupMenu popup;
	String b1[]={"UPLOAD","ENCRYPT","DECRYPT"};
	String open;

	final Toolkit kit;
                final Clipboard clipboard;

	static final int MAX_CHARACTERS = 300;

	Color myColor=Color.orange;

    keyword11R x=new keyword11R();

	editor()
	{
		setTitle("Pace Bureau");

		jmb=new JMenuBar();
		jm=new JMenu[4];
		jm[0]=new JMenu("File");
		jm[1]=new JMenu("Edit");
		jm[2]=new JMenu("Format");
		jm[3]=new JMenu("Help");


		jmi=new JMenuItem[5];
		jmi[0]=new JMenuItem("New",new ImageIcon("new.gif"));
		jmi[1]=new JMenuItem("Open");

		jmi[1].setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_1, ActionEvent.ALT_MASK));

		jmi[2]=new JMenuItem("Save");
		jmi[3]=new JMenuItem("Save As");
		jm[1].addSeparator();
		jmi[4]=new JMenuItem("Close");
		jm[0].add(jmi[0]);
		jm[0].add(jmi[1]);
		jm[0].add(jmi[2]);
		jm[0].add(jmi[3]);
		jm[0].add(jmi[4]);

		jmi1=new JMenuItem[11];
		jmi1[0]=new JMenuItem("Undo",new ImageIcon("undo.gif"));
		//menu.addSeparator();
		jmi1[1]=new JMenuItem("Cut",new ImageIcon("cut.gif"));
		jmi1[2]=new JMenuItem("Copy",new ImageIcon("copy.gif"));
		jmi1[3]=new JMenuItem("Paste",new ImageIcon("paste.gif"));
		jmi1[4]=new JMenuItem("Delete",new ImageIcon("delete.gif"));
		//menu.addSeparator();
		jmi1[5]=new JMenuItem("Find...",new ImageIcon("search.gif"));
		jmi1[6]=new JMenuItem("Find Next");
		jmi1[7]=new JMenuItem("Replace..",new ImageIcon("base.gif"));
		jmi1[8]=new JMenuItem("Go to...",'G');
		//menu.addSeparator();
		jmi1[9]=new JMenuItem("Select All",'A');
		jmi1[10]=new JMenuItem("Time/Date",new ImageIcon("date.gif"));
		for(int i=0;i<11;i++)
		{
			jm[1].add(jmi1[i]);
			jmi1[i].addActionListener(this);
		}

		jmi2=new JMenuItem();
		jmi2=new JMenuItem("Font");
		jm[2].add(jmi2);

		jmi3=new JMenuItem();
		jmi3=new JMenuItem("About Editor");
		jm[3].add(jmi3);
		for(int i=0;i<=3;i++)
		{
			jmb.add(jm[i]);
			jmi[i].addActionListener(this);
		}

		jmi2.addActionListener(this);
		jmi3.addActionListener(this);


/*		toolBar = new JToolBar()
		{
			public boolean isFocusTraversable()
			{
				return true;
			}
		};*/

		p=new JPanel();
		p1=new JPanel();
		p.setBackground(myColor);
		p1.setBackground(myColor);
		p.repaint();
		btn= new JButton[3];

		Border myBorder=BorderFactory.createBevelBorder(BevelBorder.LOWERED,Color.orange,Color.black);
		Border titled=BorderFactory.createTitledBorder(myBorder,"");
		getContentPane().setLayout(new BorderLayout());
		jta=new JTextArea(25,56);

		jsp=new JScrollPane(jta);
		p.add(jsp);
		jta.addKeyListener(this);
		getContentPane().add(p,"East");
		getContentPane().add(p1,"South");
		p1.setBorder(titled);

		bg=new ButtonGroup();
		buttongrp(bg);

		setJMenuBar(jmb);
		setSize(800,560);
		setLocation(0,0);

		//Adding Image on to the JLabel
		icon = new ImageIcon("BALL_ANI.gif");
    		jlb = new JLabel("Pace Bureau",icon,JLabel.LEFT);
		getContentPane().add(jlb);

		kit = Toolkit.getDefaultToolkit();
                	clipboard = kit.getSystemClipboard();


///////////////////////////////////////////////////////////////////


		//Create the popup menu.

        popup = new JPopupMenu();
    	popjmi=new JMenuItem[6];
        popjmi[0] = new JMenuItem("Undo");
        popjmi[0].addActionListener(this);
        popup.add(popjmi[0]);

        popup.addSeparator();

        popjmi[1] = new JMenuItem("Cut");
        popjmi[1].addActionListener(this);
        popup.add(popjmi[1]);

    	popjmi[2] = new JMenuItem("Copy");
        popjmi[2].addActionListener(this);
        popup.add(popjmi[2]);

    	popjmi[3] = new JMenuItem("Paste");
        popjmi[3].addActionListener(this);
        popup.add(popjmi[3]);

    	popjmi[4] = new JMenuItem("Delete");
        popjmi[4].addActionListener(this);
        popup.add(popjmi[4]);

    	popup.addSeparator();

    	popjmi[5] = new JMenuItem("Select All");
        popjmi[5].addActionListener(this);
        popup.add(popjmi[5]);


	//Add listener to components that can bring up popup menus.
        MouseListener popupListener = new PopupListener();
        jta.addMouseListener(popupListener);
        jsp.addMouseListener(popupListener);
        jmb.addMouseListener(popupListener);

                   /*------------------ToolBar------------------------------------------*/

		toolBar = new JToolBar()
		{
			public boolean isFocusTraversable()
			{
				return true;
			}
		};


		toolBar.addFocusListener(this);

 		toolBar.add( new JButton(new ImageIcon("cut.gif")));
		toolBar.add( new JButton(new ImageIcon("copy.gif")));
 		toolBar.add( new JButton(new ImageIcon("paste.gif")) );
 		toolBar.add( new JButton(new ImageIcon("bold.gif")) );
 		toolBar.add( new JButton(new ImageIcon("italic.gif")) );
	    toolBar.add( new JButton(new ImageIcon("underline.gif")) );
        toolBar.add( new JButton(new ImageIcon("undo.gif")) );
	    toolBar.add( new JButton(new ImageIcon("redo.gif")) );

		getContentPane().add( toolBar, BorderLayout.NORTH );



	    show();

}              //--------------------------------------------------CLOSING CONSTRUCTOR

		public void buttongrp(ButtonGroup bg)
		{
			for(int i=0;i<3;i++)
			{
			btn[i]=new JButton(b1[i]);
			bg.add(btn[i]);
			p1.add(btn[i]);

			}
		btn[1].addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
				String strenc=jta.getText();

				String readenc="",readenc1="";
				try{int bool=strenc.length();
				if((bool%2)==1)
					{
						strenc=strenc+'.';
					}
                //enc.key k=new enc.key(strenc);
                x.keyGenerate();
                x.getEncryption(strenc,"myenc.txt");
		//---------Openig the encrypted file----------------

				FileReader fr= new FileReader("myenc.txt");
				BufferedReader br=new BufferedReader(fr);
				while((readenc=br.readLine()) !=null)
				{
						readenc1+=readenc;
						readenc1+="\n";
				}
				jta.setText(readenc1);
			}
			catch(Exception io)
			{
					System.out.println(io);
			}
				}
		});
		btn[2].addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent ae)
			{
                String strenc=jta.getText();
				try
                {
                    //System.out.println(open);
                    //enc.key k=new enc.key('c',"strenc");
                    jta.setText(x.getDecryption("myenc.txt"));
                }
                catch(Exception io)
                {
                    System.out.println(io);
                }
            }
		});


		}

	public void focusGained(FocusEvent e)
	{
		System.out.println("gained");
	}

	public void focusLost(FocusEvent e)
	{
		System.out.println("lost");
	}

/*------------------------------- Function Main ------------------------------------------*/

	public static void main(String args[])
    throws Exception
    {
    	JFrame f=new editor();
		f.show();
	 }
	public void keyPressed(KeyEvent ke)
	{
		if(flag==true)
		{
			temp=jta.getText();
			flag=false;
		}
			//System.out.println(temp);
	}
	public void keyReleased(KeyEvent ke)
	{

	}
	public void keyTyped(KeyEvent ke)
	{}
//////////////////////////////////////////////////////////////////

	 class PopupListener extends MouseAdapter
	 {
        	public void mousePressed(MouseEvent e)
	    	{
            		maybeShowPopup(e);
        	}

	        public void mouseReleased(MouseEvent e)
	    	{
        		maybeShowPopup(e);
        	}

        	private void maybeShowPopup(MouseEvent e)
	    	{
            		if (e.isPopupTrigger())
	        		{
                		popup.show(e.getComponent(),e.getX(), e.getY());
            		}
        	}
	 }

//////////////////////////////////////////////////////////////////

	public void actionPerformed(ActionEvent ae)
	{
		JMenuItem mit=(JMenuItem)ae.getSource();
		JFileChooser jfc = new JFileChooser();
		JFrame jf=new JFrame();

/*--------For New ------------------*/


		if(mit==jmi[0])
		{
			Container c=getContentPane();
			c.setLayout(new BorderLayout());
			c.add(jta,"North");
			show();
		}


/*--------For Open Dialog Box--------*/

		if(mit==jmi[1])
		{
			try{
						String str1="", str="";
						jfc.showOpenDialog(jf);
						open=jfc.getSelectedFile().getName();

						File fopen =new File(open);
						FileReader fr= new FileReader(fopen);
						BufferedReader br=new BufferedReader(fr);

						while((str=br.readLine()) !=null)
						{
							str1+=str;
							str1+="\n";
							//System.out.println(str);
						}
						jta.setText(str1);
					}
					catch(Exception e)
					{
						System.out.println("Error in reading file : "+e);
		}
		}

/*--------For Save Dialog Box--------*/

		if(mit==jmi[2])
		{
			jfc.showSaveDialog(jf);
		}

/*--------For Closing Window--------*/

                               if(mit==jmi[4])
		{
			System.exit(0);
		}

/*--------For Undo Manager----------*/

		if(mit==jmi1[0])
		{
			temp1=temp;
			temp=jta.getText();
			//jta.setText(temp2,temp1);
			flag=true;
		}
/*----------For Cut Function---------*/

		if((mit==jmi1[1])||(mit==popjmi[1]))
		{
			temp2=jta.getText();
			String selection = jta.getSelectedText();
			temp=selection;
			jta.replaceSelection("");
	        		StringSelection data = new StringSelection(selection);
        			clipboard.setContents(data,data);
		}

/*--------For Copy Function----------*/

		if((mit==jmi1[2])||(mit==popjmi[2]))
		{
			String selection = jta.getSelectedText();
        		StringSelection data = new StringSelection(selection);
        		clipboard.setContents(data, data);
		}

/*--------For Paste Function---------*/

		if((mit==jmi1[3])||(mit==popjmi[3]))
		{
			Transferable clipData = clipboard.getContents(clipboard);
        		if (clipData != null)
			{
          		   try
		       	   {
            			if (clipData.isDataFlavorSupported(DataFlavor.stringFlavor))
				{
             				String s = (String)(clipData.getTransferData(DataFlavor.stringFlavor));
             	 			jta.replaceSelection(s);
            			}
				else
				{
              	 			kit.beep();
            			}
         		   }
	 		   catch (Exception e)
	 		   {
           	 		System.err.println("Problems getting data:" + e);
         		   }
        		}
		 }

/*----------For Delete Function---------*/

		if((mit==jmi1[4])||(mit==popjmi[4]))
		{

			jta.replaceSelection("");
		}

/*----------For Select All Function---------*/

		if((mit==jmi1[5])||(mit==popjmi[5]))
		{
			jta.selectAll();
		}

	}

}
