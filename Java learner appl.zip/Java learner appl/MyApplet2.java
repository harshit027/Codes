import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*
	<applet code="MyApplet2" width=400 height=400>
	</applet>
*/
public class MyApplet2 extends Applet
{
	Color  bgColor=new Color(255,255,0);
	public void init()
	{
		setForeground(Color.red);
		MyColorThread t = new MyColorThread(this);
	}
	public void paint(Graphics g)
	{
		setBackground(bgColor);
		Dimension d = getSize();
		g.setColor(new Color(0,0,255));
		g.drawRect(50,50,50,50);
		g.drawString("PACE BUREAU",d.width/2-20,d.height/2);
		g.setColor(new Color(255,255,0));
		g.drawLine(0,0,d.width,d.height);
		g.drawLine(d.width,0,0,d.height);
		g.setColor(new Color(255,255,255));
		g.drawOval(0,0,d.width,d.height);
		int []x = {10,60,90,60,10};
		int []y = {10,10,50,120,120};
		g.setColor(new Color(96,96,96));
		g.drawPolygon(x,y,4);
		g.setColor(new Color(34,66,232));
		g.drawArc(100,100,200,200,5,50);
		g.setColor(new Color(0,166,32));
		g.fillArc(100,100,200,200,30,300);
	}
}

class MyColorThread extends Thread
{
	MyApplet2 ref;
	int r,g,b;
	MyColorThread(MyApplet2 ref)
	{
			this.ref = ref;
			r=5;g=10;b=50;
			start();
	}
	public void run()
	{
		while(true)
		{
			ref.bgColor = new Color(r,g,b);
			ref.repaint();
			r+=10;g+=15;b+=6;
			if(r>255) r=0;
			if(g>255) g=0;
			if(b>255) b=0;
			try
			{
				sleep(1000);
			}
			catch(InterruptedException ie)
			{
				System.out.println("Error : "+ie);
			}
		}
	}
}