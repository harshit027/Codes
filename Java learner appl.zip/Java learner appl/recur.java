class recur
{
         public static void main(String a[])
           {
                  int n=12345;
                  System.out.println(sum(n));
            }
            static int sum(int n)
            {
                int j=0;
               if(n>0)
               {
                   j=n%10+sum(n/10);
               }
               return j;
           }
}
