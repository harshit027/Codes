class diag
{
    public static void main(String args[])
    {
        int  a[][] = new int[5][];
        int i,j,k=0;int x[]=new int[10];
    for(i=0;i<=4;i++)
    {
        a[i]=new int[i+1];
    }
    for(i=0;i<=4;i++)
        for(j=0;j<i+1;j++)
         {
              a[i][j]=k;
               k++;
          }
    for(i=0;i<=4;i++)
      {
        for(j=0;j<i+1;j++)
            System.out.print(a[i][j]+" ");
                              System.out.println();
      }
    int l=4,m=0;
    while(m<=4)
    {
    for(int z=0;z<=4;z++)
    {
    x[z]=0;
           for(j=0;j<l;j++)
       {
            i=m;
           x[z]+=a[i][j];
           i=i+1;
       }
           System.out.println("sum "+x[z]);
            System.out.println();
    }
       l=l-1;
       m=m+1;

       }
        
}
}
