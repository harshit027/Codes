
import java.awt.*;
import java.applet.*;
import java.net.*;
public class Applet1 extends Applet
{
	int i=1;
	public void paint(Graphics g)
	{
		i++;
		setBackground(Color.orange);
		setForeground(Color.green);
		try
		{
			URL myurl = getCodeBase();
			myurl = new URL(myurl+"fish.gif");
			g.drawString("PACE BUREAU"+i,60,60);
			AppletContext ac = getAppletContext();
			ac.showDocument(myurl,"_blank");
			play(new URL(getCodeBase()+"mysound.wav"));
		}
		catch(Exception e)
		{}
	}
}
/*
<applet code="Applet1.class" width=400 height=300>
</applet>
*/