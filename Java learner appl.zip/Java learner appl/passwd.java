
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class passwd extends JFrame  implements ActionListener
{  
 public static void main(String args[])
 { 
  JFrame jframe=new JFrame("Entry Form");
  jframe.setSize(200,200);
 
  //jframe.resizeable(false);
  WindowListener l = new WindowAdapter()
  {
   public void windowClosing(WindowEvent we)
   {
    System.exit(0);
   }
  };
 jframe.addWindowListener(l);

 GridBagLayout gb = new GridBagLayout();
 GridBagConstraints gbc = new GridBagConstraints();
 Container cp = jframe.getContentPane();
 JPanel jp = new JPanel();

 jp.setLayout(gb);
 jp.setBorder(BorderFactory.createCompoundBorder());
 gbc.gridwidth=1;
 gbc.gridheight=1;
 gbc.weightx=0.1;
 gbc.weighty=0.1; 

 JLabel jl1 = new JLabel("User_name"); 
 JLabel jl2 = new JLabel("Password"); 
 JTextField jt1 = new JTextField(15);
 JTextField jt2 = new JTextField(15);
 JButton jb1=new JButton("OK");
 JButton jb2=new JButton("Exit");

 

 gbc.gridx =10;
 gbc.gridy =10;
 jp.add(jl1,gbc);


 gbc.gridx =11;
 gbc.gridy =10;
 jp.add(jt1,gbc);

   

 gbc.gridx =10;
 gbc.gridy =12;
 jp.add(jl2,gbc);

 gbc.gridx =11;
 gbc.gridy =12;
 jp.add(jt2,gbc);

 gbc.gridx =10;
 gbc.gridy =13;
 jp.add(jb1,gbc);

 gbc.gridx =11;
 gbc.gridy =13;
 jp.add(jb2,gbc);


 cp.add(jp);
 jframe.pack();

  jframe.setVisible(true);
  jframe.setResizable(false);

 }

public void actionPerformed(ActionEvent ae)
{



}


