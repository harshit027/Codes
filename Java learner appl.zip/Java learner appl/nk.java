import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
/*<applet code =nk width=400 height=500>
</applet>
*/

public class nk extends JApplet implements ActionListener
    {
     JButton btn=new JButton("OK");
     JButton btn1=new JButton("cancel");
    JLabel jl= new JLabel("hello");
     Container cp=getContentPane();

     public void init()
     {
     cp.setLayout(new FlowLayout());
     //cp.setLayout(new BorderLayout());

     cp.add(btn);
     cp.add(btn1);
    // cp.add(jl);

     btn.addActionListener(this);
     }
    public void actionPerformed(ActionEvent ae)
  {
//    showStatus("buttun is pressed");
   // JTextField jt= new JTextField(15);
  jl = new JLabel("hello");
    cp.add(jl);


    }
}
