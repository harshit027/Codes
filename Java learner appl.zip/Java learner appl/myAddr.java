import java.net.*;

class myAddr 
{
	public static void main(String args[]) throws Exception
	{
		InetAddress x;
		x=InetAddress.getLocalHost();
		System.out.println(x+"");
		x=InetAddress.getByName("Node7");
		System.out.println(x+"");
		InetAddress y[]=InetAddress.getAllByName("202.54.4.11");
		for(int i=0;i<=y.length-1;i++)
		{
			System.out.println(y[i]+"");
			System.out.println(y[i].getAddress()[0]+"\n"+y[i].getAddress()[1]+"\n"+y[i].getAddress()[2]+"\n"+y[i].getAddress()[3]);
			System.out.println(y[i].getHostAddress()+"");
		}
	}
}