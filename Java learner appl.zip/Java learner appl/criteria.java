import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.table.*;

class criteria extends JFrame 
 {
          JTable table;
          JScrollPane jsp;
           Container cp;
          JPanel jp1;
          int v,h;
          ResultSet rs;
          Statement st;
          Connection con;
          String  qry,qry1,qry11;
          public static void main(String args[])
          {
                    new criteria();
          }
          criteria()
          {
             super("Criteria of companies");
             
             setSize(800,800);
 
             WindowListener l = new WindowAdapter()
              {
               public void windowClosing(WindowEvent we)
                  {
                  System.exit(0);
                 }
              };
          addWindowListener(l);
          jp1 = new JPanel();
          cp = getContentPane();
          GridBagLayout gb = new GridBagLayout();
          GridBagConstraints gbc =new GridBagConstraints();

          jp1.setLayout(gb);
          gbc.weightx=1;
          gbc.weighty=1;
          gbc.gridwidth=1;
          gbc.gridheight=1;

          final String[] colHeads ={"company_id","company_name","company_criteria"};
          String[][] data=new String[10][3];
          int i=0,j=0;

          v= ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS;
          h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS;

          try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
            Connection con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
            Statement st   = con.createStatement();
            String qry11="select company_id,company_name,company_criteria from criteria";
	JOptionPane.showMessageDialog(this,qry11);
            ResultSet rs = st.executeQuery(qry11);
            //ResultSet rs = st.executeQuery("select student_data.roll_no,name,category,dob,fathername,course,branch,semester,phone_no,tenth,twelvth,graduation,sem1,sem2,sem3,sem4,sem5,sem6,sem7,sem8,aggregate,post_graduation,psem1,psem2,psem3,psem4,psem5,psem6,paggregate  from student_data,s_marks where student_data.roll_no=s_marks.roll_no");
            System.out.println("Abhi Data Nikal liya");
            while(rs.next())
            {  j=0;
              while(j<3)
               {
                 System.out.println("data array main bheja ja raha hai");
                 String str=rs.getString(j+1);
	str=str+"                                                ".substring(0,"                                                ".length()-str.length());
	data[i][j]=str;
                 System.out.println(data[i][j]);
                 j++;
               }
             i++;
            }
            System.out.println("Abhi Data dikha kya");
            }
           catch(Exception e)
            {
                    System.out.println("Error : "+e);
            }
  
          table = new JTable (data,colHeads);
	  table.setSize(500,200);
          //table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
          jsp= new JScrollPane(table,v,h);
           cp.add(jsp,"Center");


       setVisible(true);

}
}