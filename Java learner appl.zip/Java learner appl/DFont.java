import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.Graphics;
import java.util.Hashtable;
import java.net.URL;
//import java.util.*;



public class DFont implements ActionListener,ItemListener//,TextListener
{
	static Frame f1;
	static int idf[],ids[],idfs[];
	static int i=0;
	static JPanel p1;
	static JDialog fd;
	static JButton ok,mail,cancel;
	static List fontlist,fst,fsiz;
	static TextField fname,fstyl,fsize;//Font Storing Text field
	static JTextPane text1;
	static Font ft1;
	static GraphicsEnvironment ge;
	static String name[];
	static String fsname[]={"Plain", "Bold", "Italic", "Bold Italic"};
	static String fsz[]={"4","6","8","10","12","14","16","18","20","24","26","28","30","34"};
	static JTextPane t1;
	static Font fnt;
	static String fs;//Variable below will store text from text fields fs fstr fsizstr styl size
	static String fstr;
	static String fsizstr;
	static int styl;
	static int size;
	static	Hashtable styles;
	static JTextPane preview=new JTextPane();
	static JButton pbtn=new JButton();
	public  DFont(JTextPane tcx,Frame owner,String title,boolean model)
	 {

		try
		{
			preview.setEditable(false);
			init(tcx,owner,title,model);
		}
		catch (Exception e)
		{
			System.out.println(e);
		}

		fd.setSize(new Dimension(460,350));
		//fd.setResizable(false);
		fd.setVisible(true);
		f1.setSize(300,333);
		f1.setVisible(false);
	}
	public void actionPerformed(ActionEvent a)
	{
		if (a.getSource()==ok)
		{
			font(t1);
			System.out.println(a);
		}
		else if (a.getSource()==cancel)
		{
			fd.dispose();
		}
		else if (a.getSource()==mail)
		{
			try
			{
				Runtime.getRuntime().exec("rundll32.exe url.dll,FileProtocolHandler email.eml");
			}
			catch (Exception e)
			{

			}
		}

	}

	public void  init(JTextPane t2,Frame ff1,String str,boolean modl)throws Exception
	{
		//JFrame.setDefaultLookAndFeelDecorated(true);
		f1=new Frame();
		//Hash Table
			styles = new Hashtable();
        styles.put("Plain", new Integer(Font.PLAIN));
        styles.put("Bold", new Integer(Font.BOLD));
        styles.put("Italic", new Integer(Font.ITALIC));
        styles.put("Bold Italic", new Integer(Font.BOLD | Font.ITALIC));
		//Hash Table
		//f1=owner;
		p1=new JPanel();
		fd=new JDialog(ff1,str,modl);
		ok=new JButton("OK");//<html><body bgcolor=cyan><font color=blue><table border=2 height=20 width=70><B><b><p><center>O<font color=red>
		cancel=new JButton("Cancel");//<html><body bgcolor=cyan><B><b><p><table border=2 height=20 width=70><tr><td><font size=3 color=blue>C<font color=red>a<font color=blue>n<font color=green>
		mail=new JButton("<html><font color=red>Mail</font><font color=blue><i><u>Me");
		t1=new JTextPane();
		t1=t2;
		fontlist=new List();
		fst=new List();
		fsiz=new List();
		ge=GraphicsEnvironment.getLocalGraphicsEnvironment();
		name=ge.getAvailableFontFamilyNames();

				for(int x=0;x<name.length;x++)
				{
					fontlist.addItem(name[x]);
				}
				for (int y=0;y!=4;y++ )
				{
					fst.addItem(fsname[y]);
				}
				for (int a=0;a<fsz.length ;a++ )
				{
					fsiz.addItem(fsz[a]);
				}
		fname=new TextField("Arial",50);
		//fsize.addTextListener(this);
		fontlist.select(0);
		fname.setText(fontlist.getSelectedItem());


		fstyl=new TextField("Plain",50);
		fst.select(0);
		fstyl.setText(fst.getSelectedItem());

		fsize=new TextField("14",14);
		fsiz.select(4);
		fsize.setText(fsiz.getSelectedItem());
		fd.getContentPane().add(p1);
		p1.setLayout(null);//fontlist,fst,fsiz/textfld/fname,fstyl,fsize
		fname.setBounds(new Rectangle(10,30,140,20));
		fontlist.setBounds(new Rectangle(10,55,140,150));
		fstyl.setBounds(new Rectangle(155,30,110,20));
		fst.setBounds(new Rectangle(155,55,110,150));
		fsize.setBounds(new Rectangle(270,30,70,20));
		fsiz.setBounds(new Rectangle(270,55,70,150));
		ok.setBounds(new Rectangle(350,30,100,25));
		cancel.setBounds(new Rectangle(350,60,100,25));
		mail.setBounds(new Rectangle(350,90,100,35));
		pbtn.setBounds(new Rectangle(48,225,225,50));
		preview.setBounds(new Rectangle(57,229,200,43));
		p1.add(preview);
		p1.add(pbtn);
		p1.add(mail);
		pbtn.setEnabled(false);

		preview.setText("Font Preview");
		preview.setEnabled(false);
		p1.add(fname);
		p1.add(fontlist);

		p1.add(fstyl);
		p1.add(fst);
		p1.add(fsize);
		p1.add(fsiz);
		p1.add(ok);
		p1.add(cancel);
		//fontlist.setMaximumRowCount(10);
		ok.addActionListener(this);
		cancel.addActionListener(this);
		mail.addActionListener(this);
		fontlist.addItemListener(this);
		fst.addItemListener(this);
		fsiz.addItemListener(this);
	}
	public void itemStateChanged(ItemEvent ie)
	{
		if (ie.getSource()==fontlist)//fontnameList List
		/**
		@this update associated text as we select any item fs fstr fsizstr styl size
		*/
			{

					int idx[];
					idx=fontlist.getSelectedIndexes();
					for(int i=0;i<idx.length;i++)
					fs=fontlist.getItem(idx[i]);
					fname.setText(fs);
			}
			else if(ie.getSource()==fst)//Font Style list
			{
					int idx[];
					idx=fst.getSelectedIndexes();
					for(int i=0;i<idx.length;i++)
					fstr=fst.getItem(idx[i]);
					fstyl.setText(fstr);
			}
			else if (ie.getSource()==fsiz) //Font Size Listfs fstr fsizstr styl size
			{
					int idx[];
					idx=fsiz.getSelectedIndexes();
					for(int i=0;i<idx.length;i++)
					fsizstr=fsiz.getItem(idx[i]);
					fsize.setText(fsizstr);
			}
			preview.setFont(new Font(fname.getText(),((Integer)styles.get(fstyl.getText())).intValue(),Integer.parseInt(fsize.getText())));
	}
	/*public void textValueChanged(TextEvent te)
	{
		if(te.getSource()==fsize)
		{
			preview.setFont(new Font(fname.getText(),((Integer)styles.get(fst.getSelectedItem())).intValue(),Integer.parseInt(fsize.getText())));
		}
	}*/
	public static  JTextPane font(JTextPane ttx)
	{
		String nam=fname.getText();
		String stl=fstyl.getText();
		String size=fsize.getText();

		t1=ttx;
		ttx.setFont(new Font(nam,((Integer)styles.get(fst.getSelectedItem())).intValue(),Integer.parseInt(size)));
		fd.dispose();
		return ttx;

	}
}
