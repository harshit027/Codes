import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code= "chess" width= 200 height=200>
</applet>
*/
public class chess extends Applet
{

    int x=0,y=0;boolean flag=true;
    Dimension d;
    public void init()
    {
        d=getSize();
    }
    public void paint(Graphics g)
    {
    	x=d.width/8;
    	y=d.height/8;
        for(int i=0;i<=200-x;i+=x)
        {
         	for(int j=0;j<=200-y;j+=y)
         	{
         		g.drawRect(i,j,x,y);
         	}
    	}
    for(int i=0;i<=200-x;i+=(2*x))
        {
        for(int j=0;j<=200-y;j+=(2*y))
    	    {
    	    g.fillRect(i,j,x,y);
    	   // g.show();
    	    }
        }
    	for(int i=x;i<=200-x;i+=(2*x))
        {
    	    for(int j=y;j<=200-y;j+=(2*y))
    	    {
    		    g.fillRect(i,j,x,y);
    	   // g.show();
    	    }
        }
	}
}

