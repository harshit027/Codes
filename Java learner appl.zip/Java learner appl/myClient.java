import java.net.*;
import java.io.*;

class myClient
{
	public static void main(String ada[]) 
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String str="";
		try
		{
			Socket client=new Socket("202.54.4.11",1400);
			InputStream myIS=client.getInputStream();
			OutputStream myOS=client.getOutputStream();
			BufferedReader mySocketIS=new BufferedReader(new InputStreamReader(myIS));
			PrintWriter mySocketOS=new PrintWriter(new BufferedWriter(new OutputStreamWriter(myOS)),true);
			str=mySocketIS.readLine();
			System.out.println("Server Sent : "+str);
			while(str.equals("bye")==false)
			{
				str=mySocketIS.readLine();
				System.out.println("Server Sent : "+str);
				System.out.println("\nEnter Response : ");
				str=br.readLine();
				System.out.println("Sent : "+str+" :to Server");
				mySocketOS.println(str);
			}
			
		}
		catch(Exception e){}
	}
}
