import java.awt.event.*;
import java.awt.*;

public class applet2 extends java.applet.Applet
									implements MouseListener
{
	Color c=Color.yellow;
	int i;
	public void init()
	{
		addMouseListener(this);
	}
	public void paint(Graphics g)
	{
		setBackground(c);
	}
	public void mouseClicked(MouseEvent me)
	{
		switch(i)
		{
			case 0:
				c=Color.orange;break;
			case 1:
				c=Color.green;break;
			case 2:
				c=Color.pink;break;
			case 3:
				c=Color.white;break;
			case 4:
				c=Color.black;break;
			case 5:
				c=Color.red;break;
			case 6:
				c=Color.blue;break;
			case 7:
				c=Color.magenta;break;
		}
		i++;
		if(i>7)i=0;
		repaint();
	}
	public void mouseReleased(MouseEvent me)
	{}
	public void mouseEntered(MouseEvent me)
	{}
	public void mouseExited(MouseEvent me)
	{}
	public void mousePressed(MouseEvent me)
	{}
}

/*
	<applet id='app1' class="applet2.class" width=400 height=300>
	</applet>
*/