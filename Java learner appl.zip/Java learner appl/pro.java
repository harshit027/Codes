import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.*;

public class pro extends JFrame implements ActionListener 
{
        JButton b;
        JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11;
        JRadioButton r1,r2,r3,r4,r5,r6,r7,r8,r10,r11,r12;
        JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18;
        ButtonGroup group=new ButtonGroup();
        ButtonGroup group1=new ButtonGroup();
        ButtonGroup group2=new ButtonGroup();
        String st=" ";
        String st1=" ";
        pro()
        {
                Container contentpane=getContentPane();
                contentpane.setLayout(new GridLayout(25,0,2,10));
                l1=new JLabel("    S.No.");
                contentpane.add(l1);
                t11=new JTextField(2);
                contentpane.add(t11);

                l2=new JLabel("    Enter FileName");
                contentpane.add(l2);

                t1=new JTextField(20);
                contentpane.add(t1);

                l3=new JLabel("    Enter Title");
                contentpane.add(l3);

                t2=new JTextField(20);
                contentpane.add(t2);

                l4=new JLabel("    Enter Author");
                contentpane.add(l4);

                t3=new JTextField(20);
                contentpane.add(t3);

                l5=new JLabel("    Enter Background color");
                contentpane.add(l5);

                t4=new JTextField(20);
                contentpane.add(t4);

                l6=new JLabel("    Enter Text color");
                contentpane.add(l6);

                t5=new JTextField(20);
                contentpane.add(t5);

                l7=new JLabel("    Enter Link color");
                contentpane.add(l7);

                t6=new JTextField(20);
                contentpane.add(t6);

                l8=new JLabel("    Enter Scoring method");
                contentpane.add(l8);

                l9=new JLabel("");
                contentpane.add(l9);

                JRadioButton r1=new JRadioButton("Self-Test");
                JRadioButton r2=new JRadioButton("Retry-Test");
                JRadioButton r3=new JRadioButton("Email-In-Test");
                JRadioButton r4=new JRadioButton("correct and Email-Test");

                group.add(r1);
                group.add(r2);
                group.add(r3);
                group.add(r4);
                group.add(null);

                //contentpane.add(r11);
                contentpane.add(r1);
                contentpane.add(r2);
                contentpane.add(r3);
                contentpane.add(r4);
                //contentpane.add(null);

                
                l10=new JLabel("    Enter Number of questions");
                contentpane.add(l10);

                t7=new JTextField(20);
                contentpane.add(t7);
                System.out.println(st);

                l11=new JLabel("    Enter Question type");
                contentpane.add(l11);

                l12=new JLabel("");
                contentpane.add(l12);

                r5=new JRadioButton("Short answer");
                contentpane.add(r5);
                r6=new JRadioButton("True-False");
                contentpane.add(r6);
                r7=new JRadioButton("Multiple Choice");
                contentpane.add(r7);
                r8=new JRadioButton("Fill in the blanks");
                contentpane.add(r8);
                r10=new JRadioButton("Mixed type");
                contentpane.add(r10);
                l18=new JLabel("");
                contentpane.add(l18);


                group1.add(r5);
                group1.add(r6);
                group1.add(r7);
                group1.add(r8);
                group1.add(r10);
                

                l13=new JLabel("    Email");
                contentpane.add(l13);
                t8=new JTextField(30);
                contentpane.add(t8);

                l14=new JLabel("    Graphics Address");
                contentpane.add(l14);
                t9=new JTextField(20);
                contentpane.add(t9);

                l15=new JLabel("    External Links");
                contentpane.add(l15);
                t10=new JTextField(20);
                contentpane.add(t10);

                l16=new JLabel("    Display");
                contentpane.add(l16);
                l17=new JLabel("");
                contentpane.add(l17);

                r11=new JRadioButton("As HTML Page");
                contentpane.add(r11);
                r12=new JRadioButton("As Plain Text");
                contentpane.add(r12);
                group2.add(r11);
                group2.add(r12);

                //contentpane.setLayout(null);
                //contentpane.setLayout(new GridLayout(1,1));
                b=new JButton("CONTINUE");
                b.addActionListener(this);
                contentpane.add(b);
                setVisible(true);
        }
         public void actionPerformed(ActionEvent ae)
         {
          String so=ae.getActionCommand();
          if(so.equals("CONTINUE"))
          {
          st=t7.getText();
          }
          
          st1=group1.getSelectedCheckbox();
          myq q=new myq(st,st1);
          q.setVisible(true);
         }
        public static void main(String args[])
        {
         new pro();
        }

 }

class myq extends JFrame
{
        myq(String st,String st1)
        {
          JLabel l19,l20;
          l19=new JLabel("Number of questions:");
          JTextField  t12,t13;
          System.out.println(st);
          t12=new JTextField(" ",3);
          t12.setText(st);

          l20=new JLabel("Type of questions:");
          t13=new JTextField(" ",10);
          t13.setText(st1);
          //t13.setText()=r6.getText();
          //t13.setText()=r7.getText();
          //t13.setText()=r8.getText();
          //t13.setText()=r10.getText();
          Container c=getContentPane();
          c.setLayout(new FlowLayout());
          c.add(l19);
          c.add(t12);
          c.add(l20);
          c.add(t13);
          
         // c.add(t13);
          setVisible(true);
          }
      
}
