import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code= "chess1" width= 200 height=200>
</applet>
*/
public class chess1 extends Applet
{
       
    int x=0,y=0;
      Dimension d=getSize(); 

    public void paint(Graphics g)
    {
    x=200/10;
    y=200/10;


        for(int i=0;i<=200-x;i+=x)
         {
            for(int j=0;j<=200-y;j+=y)
           {
                g.drawRect(i,j,x,y);
            }
         }

    }

}

