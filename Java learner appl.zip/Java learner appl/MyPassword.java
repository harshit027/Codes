import java.awt.*;
import java.awt.event.*;

public class MyPassword
	extends java.applet.Applet
		implements ActionListener
{
	Label lbl1,lbl2;
	TextField txt1,txt2;
	Button btn1, btn2;
	public void init()
	{
		lbl1 = new Label("Enter User Name");
		lbl2 = new Label("Enter Password");
		txt1=new TextField(20);
		txt2=new TextField(20);

		btn1=new Button("Reset");
		btn2 = new Button ("Done");
		txt2.setEchoChar('*');
		add(lbl1);
		add(txt1);
		add(lbl2);
		add(txt2);
		add(btn1);
		add(btn2);
		btn1.addActionListener(this);
		btn2.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		Button btn=  (Button) ae.getSource();
		if(btn==btn1)
		{
			txt1.setText("");
			txt2.setText("");
		}
		if(btn == btn2)
		{

		}
	}
}

/*
	<applet code="MyPassword.class"
	width=300 height=300>
	</applet>
*/