import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
 /*<applet code= "im" width=400 height =400>
</applet> */
public class im extends JApplet implements ActionListener
 {

    JTextField tf;
         JLabel jl;
         Container c= getContentPane();
 public void init()
    {
    // Container c= getContentPane();
     ImageIcon i= new ImageIcon("HLPCD.GIF");

     JButton b = new JButton(i);
     c.setLayout(new FlowLayout());
    b.addActionListener(this);
     c.add(b);
     c.setBackground(Color.pink);
     }
     public void actionPerformed(ActionEvent ae) 
     {

         tf= new JTextField(20);
         c.add(tf);
        tf.setBackground(Color.blue);
        jl= new JLabel("tf");
        c.add(jl);
     }
}
