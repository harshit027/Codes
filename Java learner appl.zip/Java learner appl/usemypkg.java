import mypkg.*;

class usemypkg
{
	public static void main(String args[])
	{
		ShowString ss = new ShowString();
		ss.getString("PACE BUREAU");
		ss.showString();
	}
}