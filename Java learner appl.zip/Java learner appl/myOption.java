import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class myOption extends JFrame implements ActionListener
{
	JTabbedPane tp;
	JButton btn,btn1;
	JTextField jtf1,jtf2;
	public static void main(String sdfs[])
	{
		new myOption();
	}
	myOption()
	{
		tp=new JTabbedPane();
		btn=new JButton("Hello");
		jtf1=new JTextField(30);
		btn1=new JButton("PACE");
		jtf2=new JTextField(30);
		JPanel jp1=new JPanel();
		jp1.add(btn);
		jp1.add(jtf1);
		JPanel jp2=new JPanel();
		jp2.add(btn1);
		jp2.add(jtf2);
		tp.addTab("India",jp1);
		tp.addTab("Shrilanka",jp2);
		setSize(400,400);
		getContentPane().add(tp);
		jp1.setBackground(Color.pink);
		jp2.setBackground(Color.green);
		btn.addActionListener(this);
		btn1.addActionListener(this);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if((JButton)ae.getSource()==btn)
			JOptionPane.showMessageDialog(this,"Hello, World");
		else
			JOptionPane.showConfirmDialog(this,"Hello, World");
	}
}
