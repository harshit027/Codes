import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import java.sql.*;
import java.awt.event.*;

class MyPractice1 extends JFrame implements ActionListener
{
	JButton b1;
	MyPractice1()
	{
		setSize(400,400);
		b1=new JButton("Database");
		setLayout(new FlowLayout());
		b1.addActionListener(this);
		getContentPane().add(b1);
		setVisible(true);
	}
	public static void main(String args[])
	{
		new MyPractice1();
	}
	public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			new Database();
		}
	}
}

class Database extends JFrame
{
	JTable table;
    int i;
	String data[][];
	Database()
	{
		setSize(300,300);

		String heads[]={"ID","Name","Branch"};

		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con=DriverManager.getConnection("jdbc:odbc:mydatabase");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from mytable");
            i=0;
			while(rs.next())
			{
				i++;
			}
		}
		catch(Exception e)
		{
			System.out.println("Error :"+e);
		}
		data=new String[i][3];
		try
		{
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			Connection con=DriverManager.getConnection("jdbc:odbc:mydatabase");
			Statement st=con.createStatement();
			ResultSet rs=st.executeQuery("select * from mytable");
			int j=0;
			while(rs.next())
			{
				data[j][0]=rs.getString(1);
				data[j][1]=rs.getString(2);
				data[j][2]=rs.getString(3);
				j++;
			}
		}
		catch(Exception e)
		{
			System.out.println("Error :"+e);
		}
		table=new JTable(data,heads);
		JScrollPane jsp=new JScrollPane(table);
		getContentPane().add(jsp);
		setVisible(true);
	}
}






