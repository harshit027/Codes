import java.io.*;

class myinput1
{
        public static void main(String args[]) throws Exception
        {
                String str="";
                BufferedReader br=new BufferedReader(new InputStreamReader (System.in));
                System.out.println("\nEnter Any Number  :");
                str=br.readLine();
                int i= Integer.parseInt(str);
                System.out.println(i*2);
        }
}
