import java.awt.*;
import java.applet.*;
import java.awt.event.*;

public class MyMouserEvent extends Applet
		implements MouseListener
{
	Color myColor=Color.red;
	int i=1;
	int x=50, y=50;
	public void init()
	{
		addMouseListener(this);
	}
	public void paint(Graphics g)
	{
		setBackground(myColor);
		g.drawString("PACE BUREAU",x,y);
	}
	public void mouseClicked(MouseEvent me)
	{
		x=me.getX();
		y=me.getY();
		switch(i)
		{
			case 1:
				myColor=Color.green;break;
			case 2:
				myColor=Color.blue;break;
			case 3:
				myColor=Color.yellow;break;
			case 4:
				myColor=Color.cyan;break;
			case 5:
				myColor=Color.magenta;break;
			case 6:
				myColor=Color.orange;break;
			case 7:
				myColor=Color.pink;break;
		}
		i++;
		if(i>7)i=1;
		repaint();
	}
	public void mousePressed(MouseEvent me)
	{}
	public void mouseReleased(MouseEvent me)
	{}
	public void mouseEntered(MouseEvent me)
	{}
	public void mouseExited(MouseEvent me)
	{}
}
