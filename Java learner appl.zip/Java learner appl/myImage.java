import java.awt.*;
import java.applet.*;
/*
	<applet code="myImage.class" height=300 width=400>
	<param name="myimg" value="hlpcd.gif">
	<param name="myimg1" value="hlpglobe.gif">	
	</applet>
*/
public class myImage extends Applet
{
	String param1="";	
	String param2="";
	Image img,img1;
	public void init()
	{
		param1=getParameter("myimg");
		param2=getParameter("myimg1");
		img = getImage(getDocumentBase(),param1);	
		img1 = getImage(getDocumentBase(),param2);	
	}
	public void paint(Graphics g)
	{
		g.drawImage(img,50,50,this);
		g.drawImage(img1,250,250,this);
	}
}