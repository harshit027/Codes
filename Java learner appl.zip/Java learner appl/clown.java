import javabookEd3.*;
import java.awt.*;

// In this program we demonstrate the drawing methods of class Graphics.
// The Graphics object is created using a method of MainWindow. The drawings
// appear on the MainWindow object.


class Clown
{



	public static void main (String[] arg)
	{
		MainWindow mainWindow;
		InputBox inputBox;
        	Graphics graphics;
		int hour, minute;
		mainWindow = new MainWindow("clock window");
		mainWindow.setVisible(true);
		inputBox = new InputBox(mainWindow);
		inputBox.getInteger("Type any integer");
	 	graphics = mainWindow.getGraphics();


// Following instructions form a grid for reference.
// It could be useful while writing the program. Currently instructions
// are commented out. If you wish you can remove the comment symbol
// and run the program.

// Method drawLine(x1,y1,x2,y2) draws a line between points (x1,y1) and (x2,y2).

/*
		graphics.drawLine(0,100, 500,100);
		graphics.drawLine(0,200, 500,200);
		graphics.drawLine(0,300, 500,300);
		graphics.drawLine(0,400, 500,400);
		graphics.drawLine(0,500, 500,500);
		graphics.drawLine(0, 0, 0, 500);
		graphics.drawLine(100,0, 100,500);
		graphics.drawLine(200,0, 200,500);
		graphics.drawLine(300,0, 300,500);
		graphics.drawLine(400,0, 400,500);
		graphics.drawLine(500,0, 500,500);
*/


//face outline:

// Method drawArc(x,y,w,h,theta, delta) draws an elliptical arc. Consider the
//complete ellipse. The enclosing box for this complete ellips must have
//its top-left corner at (x,y), its width and height should be w and h. The
//above command will draw the section with angular span delta and its lower
//angle is theta (measured from positive x-axis in anti-clockwise manner.
// Method fillArc(x,y,w,h,theta, delta) draws the same arc but fills it with
//the current colour.

// Method setColor(a color object) sets the current colour. Color.yellow,
// Color.red,... are some readymade color objects which are created by the system
// automatically for you.


		graphics.setColor(Color.yellow);
		graphics.fillArc(100,100,400,300,0,360);

//eyes outline:

		graphics.setColor(Color.cyan);
		graphics.fillArc(200,175,50,75,0,360);
		graphics.fillArc(350,175,50,75,0,360);

//pupils:
		graphics.setColor(Color.black);
		graphics.fillArc(200,175,50,75,225,90);
		graphics.fillArc(350,175,50,75,225,90);


//nose:

//drawOval(x,y,w,h) is same as drawArc(x,y,w,h,0,360).
//fillOval(x,y,w,h) is same as fillArc(x,y,w,h,0,360).

		graphics.setColor(Color.red);
		graphics.fillOval(275,225,50,50);


//mouth:
		graphics.setColor(Color.blue);
		graphics.fillOval(285,300,30,60);


//ears:

/* Thus far we use some readymade color-objects (like black, white, blue, red,
yellow, gray,lightGray,darkGray,magenta,orange,cyan,pink).
 Next, we will create a colour object and pass it as a parameter
to the setColor method. These steps are combined, i.e., we are creating the object
inside the argument space. That way we do not have to save it in a Color type
variable. The 3 arguments used in the creation of the color
object are the redness, greenness, and blueness. Each ranges from 0 to 255.
*/

		graphics.setColor(new Color(0,255,150));
		graphics.fillOval(475,175,100,75);
		graphics.fillOval(25,175,100,75);

//brows:

		graphics.setColor(Color.black);
		graphics.drawLine(175,175,225,150);
		graphics.drawLine(275,175,225,150);
		graphics.drawLine(425,175,375,150);
		graphics.drawLine(325,175,375,150);

//cap:

		graphics.setColor(new Color(255,100,0));
		graphics.fillArc(-123,-273,450,450,277,40);



//caption:

/* Here we are setting the font by creating a font object and passing it to
the setFont method. The three arguments are font_name, font style, font_size.
*/


		graphics.setFont(new Font("SansSerif", Font.BOLD, 50));
		graphics.setColor(Color.black);
		graphics.drawString("SURPRISED?",150, 500);

	}
}

