import  java.awt.*;
import  java.awt.event.*;
import  java.applet.*;
/*<applet code="menudemo.class" width=400 height=500>
</applet>*/

class fm1 extends Frame
	{
	  fm1(String title)
                       {
	          super(title); 
                  setBackground(Color.blue);

                            MenuBar mbar= new MenuBar();
                  setMenuBar (mbar);
                               
	          Menu file = new  Menu("File");
                            MenuItem  item1,item2,item3;
                  Menu Security =new Menu("Security");
                            MenuItem ii1;
                  Menu Help = new Menu("Help");
                            MenuItem i11;

                  Menu sub =new Menu("Action");
                    MenuItem i1,i2,i3,i4,i5;

                   sub.add(i1= new MenuItem("Initiate"));
                   sub.add(i2= new MenuItem("Close_firewall"));
                   sub.add(i3= new MenuItem("Blockservices"));
                   sub.add(i4= new MenuItem("Allow Services"));
                   sub.add(i5= new MenuItem("Block Ping"));
                    file.add(sub);


                   file.add(item2=new MenuItem("-"));
                   file.add(item3 =new MenuItem("Quit.."));

                   Security.add(ii1= new MenuItem("Protection"));


                   Help.add(i11 = new MenuItem("help"));

   	             mbar.add(file);
                     mbar.add(Security);
                     mbar.add(Help);
                   }
     }

public class menudemo extends Applet
	{
                         Frame f;
                          
                public void init()
                    {
                         f = new fm1(" MENU DEMO");
		  
                         int width= Integer.parseInt(getParameter ("width"));
                         int height= Integer.parseInt(getParameter ("height"));

                         setSize( new Dimension(width,height));
                                         
                         f.setSize(width,height);
                         f.setVisible(true);
                    }

                 public void start()
                          {
                                f.setVisible(true);
                          }

                public void stop()
                         {
                              f.setVisible(false);
                         }
        }
                                         
