class RajThread1
{
	public static void main(String args[])
	{
		System.out.println("I am Main");
		MyFactorialThread t= new MyFactorialThread();
		try
		{
			System.out.println("I am Main before sleeping");
			Thread.sleep(5000);
			System.out.println("I am Main after sleeping");
			t.join();
		}
		catch(Exception e)
		{
			System.out.println("Error : "+e);
		}
		System.out.println("I am Main ending");
	}
}

class MyFactorialThread extends Thread
{
	MyFactorialThread()
	{
		start();
		System.out.println("I am Child Constructor");
	}
	public void run()
	{
		int n=5,i;
		for(i=1;n>1;n--)
		{
			i*=n;
		}
		System.out.println(i);
	}
}