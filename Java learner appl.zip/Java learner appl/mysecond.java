import java.io.*;
class mysecond
{
	public static void main(String args[]) throws Exception
	{
		InputStreamReader t=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(t);
		String str="";
		str=br.readLine();
		int n = Integer.parseInt(str);
		int m=0;
		for(m=n/2;m>1;m--)
		{
			if(n%m==0)
			{
				break;
			}
		}
		if(m==1)
		{
			System.out.println("Number : "+n+" is PRIME");
		}
		else
		{
			System.out.println("Number : "+n+" is NOT PRIME");
		}
	}
}