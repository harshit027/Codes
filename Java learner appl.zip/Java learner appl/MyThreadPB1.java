class Common
{
	private int n;
	int flag=0;
	synchronized public void put(int n)
	{
		if(flag==0)
		{
			this.n=n;
			flag=1;
			try
			{
				notify();
			}
			catch(Exception e){}
		}
		else
		{
			try
			{
				wait();
			}
			catch(Exception e){}
		}
	}
	synchronized public int get()
	{
		if(flag==1)
		{
			flag=0;
			try
			{
				notify();
			}
			catch(Exception e){}
		}
		else
		{
			try
			{
				wait();
			}
			catch(Exception e){}
		}
		return this.n;
	}
}
class ThreadPB1 extends Thread
{
	Common ref;
	ThreadPB1(Common ref)
	{
		this.ref = ref;
		start();
	}
	public void run()
	{
		java.util.Random rnd=new java.util.Random();
		while(true)
		{
			System.out.println("From Producer");
			//ref.put(41);
			int n=41;
			while(n>40)
			{
				int t=rnd.nextInt();
				if(t>100)
				{
					String str=(t+"").substring(0,2);
					n=Integer.parseInt(str);
				}
			}
			ref.put(n);
			try
			{
				sleep(500);
			}
			catch(Exception e)
			{}
		}
	}
}
class ThreadPB2 extends Thread
{
	Common ref;
	ThreadPB2(Common ref)
	{
		this.ref = ref;
		start();
	}
	public void run()
	{
		while(true)
		{
			System.out.println("From Consumer");
			int n=ref.get();
			System.out.println("");
			System.out.print(n+" : ");
			while(n>0)
			{
				System.out.print("�");
				n--;
				try
				{
					sleep(500);
				}
				catch(Exception e)
				{
				System.out.println("Error : "+e);
				}
			}
			try
			{sleep(500);}
			catch(Exception e)
			{System.out.println("Error : "+e);}
		}
	}
}

class MyThreadPB1
{
	public static void main(String args[])
	{
		Common obj=new Common();
		ThreadPB1 t1=new ThreadPB1(obj);
		ThreadPB2 t2=new ThreadPB2(obj);
		try
		{
			t1.join();
			t2.join();
		}
		catch(Exception e)
		{
			System.out.println("Error:"+e);
		}
	}
}