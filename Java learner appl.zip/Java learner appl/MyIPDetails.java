import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.*;

class MyIPDetails
{
	MyIPDetails()
	{
		//super("MyIP");
		//setSize(400,400);
		try
		{
			//InetAddress myip = InetAddress.getByName("www.pacejbp.com");
			InetAddress myip = InetAddress.getLocalHost();
			System.out.println(myip);
			byte b[]=myip.getAddress();
			System.out.println(b[0]+"\n"+b[1]+"\n"+b[2]+"\n"+b[3]);
			System.out.println(myip.getHostAddress());
		}
		catch(Exception e)
		{
			System.out.println("Error : "+e);
		}
	}
	public static void main(String args[])
	{
		new MyIPDetails();
	}
}
