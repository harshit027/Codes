class MyConstructor
{
	int i;
	public static void main(String args[]) throws Exception
	{
		myf();
		//finalize();
		Thread.sleep(10000);
		myf();
		//finalize();
	}
	static void myf()
	{
		MyConstructor m=new MyConstructor();
		System.out.println(m.i);

		MyConstructor m1=new MyConstructor(4);
		System.out.println(m1.i);
	}
	protected void finalize() throws Exception
	{
		System.out.println("Ihhhh!!! One Object Killed");
	}
	MyConstructor()
	{
		System.out.println("Hello I am from constructor");
		i=45;
	}
	MyConstructor(int t)
	{
		System.out.println("Hello I am from Parameterized constructor");
		i=t;
	}
}

