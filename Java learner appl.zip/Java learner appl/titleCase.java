import java.io.*;
class titleCase
{
	public static void main(String args[])
	{
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));

		String str="PACE BUREAU",str1="",str2="";
		try
		{
			str=br.readLine();
		}
		catch(Exception e){}
		char t,t1;
		for (int i=0;i<=str.length()-1;i++)
		{
			if(i==0 || str.charAt(i-1)==' ')
			{
				str1=str.substring(0,i);
				str2=str.substring(i+1);
				str=str.charAt(i)+"";
				str=str1+str.toUpperCase()+str2;
			}
		}
		System.out.println("titledCase String is : "+str);
	}
}