import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.io.*;
import javax.swing.event.*;

class Criteria_input extends JFrame implements ItemListener,ActionListener
{ 
 
Connection con;
Statement st;
ResultSet rs;
JTextField jt1;
TextArea jta1;
JButton jb1,jb2;
String str;
JComboBox jc2;
String id[];
String name[];
int x;
 public static void main(String args[])
 { 
  new Criteria_input();
}
   Criteria_input()
{
super("COMPANY_DETAILS");
  setSize(400,400);
  setVisible(true);
 
 
  WindowListener l = new WindowAdapter()
  {
   public void windowClosing(WindowEvent we)
   {
    System.exit(0);
   }
  };
 addWindowListener(l);

  name = new String[50];
  id =new String[50];
 GridBagLayout gb = new GridBagLayout();
 GridBagConstraints gbc = new GridBagConstraints();
 Container cp = getContentPane();
 JPanel jp = new JPanel();


 jp.setLayout(gb);
 jp.setBorder(BorderFactory.createCompoundBorder());
 gbc.gridwidth=1;
 gbc.gridheight=1;
 gbc.weightx=0.1;
 gbc.weighty=0.1; 

 JLabel jl1 = new JLabel("Company_id"); 
 JLabel jl2 = new JLabel("Company_name"); 
 JLabel jl3 = new JLabel("Criteria of Selection"); 
 jt1 = new JTextField(15) ;

 jc2 = new JComboBox() ;
 

 jta1 = new TextArea(3,15);
// jc1.addItem(str);
  jb1=new JButton("Submit");

  jb2=new JButton("Cancel");
 try
           {
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
             con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
             st   = con.createStatement();
            String qry11="select company_id,company_name";
            qry11+=" from company_details  ";
                  
             rs = st.executeQuery(qry11);
            
                 int i=0;        
            while(rs.next())
             
            {
             id[i]=rs.getString("company_id");
             name[i]=rs.getString("company_name"); 
             i++;
            }
             int j=0;  
             while(j<i)
              {
              jc2.addItem(name[j]);
                j++;
              } 
           }
             catch(Exception e)
            {
                    System.out.println("Error : "+e);
            }


 gbc.gridx =0;
 gbc.gridy =0;
 jp.add(jl1,gbc);


 gbc.gridx =2;
 gbc.gridy =0;
 jp.add(jt1,gbc);

   

 gbc.gridx =0;
 gbc.gridy =7;
 jp.add(jl2,gbc);

 gbc.gridx =2;
 gbc.gridy =7;
 jp.add(jc2,gbc);

 
 gbc.gridx =0;
 gbc.gridy =14;
 jp.add(jl3,gbc);

 gbc.gridx =2;
 gbc.gridy =14;
 jp.add(jta1,gbc);


 gbc.gridx =1;
 gbc.gridy =42;
 jp.add(jb1,gbc);

 gbc.gridx =2;
 gbc.gridy =42;
 jp.add(jb2,gbc);

 jc2.addItemListener(this);
 jb1.addActionListener(this);

 cp.add(jp);
 
 }
public void actionPerformed(ActionEvent ae)
{
       Object source=ae.getSource();
      try
      {
        if (source == jb1)
        {
	JOptionPane.showMessageDialog(this,"check1");
            Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
	JOptionPane.showMessageDialog(this,"check2");
            con = DriverManager.getConnection("jdbc:odbc:mydsn","scott" ,"tiger"); 
	JOptionPane.showMessageDialog(this,"check3");
            st   = con.createStatement();
	JOptionPane.showMessageDialog(this,"check4");
	String insertqry1="insert into criteria values ("+Integer.parseInt(jt1.getText())+",'"+jc2.getSelectedItem()+"','"+jta1.getText()+"')";
	JOptionPane.showMessageDialog(this,insertqry1);
            int t=st.executeUpdate(insertqry1);
          }
         }
        catch (Exception e)
        {
		System.out.println("Arre yanhan to error hai");
	}
}

public void itemStateChanged(ItemEvent ie)
{

 try
           {
            x=jc2.getSelectedIndex();
            jt1.setText(id[x]);

            }
              catch(Exception e)
            {
                    System.out.println("Error : "+e);
            }


}


}






