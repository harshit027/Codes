import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

public class selected_candidate_output extends JFrame
{  

           /*public  static void main(String args[])
              { 
                  new selected_candidate_output(); 
                }*/

        public selected_candidate_output()
           {
               super("Record Of Selected Students");
               setSize(640,800);
               setVisible(true);
 
        
                 WindowListener l = new WindowAdapter()
                 {
                    public void windowClosing(WindowEvent we)
                        {
                         System.exit(0);
                        }
                 };
                 addWindowListener(l);

                Container cp =getContentPane();
                GridBagLayout gb = new GridBagLayout();
GridBagConstraints gbc =new GridBagConstraints();

cp.setLayout(gb);
gbc.weightx=1;
gbc.weighty=1;
gbc.gridx=0;
gbc.gridy=0;

final String[] colHeads ={ "Name", "Roll_no" , "Date_Of_Birth" ,"Sex", "Branch" ,"Email id", "Company Name" };
final Object[][] data={
  {"Amrita ", "0201ca021020" , "07/07/1981" , "female" , "MCA" ,"amrita_koshta@yahoo.com" , "WIPRO"},
  {"Smita Rao" , "0201ca021028" , "01/06/1980" , "female" , "MCA" , "smitarao@rediffmail.com"," HUGHES"}

   };

 JTable table = new JTable (data,colHeads);
 int v= ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
 int h= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
 JScrollPane jsp= new JScrollPane(table,v,h);
 cp.add(jsp);

 JButton jb1=new JButton("OK");
  jb1.setToolTipText("view selected girls");
  cp.add(jb1);

 JButton jb2=new JButton("CANCEL");
  jb2.setToolTipText("view selected boys");
  cp.add(jb2);

   }
 }


