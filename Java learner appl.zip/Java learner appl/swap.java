import java.io.*;

class My
{
	int x,y;
}

class swap
{
        public static void main(String args[]) throws Exception
        {
                String str="";
                My t=new My();
                BufferedReader br=new BufferedReader(new InputStreamReader (System.in));
                System.out.println("\nEnter Any Number  :");
                str=br.readLine();
                t.x= Integer.parseInt(str);
                System.out.println("\nEnter Second Number  :");
                str=br.readLine();
                t.y= Integer.parseInt(str);
                System.out.println("\nNumber Before Swapping are : "+t.x+ ","+t.y);
				myf(t);
                System.out.println("\nNumber After Swapping are : "+t.x+","+t.y);
        }
        static void myf(My ref)
        {
			int t;
			t=ref.x;
			ref.x=ref.y;
			ref.y=t;
		}
}
