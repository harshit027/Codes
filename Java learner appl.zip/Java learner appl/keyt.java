import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*<applet code= "keyt" width= 200 height=200>
</applet>
*/
public class dd extends Dialog
{
    dd(p,"aaa")
    {
    showstatus("dddd");
    }
 }
 class myd exetnds Frame
 {
    myd()
    {
    }
 }


public class keyt extends Applet implements KeyListener
{
        String msg[]=new String[50];
        String st=" I am fool. ";
        int y=20,i=0;
        public void init()
        {
            addKeyListener(this);
            for(int i=0;i<=49;i++)
            {
                msg[i]="";
            }
            requestFocus();
        }
        public void keyPressed(KeyEvent ke)
        {
            int key=ke.getKeyCode();
            switch(key)
            {
                case  KeyEvent.VK_ENTER:
                        i++;
                        break;
           }
    }
    public void keyReleased(KeyEvent ke)
    {
    }
    public void keyTyped(KeyEvent ke)
    {
   //    if((ke.getKeyChar())!=(KeyEvent.VK_ENTER))
        msg[i]=msg[i]+st;
                repaint();
              if(i==49)
              {
              myd d= new myd();
              dd d2 = new dd(myd,"new Dilog box");
              d.setVisible(true);
              }

              

    }
    public void paint(Graphics g)
    {
        int t=y;
        for(int i=0;i<=49;i++)
        {
            g.drawString(msg[i],30,t);
            t+=20;
        }

     

    }
}
