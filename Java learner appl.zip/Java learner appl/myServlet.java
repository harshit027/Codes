import java.io.*;
import javax.servlet.*;

public class myServlet extends GenericServlet
{
	public void service(ServletRequest sr, ServletResponse srp) throws ServletException, IOException
	{
		srp.setContentType("text/html");
		BufferedReader br=sr.getReader();
		String nam="PACE",pwd="";
		nam+=br.readLine();
		PrintWriter p=srp.getWriter();
		p.println("<html>");
		p.println("<head><title>Hello From Servlet</title>");
		p.println("</head>");
		p.println("<body bgColor='Yellow'><h1 align='center'>PACE BUREAU</h1><hr><font color=blue size=6>This is from Servlet<br>"+nam+"</font>");
		p.println("</body>");
		p.println("</html>");
	}
}