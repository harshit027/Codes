import java.io.*;
public class mythread
{

    static int ps=200;
    static int cs=200;
    public static void main(String a[])
    {
        if(a.length>0 )
        ps=Integer.parseInt(a[0]);
        if(a.length>1)
        cs=Integer.parseInt(a[1]);
        Monitor m=new Monitor();
        new producer(m,ps);
        new consumer(m,cs);
        try
        {
        Thread.sleep(1000);
         }
         catch(InterruptedException e)
         {     }
         System.exit(0);

    }
}
class Monitor
{
PrintWriter out=new PrintWriter(System.out,true);
int token;
boolean vs=false;
synchronized int get()
    {
    if(!vs)
    try
    {
    wait();
    }
    catch(InterruptedException e)
    {}                     
    
    vs=false;
    out.println("got:"+token);
    notify();
    return token;
    }
    synchronized void set(int value)
        {
         if(vs)
         try
         {
         wait();
         }
      catch(InterruptedException e)
      {        }

      vs=true;
      token=value;
      out.println("set"+token);
      notify();
      }
   }
   class producer implements Runnable
     {
     Monitor m ;
     int speed;
     producer(Monitor m,int speed)
        {
        this.m=m;
        this.speed=speed;
        new Thread(this,"producer").start();
        }
     public void run()
        {
        int i=0;
        while(true)
        {
        m.set(i++);
        try{
        Thread.sleep((int) (Math.random()*speed));
        }
        catch(InterruptedException e)
        {}
        }
        }
        }
        class consumer implements Runnable 
         {
         Monitor m;
         int speed;
         consumer(Monitor m,int speed)
         {
         this.m=m;
         this.speed=speed;
         new Thread(this,"consumer").start();
         }
         public void run()
         {int i=0;
         while(true)
         {
         m.get();
         try{Thread.sleep((int)(Math.random()*speed));
         }
         catch(InterruptedException e)
         {}
         }
         }
         }
        

