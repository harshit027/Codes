import javax.swing.*;

class myProgressBar extends JFrame
{
        JProgressBar pb;
        public static void main(String argfdp[])
        {
                new myProgressBar();
        }
        myProgressBar()
        {
                pb=new JProgressBar();
                //pb.setString("PACE");
                pb.setStringPainted(true);
                getContentPane().add(pb,"South");
                setBounds(10,10,400,400);
                setTitle("My ProgressBar");
                setVisible(true);
	//create thread object to run progressbar
                new myPBThread(this);
        }
}

class myPBThread extends Thread
{
        myProgressBar ref;
        myPBThread(myProgressBar ref)
        {
                super("MyPBThread");
                this.ref=ref;
                start();
        }
        public void run()
        {
                boolean flag=false;
                while(true)
                {
                        int t=ref.pb.getValue();
                        if(flag==false)
                        {
                                t=t+5;
                                if(t>=100)
                                      flag=true;          
                        }
                        else
                        {
                                t=t-5;
                                if(t<=0)
                                        flag=false;
                        }
                        ref.pb.setValue(t);
                        try
                        {
                                sleep(200);
                        }
                        catch(Exception e){}
                }
        }
}
