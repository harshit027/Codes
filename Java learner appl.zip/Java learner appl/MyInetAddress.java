import java.net.*;
class MyInetAddress
{
	public static void main(String args[]) throws Exception
	{
		InetAddress ip=InetAddress.getByName("localhost");
		System.out.println("IP of Yahoo is :"+ip.getHostAddress());
	}
}