import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/*
	<applet code="MyApplet1" width=400 height=400>
	</applet>
*/
public class MyApplet1 extends Applet
{
	public void init()
	{
		setBackground(Color.orange);
	}
	public void paint(Graphics g)
	{
		Dimension d = getSize();
		g.drawString("PACE BUREAU",d.width/2-20,d.height/2);
	}
}