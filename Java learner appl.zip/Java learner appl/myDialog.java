import java.awt.*;
import java.awt.event.*;
import java.applet.*;
/*
	<applet code="myDialog.class" height=300 width=400>
	</applet>
*/
public class myDialog extends Applet implements ActionListener
{
	Button btn;
	public void init()
	{
		btn=new Button("Show Open Dialog");
		add(btn);
		btn.addActionListener(this);
	}
	public void actionPerformed(ActionEvent ae)
	{
		myd d=new myd();
		FileDialog d1=new FileDialog(d,"Ye Maine Banaya");
		d1.setVisible(true);
	}
}

class myd extends Frame
{
	myd()
	{
	}
}