import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class frame extends JFrame implements ActionListener
{
	//static JFrame f1;
	static JPanel p1;
	static JButton b1;
	static JTextPane t1;
	static BorderLayout bl1;
	static	DFont dd;
	public frame()
	{
	//	f1=new JFrame();
		//p1=new JPanel();
		getContentPane().setLayout(new BorderLayout());
		t1=new JTextPane();
		JScrollPane scrollPane = new JScrollPane( t1 );
    scrollPane.setPreferredSize( new Dimension( 200, 200 ) );

    getContentPane().add( scrollPane,BorderLayout.CENTER );
		b1=new JButton("Set Font");
		b1.setBackground(Color.blue);
		b1.setForeground(Color.cyan);
		b1.setFont(new Font("Arial",Font.BOLD,14));

		Font fn1=new Font("Symbol",Font.PLAIN,12);
		t1.setFont(fn1);
		getContentPane().add(b1,BorderLayout.SOUTH);
		//;
		//p1.setLayout(bl1);
		//p1.add("Center",t1);
	//	p1.add("South",b1);
		b1.addActionListener(this);
		setSize(400,400);
		setVisible(true);
	}
	public void actionPerformed(ActionEvent ae)
	{
		if (ae.getSource()==b1)
		{
		//b1.setBounds(100,290,100,20);dd.p1.add(b1);
		 dd=new DFont(t1,frame.this,"Font Dialog",true);



		}
	}
	public static void main(String ar[])
	{
		JFrame f12=new frame();
	}
}
