import java.awt.*;
import java.applet.*;

/*
	<applet code="rajApp.class" width=500 height=400>
	<param name="bcolor" value="pink">
	<param name="fcolor" value="blue">
	</applet>
*/
public class rajApp extends Applet
{
	String str="";
	Color c1,c2;
	public void init()
	{
		str="PACE";
	}
	public void start()
	{
		str="Rajneesh";
		str=getParameter("fcolor");
		if (str.equals("pink"))
		{
			c1=Color.pink;	
			str="hello";
		}
		str=getParameter("bcolor");
		if (str.equals("blue"))
			c2=Color.blue;
	}
	public void paint(Graphics g)
	{
		//setBackground(Color.yellow);
		//setForeground(Color.red);
		setBackground(c1);
		setForeground(c2);
		g.drawString(str,30,50);
	}
}