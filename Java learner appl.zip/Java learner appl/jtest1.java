import java.sql.*;
import java.io.*;
import javax.swing.event.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class jtest1 extends JFrame implements ActionListener,ItemListener 
{
        JButton b;
        JTextField t1,t2,t3,t4,t5,t6,t7,t8,t9,t10,t11;
        JRadioButton r1,r2,r3,r4,r5,r6,r7,r8,r10,r11,r12,btn;
        JLabel l1,l2,l3,l4,l5,l6,l7,l8,l9,l10,l11,l12,l13,l14,l15,l16,l17,l18;
        ButtonGroup group=new ButtonGroup();
        ButtonGroup group1=new ButtonGroup();
        ButtonGroup group2=new ButtonGroup();
        String st=" ";
        String st1=" ";
        String sc1=" ";
        String sti=" ";
        String sa=" ";
        //String uid=" ";
        jtest1()
        {
                Container contentpane=getContentPane();
                contentpane.setBackground(Color.pink);
                contentpane.setLayout(new GridLayout(25,0,2,10));
                Font f=new Font("Serif",1,14);
                contentpane.setFont(f);
                l1=new JLabel("    S.No.");
                l1.setFont(f);
                contentpane.add(l1);
                t11=new JTextField(2);
                contentpane.add(t11);

                //Font f=new Font("SansSerif",Font.BOLD,14);
                l2=new JLabel("    Enter UserID");
                l2.setFont(f);
                contentpane.add(l2);

                t1=new JTextField(20);
                contentpane.add(t1);

                l3=new JLabel("    Enter Title");
                l3.setFont(f);
                contentpane.add(l3);

                t2=new JTextField(20);
                contentpane.add(t2);

                l4=new JLabel("    Enter Author");
                l4.setFont(f);
                contentpane.add(l4);

                t3=new JTextField(20);
                contentpane.add(t3);

                l5=new JLabel("    Enter Background color");
                l5.setFont(f);
                contentpane.add(l5);

                t4=new JTextField(20);
                contentpane.add(t4);

                l6=new JLabel("    Enter Text color");
                l6.setFont(f);
                contentpane.add(l6);

                t5=new JTextField(20);
                contentpane.add(t5);

                l7=new JLabel("    Enter Link color");
                l7.setFont(f);
                contentpane.add(l7);

                t6=new JTextField(20);
                contentpane.add(t6);

                l8=new JLabel("    Enter Scoring method");
                l8.setFont(f);
                contentpane.add(l8);

                l9=new JLabel("");
                l9.setFont(f);
                contentpane.add(l9);

                JRadioButton r1=new JRadioButton("Self-Test");
                JRadioButton r2=new JRadioButton("Retry-Test");
                JRadioButton r3=new JRadioButton("Email-In-Test");
                JRadioButton r4=new JRadioButton("correct and Email-Test");

                r1.setBackground(Color.pink);
                r2.setBackground(Color.pink);
                r3.setBackground(Color.pink);
                r4.setBackground(Color.pink);


                group.add(r1);
                group.add(r2);
                group.add(r3);
                group.add(r4);
                group.add(null);

                contentpane.add(r1);
                contentpane.add(r2);
                contentpane.add(r3);
                contentpane.add(r4);
                                
                l10=new JLabel("    Enter Number of questions");
                l10.setFont(f);
                contentpane.add(l10);

                t7=new JTextField(20);
                contentpane.add(t7);
                System.out.println(st);

                l11=new JLabel("    Enter Question type");
                l11.setFont(f);
                contentpane.add(l11);

                l12=new JLabel(" ");
                l12.setFont(f);
                contentpane.add(l12);

                r5=new JRadioButton("Short answer");
                contentpane.add(r5);
                r6=new JRadioButton("True-False");
                contentpane.add(r6);
                r7=new JRadioButton("Multiple Choice");
                contentpane.add(r7);
                r8=new JRadioButton("Fill in the blanks");
                contentpane.add(r8);
                r10=new JRadioButton("Mixed type");
                contentpane.add(r10);
                l18=new JLabel("");
                contentpane.add(l18);

                r5.addItemListener(this);
                r6.addItemListener(this);
                r7.addItemListener(this);
                r8.addItemListener(this);
                r10.addItemListener(this);

                r5.setBackground(Color.pink);
                r6.setBackground(Color.pink);
                r7.setBackground(Color.pink);
                r8.setBackground(Color.pink);
                r10.setBackground(Color.pink);

                group1.add(r5);
                group1.add(r6);
                group1.add(r7);
                group1.add(r8);
                group1.add(r10);
                
                l13=new JLabel("    Email");
                l13.setFont(f);
                contentpane.add(l13);
                t8=new JTextField(30);
                contentpane.add(t8);

                l14=new JLabel("    Graphics Address");
                l14.setFont(f);
                contentpane.add(l14);
                t9=new JTextField(20);
                contentpane.add(t9);

                l15=new JLabel("    External Links");
                l15.setFont(f);
                contentpane.add(l15);
                t10=new JTextField(20);
                contentpane.add(t10);

                l16=new JLabel("    Display");
                l16.setFont(f);
                contentpane.add(l16);
                l17=new JLabel("");
                contentpane.add(l17);

                r11=new JRadioButton("As HTML Page");
                contentpane.add(r11);
                r12=new JRadioButton("As Plain Text");
                contentpane.add(r12);

                r11.setBackground(Color.pink);
                r12.setBackground(Color.pink);

                group2.add(r11);
                group2.add(r12);

                b=new JButton("CONTINUE");
                Color co=new Color(255,100,100);
                b.setBackground(co);
                               
                b.addActionListener(this);
                contentpane.add(b);
                setVisible(true);
                setSize(800,650);
        }
        public void itemStateChanged(ItemEvent ie)
        {
                btn=(JRadioButton)ie.getSource();
                sc1=btn.getText();
                st1=btn.getText();
                 
        }

         public void actionPerformed(ActionEvent ae)
         {
                String so=ae.getActionCommand();
                sti=t2.getText();
                sa=t3.getText();
                //uid=t1.getText();
                if(so.equals("CONTINUE"))
                {
                        st=t7.getText();
                        if(btn==r10)
                        {
                                myq1 q1=new myq1(st,st1,sti,sa);
                                q1.setVisible(true);
                                q1.setSize(800,650);
                        } 
                        else
                        {
                                myq q=new myq(st,st1,sti,sa);
                                q.setVisible(true);
                                q.setSize(800,650);
                        }
                }

          }
        public static void main(String args[])
        {
                new jtest1();
        }

 }

class myq extends JFrame implements ActionListener
{
          int t=0,count=0;
          JLabel l19,l20,l21,l22,l23,l29,lm,lu;
          JButton b1,b2;
          JTextField  t13,t14,t15,tm,tu;
          String sc=" ";
          String sc1=" ";
          String sti1=" ";
          String sa1=" ";
          String tuid=" ";
          myq(String st,String st1,String sti,String sa)
          {
          sti1=sti;
          sa1=sa;
          //uid1=uid;
          b1=new JButton("NEXT");
          b2=new JButton("CREATE");
          l19=new JLabel("Number of questions:");
          l23=new JLabel(" ");
          l21=new JLabel("Question:");
          l22=new JLabel("Answer:");
          lm=new JLabel("Marks:");
          lu=new JLabel("UserID:");
          tu=new JTextField("",10);
          System.out.println(st);
          l23.setText(st);
         
          t = Integer.parseInt(st);
          System.out.println(t);
          System.out.println(sc1);

          t14=new JTextField("",10);
          t15=new JTextField("",10);
          tm=new JTextField("",10);
          l20=new JLabel("Type of questions:");
          l29=new JLabel("");
          l29.setText(st1);
          Container c=getContentPane();
          c.setLayout(new GridLayout(12,2,0,0));
          c.setBackground(Color.pink);
          //c.setLayout(new FlowLayout());
          b1.addActionListener(this);
          b2.addActionListener(this);
          Color co=new Color(255,100,100);
          b1.setBackground(co);
          b2.setBackground(co);
          c.add(l19);
          c.add(l23);
          c.add(l20);
          c.add(l29);
          c.add(lu);
          c.add(tu);
          c.add(l21);
          c.add(t14);
          c.add(l22);
          c.add(t15);
          c.add(lm);
          c.add(tm);
          c.add(b1);
          c.add(b2);
          setVisible(true);
          }

         public void actionPerformed(ActionEvent ae)
         {
                Connection con;
                ResultSet rs;
                Statement st1;
                String s,s1;
                        
                JButton b=(JButton)ae.getSource();
                if (b==b1)
                {
                try
                {
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                con=DriverManager.getConnection("jdbc:odbc:ques_ans",null,null);
                st1=con.createStatement();
                s=t14.getText();
                s1=t15.getText();
                tuid=tu.getText();
                st1.executeUpdate("insert into ques_ans(QUESTION,WRONG_ANS)  values('"+s+"','"+s1+"')");
                 
                if(t!=1)
                {
                t14.setText("");
                t15.setText("");
                }
                t--;
                if(count==t)
               {
                        b1.setEnabled(false);
                        count=count+1;
                        t14.setText("");
                        t15.setText("");
                        t14.setEditable(false);
                        t15.setEditable(false);
                }
                 con.close();
             }

                catch(Exception e)
                {
                        System.out.println("Error hai bhai : "+e);
                }
              }
               else
               {
                  myc1 c1=new myc1(sti1,sa1,tuid);
                  c1.setVisible(true);
                  c1.setSize(800,650);
               }   

             }
         
                                            
}
class myq1 extends JFrame  implements ActionListener
{
          int t=0,count=0;      
          JLabel l24,l25,l26,l27,l28,l30,l31,lm1,lu;
          //JLabel lb1,lb2,lb3,lb4,lb5,lb6,lb7,lb8,lu;
          JButton b3,b4;
          JTextField  t17,t18,tm1,tt,tu,tq;
          String sti1=" ";
          String sa1=" ";
         // String uid1=" ";
          String tuid;
          myq1(String st,String st1,String sti,String sa)
          {
          sti1=sti;
          sa1=sa;
         // uid1=uid;
          b3=new JButton("NEXT");
          b4=new JButton("CREATE");
          l24=new JLabel("Number of questions:");
          l25=new JLabel("Question:");
          l26=new JLabel("Answer:");
          lm1=new JLabel("Marks:");
       
          System.out.println(st);
          l30=new JLabel(" ");
          l30.setText(st);
          t = Integer.parseInt(st);
          System.out.println(t);
          t17=new JTextField("",10);
          t18=new JTextField("",10);
          tt=new JTextField("",10);

          tm1=new JTextField("",10);
          l28=new JLabel("Question Type");
          //lb1=new JLabel("                                                            ");

          //lb2=new JLabel("                                                            ");
          //lb3=new JLabel("   ");
          //lb4=new JLabel("         ");
          //lb5=new JLabel("                                                            ");
          //lb6=new JLabel("                                                            ");
          //lb7=new JLabel("                                                            ");
          //lb8=new JLabel("                                                            ");
            l31=new JLabel(" ");
          l31.setText(st1);
          l27=new JLabel("Type of questions:");
          lu=new JLabel("UserID:");
          tu=new JTextField("",10);
          Container c=getContentPane();
          c.setLayout(new GridLayout(12,2,0,0));
          //c.setLayout(new FlowLayout());
          b3.addActionListener(this);
          b4.addActionListener(this);
          c.add(l24);
          c.add(l30);
          //c.add(lb1);
          //c.add(lb2);
          //c.add(lb3);
          c.add(l27);
          c.add(l31);
          //c.add(lb4);
          //c.add(lb5);
          //c.add(lb6);
          //c.add(lb7);
          //c.add(lb8);
          c.add(lu);
          c.add(tu);
          c.add(l28);
          c.add(tt);
          c.add(l25);
          c.add(t17);
          c.add(l26);
          c.add(t18);
          c.add(lm1);
          c.add(tm1);
          c.add(b3);
          c.add(b4);
          setVisible(true);
          }
         public void actionPerformed(ActionEvent ae)
         {
                Connection con;
                ResultSet rs;
                Statement st1;
                String s,s1;
                        
                JButton b=(JButton)ae.getSource();
                if (b==b3)
               {
                try
                {
                Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
                con=DriverManager.getConnection("jdbc:odbc:ques_ans",null,null);
                st1=con.createStatement();
                s=t17.getText();
                s1=t18.getText();
                tuid=tu.getText();
                st1.executeUpdate("insert into ques_ans(QUESTION,WRONG_ANS,UserID,Marks)  values('"+s+"','"+s1+"','"+tuid+"','"+tm1+"')");
                if(t!=1)
                {
                t17.setText("");
                t18.setText("");
                tt.setText("");
                tm1.setText("");
                }
                t--;
                if(count==t)
                {                
                 b3.setEnabled(false);
                 count=count+1;
                 t17.setText("");
                 t18.setText("");
                 tt.setText("");
                 tm1.setText("");

                 t17.setEditable(false);
                 t18.setEditable(false);
                 tt.setEditable(false);
                 tm1.setEditable(false);
                 }
                con.close(); 
             }
                catch(Exception e)
                {
                        System.out.println("Error hai bhai : "+e);
                }

             }
            else
            {

                  myc1 c1=new myc1(sti1,sa1,tuid);
                  c1.setVisible(true);
                  c1.setSize(800,650);
               } 
}
}
class myc1 extends JFrame implements ActionListener
{
   JLabel lc11,lc12,lc13,lc14,lq1,la1;
   JTextField tq1,ta1,tq;
   JButton bn,bn1;
   JRadioButton rb1,rb2;
   Connection con;
   ResultSet rs;
   Statement st1;
   int i=1;
   Container c=getContentPane();
   myc1(String sti,String sa,String uid)
   {
       tq=new JTextField("",10);
       lq1=new JLabel("Question:");
       la1=new JLabel("Answer:");
       //tq1=new JTextField(" ",10);
       ta1=new JTextField("",10);
       bn=new JButton("NEXT");
       bn1=new JButton("Score");
       Font f=new Font("Dialog",1,20);
       lc11=new JLabel("Title:");
       lc11.setFont(f);
       lc12=new JLabel(" ");
       lc12.setFont(f);
       lc13=new JLabel("Author:");
       lc13.setFont(f);
       lc14=new JLabel(" ");
       lc14.setFont(f);
       lc12.setText(sti);
       lc14.setText(sa);
      // Container c=getContentPane();
       c.setLayout(new GridLayout(25,2,0,0));
       c.setBackground(Color.pink);
       bn.addActionListener(this);
       bn1.addActionListener(this);
       c.add(lc11);
       c.add(lc12);
       c.add(lc13);
       c.add(lc14);
       c.add(lq1);
       c.add(tq);
       c.add(la1);
       c.add(ta1);
       c.add(bn);
       c.add(bn1);
    try
    {
    Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
    con=DriverManager.getConnection("jdbc:odbc:ques_ans","","");
    st1=con.createStatement();
    String myQry="select QUESTION,marks from ques_ans where UserID='"+uid+"'";
    rs=st1.executeQuery(myQry);
    System.out.println(myQry);
   
    //c.add(rb1);
    if(rs.next())
	{
        tq.setText(rs.getString("question"));
        System.out.println(rs.getString("question"));
        //System.out.println("i:i:"+i);
     }
     if(rs.next())
     {
     rb1=new JRadioButton("Q");
     c.add(rb1);
     i++;
     }
     System.out.println("i:i:"+i);
    }
	catch(Exception e)
	{
		System.out.println("Error hai bhai : "+e);
	}

    setVisible(true);
	}
    public void actionPerformed(ActionEvent ae)
    { int j=1;
     rb1=new JRadioButton("QUES:1");
    c.add(rb1);
    JButton bt=(JButton)ae.getSource();
    if(bt==bn)
    {
    try
    {
    if(rs.next())
    {
    // rb1=new JRadioButton("QUES:1");
   // c.add(rb1);
    i++;
    tq.setText(rs.getString("question"));
    ta1.setText("");
    }
    System.out.println("i="+i);
    }

    catch(Exception e)
    {
    }
    /*for(j=1;j<=i;j++)
    {
     rb1=new JRadioButton("QUES:1");
    c.add(rb1);
    } */
  }
}
}
