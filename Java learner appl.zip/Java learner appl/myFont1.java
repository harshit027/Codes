import java.applet.*;
import java.awt.*;
/*
        <applet code="myFont1.class" width=500 height=400>
	</applet>
*/

public class myFont1 extends Applet
{	
       	public void paint(Graphics g)
        {
         setBackground(Color.yellow);

         setForeground(Color.red);
         GraphicsEnvironment ge=GraphicsEnvironment.getLocalGraphicsEnvironment();
         String s[]=ge.getAvailableFontFamilyNames();
         int k=0;
         int j=40;
         int i=10;
           while(true)
         {
               if(k<11)
                    {
                             g.drawString(s[k],i,j);
                             if(k==10)
                             {
                                j=40;
                                i=150;
                             }
                     }
               else
                  {
                     if (k<21)
                     {
                       g.drawString(s[k],i,j);
                             if(k==20)
                             {
                               j=40;
                               i=290;
                             }

                     }   
                    else
                       {
                       g.drawString(s[k],i,j);
                       
                       }
                   }
                         k++;
                         j=j+10;
            }
          }
}




