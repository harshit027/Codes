import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

class myd extends JFrame 
{
        
    JOptionPane j;
	public static void main(String sdfs[])
	{
                new JOptionPane();
	}
      new JOptionPane()

	{
         j=new JOptionPane();
         j.ERROR_MESSAGE():
        setVisible(true);
        }
}
