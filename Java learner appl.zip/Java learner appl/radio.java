import java.awt.*;
import java.applet.*;
import java.awt.event.*;
/* <applet code ="radio.class " width=250 height=250>
</applet>
*/
public class radio extends Applet implements ItemListener
{
String m,m1 ="";
Checkbox w98,nt,sol,mac;
CheckboxGroup cbg,cbg2;
public void init()
{
cbg=new CheckboxGroup();
w98=new Checkbox("windows 98",cbg,true);
nt=new Checkbox("windows NT",cbg,false);
sol=new Checkbox("solaris",cbg,false);
mac=new Checkbox("MACOS",cbg,false);

add(w98);
add(nt);
add(sol);
add(mac);
w98.addItemListener(this);
nt.addItemListener(this);
sol.addItemListener(this);
mac.addItemListener(this);
cbg2=new CheckboxGroup();
w98=new Checkbox("windows 98",cbg2,true);
nt=new Checkbox("windows NT",cbg2,false);
sol=new Checkbox("solaris",cbg2,false);
mac=new Checkbox("MACOS",cbg2,false);

add(w98);
add(nt);
add(sol);
add(mac);
w98.addItemListener(this);
nt.addItemListener(this);
sol.addItemListener(this);
mac.addItemListener(this);

}
public void itemStateChanged(ItemEvent ie)
{
repaint();
}
public void paint(Graphics g)
{
m="current selection:";
m+=cbg.getSelectedCheckbox().getLabel();
g.drawString(m,6,100);
m1="current selection";
m1+=cbg2.getSelectedCheckbox().getLabel();
g.drawString(m1,15,120);
}
}


