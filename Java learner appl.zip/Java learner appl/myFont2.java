import java.applet.*;                    
import java.awt.*;
/*
        <applet code="myFont2.class" width=300 height=400>
	</applet>
*/

public class myFont2 extends Applet
{
        int i=30;
        int j=40;
        int k=0;
	Font f=new Font("Arial",Font.BOLD|Font.ITALIC,50);
//	Font f=new Font("Arial",Font.BOLD,20);
	public void paint(Graphics g)
        {
         for(k=1;k<3;k++)
          {
                  System.out.print(k);
                  if(k==1)
                  {
                       g.setColor(Color.red);
                       //setForeground(Color.red);
                  }
                  else
                  {              
                       g.setColor(Color.red);
                       //setForeground(Color.pink);
                  } 
                //setForeground(Color.red);  
                setBackground(Color.yellow);

		g.setFont(f);
                g.drawString("PACE  BUREAU",i,j);
                i=i+20;j+=5;
                                                  
           }
           System.out.println(" ");
	}
}
