<?php
$username=$_POST["username"];
$password=$_POST["password"];
if($username=="admin" && $password=="acc")
{
Response.Redirect("accHome.htm");
}
else
if
?>