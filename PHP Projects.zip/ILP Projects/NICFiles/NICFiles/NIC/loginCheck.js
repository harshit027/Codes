function verifyUser()
{

var username=document.getElementById("txtUsername");

var password=document.getElementById("txtPassword");

var message=document.getElementById("errorMessage");
if(username.value=='')
{
   alert("Username not filled");
}
else
if(password.value=='')
{ 
   alert("Password not filled");
}
else
if(username.value=="admin" && password.value=='pc')
{
   window.location.assign("pcHome.htm");
}
else
if(username.value=="admin" && password.value=='acc')
{
   window.location.assign("accHome.htm");
}
else
message.innerHTML="Invalid Username/Password";
}



