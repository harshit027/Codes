function changeColor(arg)
{
arg.style.backgroundColor='#ffffff';
arg.style.color='#008888';
}

function restoreColor(arg)
{
arg.style.backgroundColor='#008888';
arg.style.color='#ffffff';
}



