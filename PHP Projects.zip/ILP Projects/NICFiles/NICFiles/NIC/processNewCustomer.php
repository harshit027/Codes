<?php
$name=$_POST["customerName"];
$age=$_POST["customerAge"];
$gender=$_POST["customerGender"];
$policy=$_POST["customerPolicy"];
$duration=$_POST["customerDuration"];
$nominee=$_POST["customerNominee"];
$address=$_POST["customerAddress"];

print("Customer Details :"."<br/>");
print("Name : ".$name."<br/>");
print("Age : ".$age."<br/>");
print("Gender : ".$gender."<br/>");
print("Policy : ".$policy."<br/>");
print("Duration : ".$duration."<br/>");
print("Nominee : ".$nominee."<br/>");
print("Address : ".$address."<br/>");
?>