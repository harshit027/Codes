
void main()
{
int r;float a;
clrscr();
printf("\nenter the radius : ");
scanf("%d",&r);
a=  (3.14*r*r);
printf("\narea of circle : %d ",a);
getch();
}


