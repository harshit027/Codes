﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("PACE BUREAU");
        Response.Clear();
        Response.Write("<h1>RAJNEESH</h1>");
        string str = "<h1>PACE BUREAU</h1>";
        str = Server.HtmlEncode(str);
        Response.Write(str);
        str = Server.HtmlDecode(str);
        Response.Write(str);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int n = 0;
        if (Application.Count > 0)
        {
            n = int.Parse(Application["ctr"].ToString());
            Application.RemoveAll();
        }
        n++;
        Application.Add("ctr", n + "");
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Write(Application["ctr"].ToString());
    }
}