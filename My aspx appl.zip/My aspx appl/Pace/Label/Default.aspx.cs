﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    //common event handler function (method) for buttons
    protected void mytest(object sender, EventArgs e)
    {
        if (sender is Button)
        {
            Button btn = (Button)sender;
            if (btn.CommandArgument == "1")
            {
                if (btn.CommandName == "a")
                {

                }
            }
            else if (btn.CommandArgument == "2")
            {
                if (btn.CommandName == "a")
                {

                }
            }
        }
        else if (sender is LinkButton)
        {
            //Literal1.Text = "I have been shown by clicking link button";
            Response.Redirect("test.htm");
        }
        else if (sender is ImageButton)
        {
            Literal1.Text = "I have been shown by clicking Image button";
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {

    }
    protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
    {

    }
}
