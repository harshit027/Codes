﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void RadioButton1_CheckedChanged(object sender, EventArgs e)
    {
        Label1.BackColor = System.Drawing.Color.Red;
    }
    protected void RadioButton2_CheckedChanged(object sender, EventArgs e)
    {
        Label1.BackColor = System.Drawing.Color.Green;
    }
    protected void RadioButton3_CheckedChanged(object sender, EventArgs e)
    {
        Label1.BackColor = System.Drawing.Color.Blue;
    }
    protected void RadioButton4_CheckedChanged(object sender, EventArgs e)
    {
        Label1.ForeColor = System.Drawing.Color.Red;
    }
    protected void RadioButton5_CheckedChanged(object sender, EventArgs e)
    {
        Label1.ForeColor = System.Drawing.Color.Green;
    }
    protected void RadioButton6_CheckedChanged(object sender, EventArgs e)
    {
        Label1.ForeColor = System.Drawing.Color.Blue;
    }
    protected void RadioButton7_CheckedChanged(object sender, EventArgs e)
    {
        Label1.Font.Size = FontUnit.Parse("10");
    }
    protected void RadioButton8_CheckedChanged(object sender, EventArgs e)
    {
        Label1.Font.Size = FontUnit.Parse("15");
    }
    protected void RadioButton9_CheckedChanged(object sender, EventArgs e)
    {
        Label1.Font.Size = FontUnit.Parse("20");
    }
}
