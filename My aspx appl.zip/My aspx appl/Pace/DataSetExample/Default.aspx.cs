﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void showdata(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        if (btn.Text == "Show")
        {
            string qry = "select department.deptno, dname, ename from department, employee  where department.deptno<5";
            SqlDataSource1.SelectCommand = qry;
            DataView dv = (DataView)SqlDataSource1.Select(DataSourceSelectArguments.Empty);
            Session.Add("dv", dv);
            Session.Add("currentrecord", "1");
            ShowRecord(1);
        }
        else if (btn.Text == "First")
        {
            Session.Remove("currentrecord");
            Session.Add("currentrecord", "1");
            ShowRecord(1);
        }
        else if (btn.Text == "Previous")
        {
            int currentRecord = int.Parse(Session["currentrecord"].ToString());
            currentRecord--;
            if (currentRecord == 0) currentRecord = 1;
            Session.Remove("currentrecord");
            Session.Add("currentrecord", currentRecord+"");
            ShowRecord(currentRecord);
        }
        else if (btn.Text == "Next")
        {
            int currentRecord = int.Parse(Session["currentrecord"].ToString());
            currentRecord++;
            DataView dv = (DataView)Session["dv"];
            if (currentRecord == dv.Count+1) currentRecord = dv.Count;
            Session.Remove("currentrecord");
            Session.Add("currentrecord", currentRecord + "");
            ShowRecord(currentRecord);
        }
        else if (btn.Text == "Last")
        {
            DataView dv = (DataView)Session["dv"];
            int currentRecord = dv.Count ;
            Session.Remove("currentrecord");
            Session.Add("currentrecord", currentRecord + "");
            ShowRecord(currentRecord);
        }
    }
    private void ShowRecord(int recno)
    {
        DataView dv = (DataView)Session["dv"];
        TextBox1.Text = dv[recno - 1][0].ToString();
        TextBox2.Text = dv[recno - 1][1].ToString();
        TextBox3.Text = dv[recno - 1][2].ToString();
    }
}
