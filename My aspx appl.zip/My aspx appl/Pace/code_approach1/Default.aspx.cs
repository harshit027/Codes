﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnReset_Click(object sender, EventArgs e)
    {
        txtBookTitle.Text = "";
        txtBookAuthor.Text = "";
        txtBookPrice.Text = "";
        txtBookEdition.Text = "";
        txtBookPublisher.Text = "";
        txtNumberOfBooks.Text = "";
    }
    protected void btnSave_Click(object sender, EventArgs e)
    {
        lblMessage.Visible = false;
         SqlConnection con =null;
        try
        {
            //connection string to specify parameters to make a connection with the database
            String constr = @"Data Source=.\SQLExpress;AttachdbFileName=|DataDirectory|library.mdf; Integrated Security=true; User Instance=true;";
            //create a connection object and specify connection string to it, which will be used by it to open connection
            con = new SqlConnection(constr);
            //open connection
            con.Open();
            //create command object so that queries can be transferred to database
            SqlCommand com = new SqlCommand();
            //command object requires following 3 things
            //1. Connection (it should be properly opened)
            //2. Command Type (optional)
            //3. Command Text (query to be executed against database to retrieve data)
            com.Connection = con;
            //command types are 3
            //1. Text - (query)
            //2. Table Direct  (Name of table - it will be used as select * from <Tablename>")
            //3. Stored Procedure (Name of the stored procedure)
            com.CommandType = CommandType.Text;
            //prepare a query to be fired
            string qry = "insert into books (booktitle, bookauthor, bookprice, bookedition, bookpublisher, numberofbooks) values ('" + txtBookTitle.Text + "','" + txtBookAuthor.Text + "'," + txtBookPrice.Text + ",'" + txtBookEdition.Text + "','" + txtBookPublisher.Text + "'," + txtNumberOfBooks.Text + ")";
            com.CommandText = qry;
            //execute query so that required processing will be done
            //it can be given in two ways
            //ExecuteNonQuery() - for sending data from asp.net to database
            //ExecuteReader() / ExecuteScalar() - for retrieving data from database
            int n = com.ExecuteNonQuery();
            //ExecuteNonQuery() - will return an integer which is number of rows affected in database
            if (n >= 0)
            {
                lblMessage.Text = "<span style='color:green'>Book Added Successfully</span>";
            }
            else
            {
                lblMessage.Text = "<span style='color:red'>Unable to add book, Please check the data entered</span>";
            }
            lblMessage.Visible = true;
        }
        catch (Exception ex)
        {
            lblMessage.Text = "<span style='color:red'>Error :" + ex.ToString() + "</span>";
            lblMessage.Visible = true;
        }
        finally
        {
            if (con.State == ConnectionState.Open) 
                con.Close();
        }
    }
}
