﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //if (Page.IsPostBack == false)
        if (!Page.IsPostBack )
        {
            DateTime dt = DateTime.Today;
            Calendar1.SelectedDate = dt;
        }

    }
    protected void Calendar1_SelectionChanged(object sender, EventArgs e)
    {

    }
    protected void ShowSelectedDate(object sender, EventArgs e)
    {
        Label1.Text = Calendar1.SelectedDate.ToString();
        int dd = Calendar1.SelectedDate.Day;
        int mm = Calendar1.SelectedDate.Month;
        int yy = Calendar1.SelectedDate.Year;
        string mon = Calendar1.SelectedDate.ToLongDateString();
        Label1.Text += "<br>Date :" + dd;
        Label1.Text += "<br>Month : " + mm;
        Label1.Text += "<br>Year :" + yy;
        Label1.Text += "<br>Long Date :" + mon;
    }
    protected void ShowDifference(object sender, EventArgs e)
    {
        int dd = int.Parse(ddlDay.SelectedItem.Text);
        int mm = int.Parse(ddlMonth.SelectedValue);
        int year = int.Parse(ddlYear.SelectedValue);
        DateTime dt1 = new DateTime(year, mm, dd);
        TimeSpan ts =  Calendar1.SelectedDate - dt1;
        Label1.Text += "Difference is :"+ts.Days;
    }
}
