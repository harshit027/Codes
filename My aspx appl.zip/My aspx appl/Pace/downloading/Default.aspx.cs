﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Directory d = Directory.GetDirectories(Request.PhysicalApplicationPath("~") + "/uploads");
        string [] f = Directory.GetFiles(Request.PhysicalApplicationPath 
                                                                + "/uploads");
        foreach (string s in f)
        {
            if (!s.ToUpper().EndsWith("BMP"))
            {
                string[] arr = s.Split("/\\".ToCharArray());
                string fn = arr[arr.Length - 1];
                lit1.Text += "<a href=\"uploads/" + fn + "\">" + fn + "</a><br>";
            }
        }
    }
}
