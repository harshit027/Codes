﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            if (FileUpload1.HasFile)
            {
                string s = "<br>File Information ...";
                s += "<br>File Name :" + FileUpload1.FileName;
                s += "<br>File Size :" + FileUpload1.FileBytes.Length;
                char[] s1 = { '.' };
                //char[] s2 = ".".ToCharArray();

                string[] arr = FileUpload1.FileName.Split(s1);
                string type = arr[arr.Length - 1];
                string dtype = "";
                if (type.ToLower() == "bmp")
                {
                    dtype = "Bitmap";
                }
                else if (type.ToLower() == "jpg" || type.ToLower() == "jpeg")
                {
                    dtype = "JPEG Image";
                }
                else if (type.ToLower() == "gif")
                {
                    dtype = "GIF Image";
                }
                else if (type.ToLower() == "pdf")
                {
                    dtype = "Portable Document Format";
                }

                s += "<br>File Type :" + dtype;
                Literal1.Text = s;

                string dfilename = Request.PhysicalApplicationPath + "/uploads/" + FileUpload1.FileName;
                FileUpload1.SaveAs(dfilename);
            }
            else
            {
                Literal1.Text = "<span style='background-color:red; color:white; font-size:16pt;'>Invalid File</span>";
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error :" + ex.ToString());
        }
    }
}
