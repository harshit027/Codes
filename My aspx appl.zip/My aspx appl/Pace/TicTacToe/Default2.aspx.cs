﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Drawing;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Button1.BackColor = Color.Red;
        string t = Label1.Font.Name;
        Label1.Font.Name = "Tahoma";
        Label1.Font.Bold = true;
        Label1.Font.Size = FontUnit.Parse("40");
    }
    protected void MyFunction(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        if (btn.Text == "")
        {
            btn.Text = Literal1.Text;
            if (Literal1.Text == "X")
            {
                Literal1.Text = "O";
            }
            else
            {
                Literal1.Text = "X";
            }
        }
    }
}
