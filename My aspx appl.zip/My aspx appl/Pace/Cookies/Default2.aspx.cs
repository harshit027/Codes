﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void RetrieveCookie(object sender, EventArgs e)
    {
        try
        {
            HttpCookieCollection hcc = Request.Cookies;
            for (int i = 0; i <= hcc.Count - 1; i++)
            {
                HttpCookie hc = hcc[i];
                if (hc.Name == "ck1")
                {
                    Response.Write("Cookie ck1 has " + hc.Value);
                    btn1.BackColor = System.Drawing.Color.FromName("rajneesh");
                    break;
                }
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error :" + ex.ToString());
        }
    }
}
