﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void StoreCookie(object sender, EventArgs e)
    {
        try
        {
            //HttpCookie hc1 = new HttpCookie("ck1", tb1.Text);
            //hc1.Expires = new DateTime(2010, 4, 1);
            //Response.SetCookie(hc1);
            HttpCookie hc2 = new HttpCookie("ck2", "RAJNEESH AGRAWAL");
            hc2.Expires = DateTime.Now.AddSeconds(30);
            Response.SetCookie(hc2);
        }
        catch (Exception ex)
        {
            Response.Write("Error :" + ex.ToString());
        }
    }
}
