﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString.Count > 0)
        {
            if (Request.QueryString["action"] == "logout")
            {
                Response.Write("Logged Out Successfully");
                
            }
        }
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (TextBox1.Text == "harshit" && TextBox2.Text == "tiwari")
        {
            
            Session.Add("authentication", "validuser");
            Response.Redirect("DataPage.aspx");
        }

        else
        {
            Literal1.Text = "<h4 style='background-color:Red; color:Yellow;'>Invalid Username/Password</h4>";
            Literal1.Visible = true;
        }

    }
}
