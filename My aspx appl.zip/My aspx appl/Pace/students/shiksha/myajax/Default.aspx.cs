﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.IO;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    

    protected void Button1_Click(object sender, EventArgs e)
    {
        Panel1.Visible = true;
        Panel2.Visible = false;
        try
        {
            FileStream fs = File.Open(Server.MapPath("~") + "./TextFile1.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            AddHeaderRow(new string[] { "SNO","Doc's ID", "Doc's Name", "Degree", "Specialization" });
            while (true)
            {
                string str = sr.ReadLine();
                if (str == null) break;
                string[] arr = str.Split("$".ToCharArray());
                AddRow(arr);
              
            }
            fs.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }
    }
    private void AddRow(string[] arr)
    {
        TableRow tr = new TableRow();
        TableCell tc1 = new TableCell();
        TableCell tc2 = new TableCell();
        TableCell tc3 = new TableCell();
        TableCell tc4 = new TableCell();
        TableCell tc5 = new TableCell();
        tc1.Text = arr[0];
        tc2.Text = arr[1];
        tc3.Text = arr[2];
        tc4.Text = arr[3];
        tc5.Text = arr[4];
        tr.Cells.Add(tc1);
        tr.Cells.Add(tc2);
        tr.Cells.Add(tc3);
        tr.Cells.Add(tc4);
        tr.Cells.Add(tc5);
        Table1.Rows.Add(tr);
    }
    private void AddHeaderRow(string[] arr)
    {
        Table1.Attributes.Add("style", "border:solid 2px #ff0000");
        TableRow tr = new TableRow();
        TableCell tc1 = new TableCell();
        TableCell tc2 = new TableCell();
        TableCell tc3 = new TableCell();
        TableCell tc4 = new TableCell();
        TableCell tc5 = new TableCell();
        tr.Attributes.Add("style", "color:Black; font-size:16pt; background-color:yellow");
        tc1.Text = arr[0];
        tc2.Text = arr[1];
        tc3.Text = arr[2];
        tc4.Text = arr[3];
        tc5.Text = arr[4];
        tr.Cells.Add(tc1);
        tr.Cells.Add(tc2);
        tr.Cells.Add(tc3);
        tr.Cells.Add(tc4);
        tr.Cells.Add(tc5);
        Table1.Rows.Add(tr);
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Panel2.Visible=true;
        Panel1.Visible = false;
        
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        try
        {
            int n = getNextSNO();
            FileStream fs = File.Open(Server.MapPath("~") + "/TextFile1.txt", FileMode.Append);
            StreamWriter sw = new StreamWriter(fs);
            string str = n + "$" + TextBox1.Text + "$" + TextBox2.Text + "$" + TextBox3.Text + "$" + TextBox4.Text;
            sw.WriteLine(str);
            sw.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }
    }
    private int getNextSNO()
    {
        int n = 0;
        try
        {
            FileStream fs = File.Open(Server.MapPath("~") + "/TextFile1.txt", FileMode.Open);
            StreamReader sr = new StreamReader(fs);
            while (true)
            {
                string str = sr.ReadLine();
                if (str == null) break;
                string[] arr = str.Split("$".ToCharArray());
                n = int.Parse(arr[0]);
            }
            fs.Close();
        }
        catch (Exception ex)
        {
            Response.Write(ex.ToString());
        }
        return n + 1;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default2.aspx");
    }
}
