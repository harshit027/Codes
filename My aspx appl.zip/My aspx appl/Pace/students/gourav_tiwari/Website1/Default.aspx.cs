﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Page.IsPostBack != true)
        {
            ShowMap();
        }
    }
    void ShowMap()
    {
        switch (DropDownList1.SelectedIndex)
        {
            case 0:
                {
                    DropDownList2.Items.Clear();
                    string[] arr = { "Madhya Pradesh", "Uttar Pradesh", "West Bengal", "Orissa", "Andhra Pradesh", "Tamilnadu" };
                    for (int i = 0; i < arr.Length; i++)
                    {
                        DropDownList2.Items.Add(arr[i]);
                    }
                    Image1.ImageUrl = "india.gif";
                    break;
                }
            case 1:
                {
                    DropDownList2.Items.Clear();
                    string[] arr = { "North", "Eastern", "Western", "Central", "North Central", "North Western" };
                    for (int i = 0; i < arr.Length; i++)
                    {
                        DropDownList2.Items.Add(arr[i]);
                    }
                    Image1.ImageUrl = "srilanka.gif";
                    break;
                }
            case 2:
                {
                    DropDownList2.Items.Clear();
                    string[] arr = { "Punjab", "Lahore", "Peshawar", "Islamabad", "Karachi", "Baluchistan" };
                    for (int i = 0; i < arr.Length; i++)
                    {
                        DropDownList2.Items.Add(arr[i]);
                    }
                    Image1.ImageUrl = "pakistan.gif";
                    break;
                }
            case 3:
                {
                    DropDownList2.Items.Clear();
                    string[] arr = { "Melbourne", "Perth", "Darwin", "Brisbane", "Sydney", "Canbera" };
                    for (int i = 0; i < arr.Length; i++)
                    {
                        DropDownList2.Items.Add(arr[i]);
                    }
                    Image1.ImageUrl = "australia.gif";
                    break;
                }
            case 4:
                {
                    DropDownList2.Items.Clear();
                    string[] arr = { "Kurao", "Marton", "Alexandra", "Cape Town", "Orawia", "Kingston" };
                    for (int i = 0; i < arr.Length; i++)
                    {
                        DropDownList2.Items.Add(arr[i]);
                    }
                    Image1.ImageUrl = "new.gif";
                    break;
                }
            case 5:
                {
                    DropDownList2.Items.Clear();
                    string[] arr = { "Beijing", "Hunan", "Shaanxt", "Xizang", "Shahghai", "Fujian" };
                    for (int i = 0; i < arr.Length; i++)
                    {
                        DropDownList2.Items.Add(arr[i]);
                    }
                    Image1.ImageUrl = "china.gif";
                    break;
                }
            case 6:
                {
                    DropDownList2.Items.Clear();
                    string[] arr = { "Gasa", "Paro", "Mongar", "Bumthang", "Sarpang", "Dagana" };
                    for (int i = 0; i < arr.Length; i++)
                    {
                        DropDownList2.Items.Add(arr[i]);
                    }
                    Image1.ImageUrl = "bhutan.gif";
                    break;
                }
        }

    }
    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        ShowMap();
    }
}
