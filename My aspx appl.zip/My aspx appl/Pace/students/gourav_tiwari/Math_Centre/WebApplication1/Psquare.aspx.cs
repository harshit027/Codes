﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Psquare : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Main.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int n;
            n = int.Parse(TextBox1.Text);
            for (int i = 1; i <= n / 2; i++)
            {
                int c = i * i;
                if (c == n)
                {
                    TextBox2.Text = "Number is Perfect Square of " + i.ToString();
                    break;
                }
                else
                    TextBox2.Text = "Number is not a Perfect Square";
            }
            if (n == 1)
                TextBox2.Text = "Number is Perfect Square of 1";

         }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
        }
    }
}
