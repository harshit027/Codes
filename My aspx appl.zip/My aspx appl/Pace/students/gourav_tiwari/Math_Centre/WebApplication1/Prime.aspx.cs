﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Prime : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LinkButton2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Main.aspx");
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            Response.Redirect("Default.aspx");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int n;
            n = int.Parse(TextBox1.Text);
                       
            for (int i = 2; i <= n/2; i++)
            {
                int c = n%i;
                if (c == 0)
                {
                    TextBox2.Text = "Not a Prime Number";
                    break;
                }
                else
                    TextBox2.Text = "Prime Number";

            }
            if (n == 2 || n == 3)
                TextBox2.Text = "Prime Number";
            if (n == 1)
                TextBox2.Text = " 1 is neither prime nor composite";

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
        }
    }
}
