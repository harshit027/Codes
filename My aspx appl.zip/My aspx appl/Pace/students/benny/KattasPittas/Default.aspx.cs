﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Button1.Text == "")
        {
            Button1.Text = Label1.Text;
            if (Label1.Text == "X")
            {
                Label1.Text = "O";
            }
            else
            {
                Label1.Text = "X";
            }
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        if (Button2.Text == "")
        {
            Button2.Text = Label1.Text;
            if (Label1.Text== "X")
            {
                Label1.Text= "O";
            }
            else
            {
                Label1.Text= "X";
            }
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        if (Button3.Text == "")
        {
            Button3.Text = Label1.Text;
            if (Label1.Text== "X")
            {
                Label1.Text= "O";
            }
            else
            {
                Label1.Text= "X";
            }
        }
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        if (Button4.Text == "")
        {
            Button4.Text = Label1.Text;
            if (Label1.Text== "X")
            {
                Label1.Text= "O";
            }
            else
            {
                Label1.Text= "X";
            }
        }
    }
    protected void Button5_Click(object sender, EventArgs e)
    {
        if (Button5.Text == "")
        {
            Button5.Text = Label1.Text;
            if (Label1.Text== "X")
            {
                Label1.Text= "O";
            }
            else
            {
                Label1.Text= "X";
            }
        }
    }
    protected void Button6_Click(object sender, EventArgs e)
    {
        if (Button6.Text == "")
        {
            Button6.Text = Label1.Text;
            if (Label1.Text== "X")
            {
                Label1.Text= "O";
            }
            else
            {
                Label1.Text= "X";
            }
        }
    }
    protected void Button7_Click(object sender, EventArgs e)
    {
        if (Button7.Text == "")
        {
            Button7.Text = Label1.Text;
            if (Label1.Text== "X")
            {
                Label1.Text= "O";
            }
            else
            {
                Label1.Text= "X";
            }
        }
    }
    protected void Button8_Click(object sender, EventArgs e)
    {
        if (Button8.Text == "")
        {
            Button8.Text = Label1.Text;
            if (Label1.Text== "X")
            {
                Label1.Text= "O";
            }
            else
            {
                Label1.Text= "X";
            }
        }
    }
    protected void Button9_Click(object sender, EventArgs e)
    {
        if (Button9.Text == "")
        {
            Button9.Text = Label1.Text;
            if (Label1.Text== "X")
            {
                Label1.Text= "O";
            }
            else
            {
                Label1.Text= "X";
            }
        }
    }
}
