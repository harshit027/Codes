﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class factorialpage : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void button1_Click(object sender, EventArgs e)
    {
        //string s=1; 
        //int c = int.Parse(text4.Text);
        int x = int.Parse(text1.Text);
        //int i = int.Parse(string s);  
        //text1.Text = x.ToString();
        ///int i = 1;
        //text3.Text = i.ToString();
        //text4.Text = c.ToString();
        ////while (i <= x)
        ////{
        ////    i = i * x;
        ////    --x;

        ////}
        ////text2.Text = c.ToString();
        int f = 1;
        for (int i = 1; i <= x; i++)
        {
            f *= i;
        }
        text2.Text = f.ToString();
    }
    protected void Button4_Click(object sender, EventArgs e)
    {


        //string s=1; 
        label1.Text = label1.ToString();
        int c = int.Parse(text4.Text);
        int x = int.Parse(text1.Text);
        //int i = int.Parse(string s);  
        text1.Text = x.ToString();
        int i = int.Parse(text3.Text);
        text3.Text = i.ToString();
        text4.Text = c.ToString();
        while (i <= x)
        {
            c = c * x;
            --x;

        }
        text2.Text = c.ToString();
        text2.BackColor = System.Drawing.Color.Green;
        label1.Text = label1.ToString();
        label1.Text = "Correct Answer";
        label1.BackColor = System.Drawing.Color.Green;
    
    }

    
}
