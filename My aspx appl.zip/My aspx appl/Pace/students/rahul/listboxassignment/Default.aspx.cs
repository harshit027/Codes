﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void myfunction(object sender, EventArgs e)
    {
        int i;
       
        if (lst1.SelectedIndex != -1 && lst1.SelectedValue == "1")
        {
            lst2.Items.Clear();
            string []arr = { "simple", "flash_mix","greentouch","crazy", "teddy" };
            for(i=0;i<arr.Length ;i++)
            {
                lst2 .Items .Add(arr[i]);
            }
        }
        if (lst1.SelectedIndex != -1 && lst1.SelectedValue == "2")
        {
            lst2.Items.Clear();
            string[] arr = {"blue_blast", "moonlight", "simple_cake", "belated_bday", "candle&cake" };
            for(i=0;i<arr.Length ;i++)
            {
                lst2.Items.Add(arr[i]);
            }
        }
        if (lst1.SelectedIndex != -1 && lst1.SelectedValue == "3")
        {
            lst2.Items.Clear();
            string[] arr = { "baloon", "dil", "kiddy", "red_rose", "beMy_velentine" };
            for (i = 0; i < arr.Length; i++)
            {
                lst2.Items.Add(arr[i]);
            }
        }
        if (lst1.SelectedIndex != -1 && lst1.SelectedValue == "4")
        {
            lst2.Items.Clear();
            string[] arr = { "holi_wishes", "happy_holi", "holi_hai", "playwith_colors", "sweet_for_u" };
            for (i = 0; i < arr.Length; i++)
            {
                lst2.Items.Add(arr[i]);
            }
        }
        if (lst1.SelectedIndex != -1 && lst1.SelectedValue == "5")
        {
            lst2.Items.Clear();
            string[] arr = { "happy_diwali", "shubh_diwali", "light-up", "shubh_lakshmi" };
            for (i = 0; i < arr.Length; i++)
            {
                lst2.Items.Add(arr[i]);
            }
        }
    }
    protected void lst2_function(object sender, EventArgs e)
    {
        cleare();
        for (int i = 0; i < lst2.Items.Count; i++)
        {
            if (lst2.Items[i].Selected == true)
            {
                if (lst2.Items[i].Text == "simple") btn1.Visible = true;
                else if (lst2.Items[i].Text == "flash_mix") btn2.Visible = true;
                else if (lst2.Items[i].Text == "greentouch") btn3.Visible = true;
                else if (lst2.Items[i].Text == "crazy") btn4.Visible = true;
                else if (lst2.Items[i].Text == "teddy") btn5.Visible = true;
                else if (lst2.Items[i].Text == "blue_blast") btn6.Visible = true;
                else if (lst2.Items[i].Text == "moonlight") btn7.Visible = true;
                else if (lst2.Items[i].Text == "simple_cake") btn8.Visible = true;
                else if (lst2.Items[i].Text == "belated_bday") btn9.Visible = true;
                else if (lst2.Items[i].Text == "candle&cake") btn10.Visible = true;
                else if (lst2.Items[i].Text == "baloon") btn11.Visible = true;
                else if (lst2.Items[i].Text == "dil") btn12.Visible = true;
                else if (lst2.Items[i].Text == "kiddy") btn13.Visible = true;
                else if (lst2.Items[i].Text == "red_rose") btn14.Visible = true;
                else if (lst2.Items[i].Text == "beMy_velentine") btn15.Visible = true;
                else if (lst2.Items[i].Text == "holi_wishes") btn16.Visible = true;
                else if (lst2.Items[i].Text == "happy_holi") btn17.Visible = true;
                else if (lst2.Items[i].Text == "holi_hai") btn18.Visible = true;
                else if (lst2.Items[i].Text == "playwith_colors") btn19.Visible = true;
                else if (lst2.Items[i].Text == "sweet_for_u") btn20.Visible = true;
                else if (lst2.Items[i].Text == "happy_diwali") btn21.Visible = true;
                else if (lst2.Items[i].Text == "shubh_diwali") btn22.Visible = true;
                else if (lst2.Items[i].Text == "light-up") btn23.Visible = true;
                else if (lst2.Items[i].Text == "shubh_lakshmi") btn24.Visible = true;

            }
        }

    }
    void cleare()
    {
       // string s = btn + "1";
       // ImageButton img = (ImageButton)s;
       // img.Visible = true;
        btn1.Visible = true;
        btn2.Visible = false; btn3.Visible = false; btn4.Visible = false; btn5.Visible = false; btn6.Visible = false;
        btn7.Visible = false; btn8.Visible = false; btn9.Visible = false; btn10.Visible = false; btn11.Visible = false; btn12.Visible = false;
        btn13.Visible = false; btn14.Visible = false; btn15.Visible = false; btn16.Visible = false; btn17.Visible = false; btn18.Visible = false;
        btn19.Visible = false; btn20.Visible = false; btn21.Visible = false; btn22.Visible = false; btn23.Visible = false; btn24.Visible = false;
    }
    protected void btnfunction(object sender, ImageClickEventArgs e)
    {
        ImageButton img = (ImageButton)sender;
        if (img==btn1)
        {
            Response.Redirect("~/html_page/simple.html");
        }
        if (img == btn2)
        {
            Response.Redirect("~/html_page/flashmix.html");
        }
        if (img == btn3)
        {
            Response.Redirect("~/html_page/greentouch.html");
        }
        if (img == btn4)
        {
            Response.Redirect("~/html_page/crazy.html");
        }
        if (img == btn5)
        {
            Response.Redirect("~/html_page/teddy.html");
        }
        if (img == btn6)
        {
            Response.Redirect("~/html_page/blue_blast.html");
        }
        if (img == btn8)
        {
            Response.Redirect("~/html_page/simplecake.html");
        }
        if (img == btn9)
        {
            Response.Redirect("~/html_page/belated_bday.html");
        }
        if (img == btn10)
        {
            Response.Redirect("~/html_page/candle&cake.html");
        }
        if (img == btn11)
        {
            Response.Redirect("~/html_page/baloon.html");
        }
        if (img == btn12)
        {
            Response.Redirect("~/html_page/dil.html");
        }
        if (img == btn13)
        {
            Response.Redirect("~/html_page/kiddy.html");
        }
        if (img == btn14)
        {
            Response.Redirect("~/html_page/redrose.html");
        }
        if (img == btn15)
        {
            Response.Redirect("~/html_page/bemyvlntine.html");
        }
        if (img == btn16)
        {
            Response.Redirect("~/html_page/holi_wish.html");
        }
        if (img == btn7)
        {
            Response.Redirect("~/html_page/moonlight.html");
        }
        if (img == btn17)
        {
            Response.Redirect("~/html_page/hapyholi.html");
        }
        if (img == btn18)
        {
            Response.Redirect("~/html_page/holi_hai.html");
        }
        if (img == btn19)
        {
            Response.Redirect("~/html_page/play_with_colors.html");
        }
        if (img == btn20)
        {
            Response.Redirect("~/html_page/sweetsforu.html");
        }
        if (img == btn21)
        {
            Response.Redirect("~/html_page/happy_diwali.html");
        }
        if (img == btn22)
        {
            Response.Redirect("~/html_page/shubhdiwali.html");
        }
        if (img == btn23)
        {
            Response.Redirect("~/html_page/lightup.html");
        }
        if (img == btn24)
        {
            Response.Redirect("~/html_page/shubhlakshmi.html");
        }
    }
}
