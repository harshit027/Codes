using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Literal11.Text == "1")
        {
            Response.Write("Game Has Finished");
        }

        else if (Literal1.Text == "" && Literal11.Text == "0")
            {
                if (Literal10.Text == "0")
                {
                    Literal1.Text = "X";
                    Literal10.Text = "1";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0") 
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if( Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
                else
                {
                    Literal1.Text = "0";
                    Literal10.Text = "0";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
            }
            else
            {
                Response.Write("u can't move here");
            }

        }
    
    protected void Button2_Click(object sender, EventArgs e)
    {

        if (Literal11.Text == "1")
        {
            Response.Write("Game Has Finished");
        }

        else if (Literal2.Text == "" && Literal11.Text == "0")
            {
                if (Literal10.Text == "0")
                {
                    Literal2.Text = "X";
                    Literal10.Text = "1";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
                else
                {
                    Literal2.Text = "0";
                    Literal10.Text = "0";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
            }
            else
            {
                Response.Write("u can't move here");
            }
        }
    
    protected void Button3_Click(object sender, EventArgs e)
    {

        if (Literal11.Text == "1")
        {
            Response.Write("Game Has Finished");
        }

        else if (Literal3.Text == "" && Literal11.Text == "0")
            {
                if (Literal10.Text == "0")
                {
                    Literal3.Text = "X";
                    Literal10.Text = "1";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
                else
                {
                    Literal3.Text = "0";
                    Literal10.Text = "0";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Literal11.Text = "1";
                        Response.Write("X You Won");
                    }
                }
            }
            else
            {
                Response.Write("u can't move here");
            }

        }
    
    protected void Button4_Click(object sender, EventArgs e)
    {
        if (Literal11.Text == "1")
        {
            Response.Write("Game Has Finished");
        }


        else if (Literal4.Text == "" && Literal11.Text == "0")
            {
                if (Literal10.Text == "0")
                {
                    Literal4.Text = "X";
                    Literal10.Text = "1";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
                else
                {
                    Literal4.Text = "0";
                    Literal10.Text = "0";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
            }
            else
            {
                Response.Write("u can't move here");
            }
        }
    
    protected void Button5_Click(object sender, EventArgs e)
    {

        if (Literal11.Text == "1")
        {
            Response.Write("Game Has Finished");
        }

        else if (Literal5.Text == "" && Literal11.Text == "0")
            {
                if (Literal10.Text == "0")
                {
                    Literal5.Text = "X";
                    Literal10.Text = "1";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");

                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");

                        Literal11.Text = "1";
                    }
                }
                else
                {
                    Literal5.Text = "0";
                    Literal10.Text = "0";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");

                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");

                        Literal11.Text = "1";
                    }
                }
            }
            else
            {
                Response.Write("u can't move here");
            }
        }
 
    protected void Button6_Click(object sender, EventArgs e)
    {

        if (Literal11.Text == "1")
        {
            Response.Write("Game Has Finished");
        }

        else if (Literal6.Text == "" && Literal11.Text == "0")
            {
                if (Literal10.Text == "0")
                {
                    Literal6.Text = "X";
                    Literal10.Text = "1";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
                else
                {
                    Literal6.Text = "0";
                    Literal10.Text = "0";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
            }
            else
            {
                Response.Write("u can't move here");
            }
        }

    protected void Button7_Click(object sender, EventArgs e)
    {
        if (Literal11.Text == "1")
        {
            Response.Write("Game Has Finished");
        }


        else if (Literal7.Text == "" && Literal11.Text == "0")
            {
                if (Literal10.Text == "0")
                {
                    Literal7.Text = "X";
                    Literal10.Text = "1";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
                else
                {
                    Literal7.Text = "0";
                    Literal10.Text = "0";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
            }
            else
            {
                Response.Write("u can't move here");
            }
        }

    protected void Button8_Click(object sender, EventArgs e)
    {
        if (Literal11.Text == "1")
        {
            Response.Write("Game Has Finished");
        }

        else if (Literal8.Text == "" && Literal11.Text == "0")
            {
                if (Literal10.Text == "0")
                {
                    Literal8.Text = "X";
                    Literal10.Text = "1";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
                else
                {
                    Literal8.Text = "0";
                    Literal10.Text = "0";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
            }
            else
            {
                Response.Write("u can't move here");
            }
        }

    protected void Button9_Click(object sender, EventArgs e)
    {

        if (Literal11.Text == "1")
        {
            Response.Write("Game Has Finished");
        }

        else if (Literal9.Text == "" && Literal11.Text == "0")
            {
                if (Literal10.Text == "0")
                {
                    Literal9.Text = "X";
                    Literal10.Text = "1";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
                else
                {
                    Literal9.Text = "0";
                    Literal10.Text = "0";

                    if (Literal1.Text == "0" && Literal2.Text == "0" && Literal3.Text == "0" || Literal4.Text == "0" && Literal5.Text == "0" && Literal6.Text == "0" || Literal7.Text == "0" && Literal8.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal4.Text == "0" && Literal7.Text == "0" || Literal2.Text == "0" && Literal5.Text == "0" && Literal8.Text == "0" || Literal3.Text == "0" && Literal6.Text == "0" && Literal9.Text == "0" || Literal1.Text == "0" && Literal5.Text == "0" && Literal9.Text == "0" || Literal7.Text == "0" && Literal5.Text == "0" && Literal3.Text == "0")
                    {
                        Response.Write("0 You Won");
                        Literal11.Text = "1";
                    }
                    else if (Literal1.Text == "X" && Literal2.Text == "X" && Literal3.Text == "X" || Literal4.Text == "X" && Literal5.Text == "X" && Literal6.Text == "X" || Literal7.Text == "X" && Literal8.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal4.Text == "X" && Literal7.Text == "X" || Literal2.Text == "X" && Literal5.Text == "X" && Literal8.Text == "X" || Literal3.Text == "X" && Literal6.Text == "X" && Literal9.Text == "X" || Literal1.Text == "X" && Literal5.Text == "X" && Literal9.Text == "X" || Literal7.Text == "X" && Literal5.Text == "X" && Literal3.Text == "X")
                    {
                        Response.Write("X You Won");
                        Literal11.Text = "1";
                    }
                }
            }
            else
            {
                Response.Write("u can't move here");
            }
        }
    }

