﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.OleDb;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {
        
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        //IEnumerable
        Literal1.Text="";
        OleDbDataReader obj = (OleDbDataReader) AccessDataSource1.Select(DataSourceSelectArguments.Empty);
        while (obj.Read())
        {
            Literal1.Text += "<br>Row Value :" + obj[0] + ", " + obj[1] + ", " + obj[2] + ", " + obj[3] + ", " + obj[4];
        }
        obj.Close();
        //AccessDataSource1.InsertCommand = "insert into query";
        //AccessDataSource1.Insert();
    }
}
