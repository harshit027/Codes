﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void changesubcat(object sender, EventArgs e)
    {
        lst2.Items.Clear();
        switch (lst1.SelectedIndex)
        {
            case 0:
                lst2.Items.Add("Flowers");
                lst2.Items.Add("Crackers");
                break;
            case 1:
                lst2.Items.Add("Flowers");
                lst2.Items.Add("Others");
                break;
        }
    }
    protected void setgreetings(object sender, EventArgs e)
    {
        image1.ImageUrl = "";
        image2.ImageUrl = "";
        if (lst1.SelectedIndex == 0 && lst2.SelectedIndex == 0)
        {
            image1.ImageUrl = "images/d1.bmp";
            image2.ImageUrl = "images/d2.bmp";
        }
        if (lst1.SelectedIndex == 0 && lst2.SelectedIndex == 1)
        {
            image1.ImageUrl = "images/d3.bmp";
        }
        if (lst1.SelectedIndex == 1 && lst2.SelectedIndex == 0)
        {
            image1.ImageUrl = "images/v1.bmp";
            image2.ImageUrl = "images/v2.bmp";
        }
        if (lst1.SelectedIndex == 1 && lst2.SelectedIndex == 1)
        {
            image1.ImageUrl = "images/v3.bmp";
        }
    }
}
