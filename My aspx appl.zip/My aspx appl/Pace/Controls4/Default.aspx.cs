﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void AddTableData(object sender, EventArgs e)
    {
        string[][] data = { 
                                       new string[] {"1002","SHASHANK","50000","2000","1000","51000"},
                                       new string[]  {"1003","SHASHANK","50000","2000","1000","51000"},
                                        new string[] {"1004","SHASHANK","50000","2000","1000","51000"},
                                       new string[]  {"1005","SHASHANK","50000","2000","1000","51000"},
                                    };
        for (int i = 0; i <= data.GetLength(0) - 1; i++)
        {
            TableRow tr = new TableRow();
            TableCell tc1 = new TableCell();
            TableCell tc2 = new TableCell();
            TableCell tc3 = new TableCell();
            TableCell tc4 = new TableCell();
            TableCell tc5 = new TableCell();
            TableCell tc6 = new TableCell();
            
            tc1.Text = data[i][0];
            tc2.Text = data[i][1];
            tc3.Text = data[i][2];
            tc4.Text = data[i][3];
            tc5.Text = data[i][4];
            tc6.Text = data[i][5];
            tr.Cells.Add(tc1);
            tr.Cells.Add(tc2);
            tr.Cells.Add(tc3);
            tr.Cells.Add(tc4);
            tr.Cells.Add(tc5);
            tr.Cells.Add(tc6);
            
            Table1.Rows.Add(tr);
        }

        System.Drawing.Color rowcolor1 = System.Drawing.Color.YellowGreen;
        for (int j = 0; j < Table1.Rows.Count; j++)
        {
            if (j % 2 == 0)
            {
                Table1.Rows[j].BackColor = rowcolor1;
            }
        }
    }
}
