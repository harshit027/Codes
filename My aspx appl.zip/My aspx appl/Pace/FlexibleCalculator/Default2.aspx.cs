﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Calculate(object sender, EventArgs e)
    {
        litError.Visible = false;
        try
        {
            double d1 = double.Parse(txtFirstNumber.Text);
            double d2 = double.Parse(txtSecondNumber.Text);
            double d3 = 0;

            Button btn = (Button)sender;
            if (btn.Text == "+")
            {
                d3 = d1 + d2;
            }
            else if (btn.Text == "-")
            {
                d3 = d1 - d2;
            }
            else if (btn.Text == "*")
            {
                d3 = d1 * d2;
            }
            else if (btn.Text == "/")
            {
                d3 = d1 / d2;
            }
            txtResult.Text = d3.ToString();
        }
        catch (Exception ex)
        {
            litError.Text = "<div style='background-color:red; color:white;'>Error" + ex.Message + "</div>";
            litError.Visible = true;
        }
        //txtResult.Text = d3+"";
        //txtResult.Text = Convert.ToString(d3);
    }
    protected void Button1_Click(object sender, EventArgs e)
    {

    }
}
