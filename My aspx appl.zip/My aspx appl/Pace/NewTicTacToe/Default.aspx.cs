﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void CommonFunction(object sender, EventArgs e)
    {
        Button btn = (Button)sender;
        if (btn.Text == "")
        {
            btn.Text = lit1.Text;
            if (CheckWinner())
            {
                lit1.Text = lit1.Text + " You have won Match";
                lit1.Visible = true;
                Button1.Enabled = false;
                Button2.Enabled = false;
                Button3.Enabled = false;
                Button4.Enabled = false;
                Button5.Enabled = false;
                Button6.Enabled = false;
                Button7.Enabled = false;
                Button8.Enabled = false;
                Button9.Enabled = false;
                return;
            }
            if (lit1.Text == "X")
            {
                lit1.Text = "O";
            }
            else
            {
                lit1.Text = "X";
            }
        }
    }
    bool CheckWinner()
    {
        if (Button1.Text == Button2.Text && Button1.Text == Button3.Text && Button1.Text != "")
        {
            return true;
        }
        if (Button4.Text == Button5.Text && Button4.Text == Button6.Text && Button4.Text != "")
        {
            return true;
        }
        if (Button7.Text == Button8.Text && Button7.Text == Button9.Text && Button7.Text != "")
        {
            return true;
        }
        if (Button1.Text == Button4.Text && Button1.Text == Button7.Text && Button1.Text != "")
        {
            return true;
        }
        if (Button2.Text == Button5.Text && Button2.Text == Button8.Text && Button2.Text != "")
        {
            return true;
        }
        if (Button3.Text == Button6.Text && Button3.Text == Button9.Text && Button3.Text != "")
        {
            return true;
        }
        if (Button1.Text == Button5.Text && Button1.Text == Button9.Text && Button1.Text != "")
        {
            return true;
        }
        if (Button3.Text == Button5.Text && Button3.Text == Button7.Text && Button3.Text != "")
        {
            return true;
        }
        return false;
    }
}
