﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void EH1(object sender, EventArgs e)
    {
        try
        {
            int[] a = { 10, 20, 30, 40, 50 };
            for (int i = 0; i < 5; i++)
            {
                Response.Write("<br>Array Value = " + a[i]);
            }
        }
        catch (IndexOutOfRangeException pace)
        {
            Response.Write("<br>Index range se bahar ho gayee" + pace.Message);
        }
        catch (ArgumentException pace)
        {
            Response.Write("<br>Index range se bahar ho gayee" + pace.Message);
        }
        catch (Exception pace)
        {
            Response.Write("<br>Index range se bahar ho gayee" + pace.Message);
        }
        finally
        {
            Response.Write("I am from finally");
        }
    }
}
