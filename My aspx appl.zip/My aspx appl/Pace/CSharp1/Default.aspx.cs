﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    enum month
    {
        jan=1,
        feb,
        mar, apr, may, jun, jul, aug, sep, oct, nov, dec, sun=0, mon, tue, wed, thu, fri, sat
    };
    protected void Page_Load(object sender, EventArgs e)
    {
         month m = month.may;
         Response.Write((int)m);
         Response.Write((int)month.wed);
    }
    protected void Button10_Click(object sender, EventArgs e)
    {
        Button[] btn = { Button1, Button2, Button3, Button4, Button5, Button6, Button7, Button8, Button9, Button10 };
        //object[] btn = new object[10];
        //btn[0] = Button1;
        //btn[1] = Button2;
        //btn[2] = Button3;
        //btn[3] = Button4;
        //btn[4] = Button5;
        //btn[5] = Button6;
        //btn[6] = Button7;
        //btn[7] = Button8;
        //btn[8] = Button9;
        //btn[9] = Button10;
        foreach (object x in btn)
        {
            
            if (x is Button)
            {
                Button b = (Button)x;
                b.BackColor = System.Drawing.Color.Green;
                b.Text = "PACE BUREAU";
                if (b.ID == "Button5")
                {
                    b.BackColor = System.Drawing.Color.Red;
                }
            }
        }
    }
}
