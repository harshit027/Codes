﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void ShowSelectedItems(object sender, EventArgs e)
    {
        for (int i = 0; i <= cbl1.Items.Count - 1; i++)
        {
            if (cbl1.Items[i].Selected)
            {
                lit1.Text += cbl1.Items[i].Text+"<br/>";
            }
        }
    }
    protected void rbl1_SelectedIndexChanged(object sender, EventArgs e)
    {
        string selcolor = rbl1.SelectedValue;
        btn1.BackColor = System.Drawing.Color.FromName(selcolor);
        rbl1.Attributes.Add("style", "background-color:" + selcolor);
    }
    protected void rbl2_SelectedIndexChanged(object sender, EventArgs e)
    {
        string selcolor = rbl2.SelectedValue;
        btn1.ForeColor = System.Drawing.Color.FromName(selcolor);
    }
}
