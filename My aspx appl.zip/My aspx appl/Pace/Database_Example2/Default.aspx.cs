﻿using System;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class _Default : System.Web.UI.Page 
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        try
        {
            string qry = "select * from department where deptno=" + TextBox1.Text;
            SqlDataSource1.SelectCommand = qry;
            SqlDataReader dr = (SqlDataReader)SqlDataSource1.Select(DataSourceSelectArguments.Empty);

            if (dr.Read())
            {
                TextBox1.Text = dr[0].ToString();
                txtDepartmentName.Text = dr[1].ToString();
                txtLocation.Text = dr[2].ToString();
            }
        }
        catch (Exception ex)
        {
            Response.Write("Error :" + ex);
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        lblMessage.Visible = true;
        try
        {
            string qry = "insert into department (dname, loc) values ('" + txtDepartmentName.Text + "', '" + txtLocation.Text + "')";
            SqlDataSource1.InsertCommand = qry;
            if (SqlDataSource1.Insert() > 0)
            {
                lblMessage.Text = "Department Inserted Successfully";
            }
            else
            {
                lblMessage.Text = "Error in inserting department data";
            }
        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error :" + ex;
        }
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        lblMessage.Visible = true;
        try
        {
            string updatequery = "update department set dname='" + txtDepartmentName.Text + "', loc = '" + txtLocation.Text + "' where deptno=" + TextBox1.Text;
            SqlDataSource1.UpdateCommand = updatequery;
            if (SqlDataSource1.Update() > 0)
            {
                lblMessage.Text = "Department Updated Successfully";
            }
            else
            {
                lblMessage.Text = "Can not update department data";
            }

        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error :" + ex;
        }

    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        lblMessage.Visible = true;
        try
        {
            string deletequery = "delete from department  where deptno=" + TextBox1.Text;
            SqlDataSource1.DeleteCommand = deletequery;
            if (SqlDataSource1.Delete() > 0)
            {
                lblMessage.Text = "Department Deleted Successfully";
            }
            else
            {
                lblMessage.Text = "Can not delete department data";
            }

        }
        catch (Exception ex)
        {
            lblMessage.Text = "Error :" + ex;
        }
    }
}
