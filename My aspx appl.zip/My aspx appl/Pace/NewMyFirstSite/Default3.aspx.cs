﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Drawing;

public partial class Default3 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("PACE BUREAU");
    }
    protected void btn1_Click(object sender, EventArgs e)
    {
        btn2.BackColor = Color.Red;
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        btn2.BackColor = Color.Green;
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        btn2.BackColor = Color.Blue;
    }
    protected void Button3_Click(object sender, EventArgs e)
    {
        btn2.BackColor = Color.Yellow;
    }
    protected void Button4_Click(object sender, EventArgs e)
    {
        btn2.BackColor = Color.Magenta;
    }
}
