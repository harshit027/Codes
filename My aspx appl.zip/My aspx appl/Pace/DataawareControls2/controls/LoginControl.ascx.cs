﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;

public partial class LoginControl : System.Web.UI.UserControl
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        lblError.Visible = false;
        try
        {
            if (txtUsername.Text == "")
            {
                lblError.Text = "Invalid Username";
                lblError.Visible = true;
                return;
            }
            if (txtPassword.Text == "")
            {
                lblError.Text = "Invalid Password";
                lblError.Visible = true;
                return;
            }
            Database db = new Database();
            string q = "select * from employee where ename='" + txtUsername.Text + "' and epassword='" + txtPassword.Text + "'";
            SqlDataReader dr = db.getdata(q);
            if (dr.Read())
            {
                Session.Add("ValidUser", dr["ename"].ToString());
                //redirection
            }
            else
            {
                lblError.Text = "Invalid username/password";
                lblError.Visible = true;
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "Error :" + ex;
            lblError.Visible = true;
        }
    }
}
