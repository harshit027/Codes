function showAnchor()
{
  alert(document.location.hash);
}
function showHost()
{
  alert(document.location.host);
}
function showPort()
{
  alert(document.location.port);
}
function showProtocol()
{
  alert(document.location.protocol);
}
function showPath()
{
  alert(document.location.pathname);
}
function showURL()
{
  alert(document.location.href);
}