<html>
<head><title>Process Form1</title>
</head>
<body>
<?php
$name=$_GET["name"];
$branch=$_GET["branch"];
$college=$_GET["college"];
$category=$_GET["category"];
$sex=$_GET["sex"];
$sport=$_GET["sport"];
print ("<br>Name : <b>$name</b>");
print ("<br>Branch : <b>$branch</b>");
print ("<br>College : <b>$college</b>");
print ("<br>Category : <b>$category</b>");
print ("<br>Sex : <b>$sex</b>");
print ("<br>Sport : <b>$sport</b>");

?>
</body>
</html>