<html>
<head>
<title></title>
</head>
<body>
<?php

$bookname=$_POST["bookname"];
$author=$_POST["author"];
$price=$_POST["price"];
print ( "<br>Book Name : <b>$bookname</b>");
print ( "<br>Author : <b>$author</b>");
print ( "<br>Price : <b>$price</b>");
?>
</body>
</html>