<html>
<head>
</head>
<body>
<h3>Appending the file through fwrite()</h3><br>
<form action="ProcessAppendFile.php" method="post">
Filename :<input type="text" name="filename" /><br />
Data : <textarea rows="4" cols="30" name="data"></textarea><br />
<input type="submit" value="Save To File"/>
</form>
</body>
</html>