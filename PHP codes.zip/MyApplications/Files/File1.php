<?php
print "Hello this is File1.php ! I have added 4 and 6 and printed result as".(4+6);
?>