<?php
print "Hello this is File2.php ! I Have added 6 and 10 and returned result"; 
return (6+10);
?>
