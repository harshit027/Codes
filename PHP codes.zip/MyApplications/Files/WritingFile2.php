<html>
<head>
</head>
<body>
<h3>Writing the file through fputs()</h3><br>
<form action="ProcessWritingFile2.php" method="post">
Filename :<input type="text" name="filename" /><br />
Data : <textarea rows="4" cols="30" name="data"></textarea><br />
<input type="submit" value="Save To File"/>
</form>
</body>
</html>