<html>
<head><title>My First PHP</title>
</head>
<body>
<div style="text-align:center; background-color:#0066FF; color:#FFFFFF;">
<h3>
<?php
print("Written of Standard Tag");
// this is a comment
/* this is another style of commenting*/
# this is also a comment
?>
<br>
<?
print("Written of Short Tag");
?>
<br>
<%
print("Written of ASP Tag");
%>
<script language="php">
print("Written of Script Tag");
</script>
</h3>
</div>

</body>
</html>