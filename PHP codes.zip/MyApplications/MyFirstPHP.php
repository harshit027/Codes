<html>
<head><title>My First PHP</title>
</head>
<body>
<div style="text-align:center; background-color:#0066FF; color:#FFFFFF;">
<h1>
<?php
print("Welcome to PHP Scripts");
?>
<br>
<?php
print("PHP : Personal Home Pages");
?>
</h1>
</div>

</body>
</html>