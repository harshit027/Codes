<html>
<head><title>My First PHP</title>
</head>
<body>
<?php
print "working";
$db=mysql_connect("localhost","root","");
?>

</body>
</html>